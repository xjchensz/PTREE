/**
 * Package that contains standard implementations for
 * {@link org.codehaus.jackson.map.jsontype.TypeResolverBuilder}
 * and
 * {@link org.codehaus.jackson.map.jsontype.TypeIdResolver}.
 *
 * @since 1.5
 */
package org.codehaus.jackson.map.jsontype.impl;
