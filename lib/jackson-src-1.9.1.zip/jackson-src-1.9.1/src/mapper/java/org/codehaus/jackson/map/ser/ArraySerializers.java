package org.codehaus.jackson.map.ser;

/**
 * @deprecated Since 1.9 use {@link org.codehaus.jackson.map.ser.std.StdArraySerializers}
 */
@Deprecated
public class ArraySerializers extends org.codehaus.jackson.map.ser.std.StdArraySerializers { }
