/**
 * 
 */
package common.graph;

import common.matrix.SparseDoubleMatrix;

/**
 * @author Xiaojun Chen
 *
 */
public class DirectedGraph implements IDirectedGraph {

	protected SparseDoubleMatrix sdm;

	public DirectedGraph(int numNodes) {
		sdm = new SparseDoubleMatrix(numNodes, numNodes);
		sdm.setEmptyValue(0);
	}

	public DirectedGraph(SparseDoubleMatrix sdm) {
		this.sdm = sdm;
		sdm.setEmptyValue(0);
	}

	public int numNodes() {
		return sdm.getRowCount() > sdm.getColumnCount() ? sdm.getRowCount()
				: sdm.getColumnCount();
	}

	@Override
	public int[] getPredecessorNodeIDs(int nodeID) {
		return sdm.getRowForColumnValues(nodeID);
	}

	@Override
	public int[] getSuccessorNodeIDs(int nodeID) {
		return sdm.getColumnForRowValues(nodeID);
	}

	@Override
	public int[] getInDegree() {
		int numNodes = sdm.getRowCount();
		int[] ind = new int[numNodes];
		for (int i = 0; i < numNodes; i++) {
			ind[i] = getPredecessorNodeIDs(i).length;
		}

		return ind;
	}

	@Override
	public int[] getOutDegree() {
		int numNodes = sdm.getColumnCount();
		int[] oud = new int[numNodes];
		for (int i = 0; i < numNodes; i++) {
			oud[i] = getSuccessorNodeIDs(i).length;
		}

		return oud;
	}

	@Override
	public void addConnection(int start, int end, double value) {
		sdm.setValue(start, end, value);
	}

	@Override
	public double getConnection(int start, int end) {
		return sdm.getValue(start, end);
	}

	@Override
	public void close() {
		sdm.close();
	}

}
