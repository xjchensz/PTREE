/**
 * 
 */
package common.graph;

import common.matrix.SparseDoubleMatrix;

/**
 * @author Xiaojun Chen
 *
 */
public class UnDirectedGraph extends DirectedGraph implements IDirectedGraph {

	public UnDirectedGraph(int numNodes) {
		super(numNodes);
	}

	public UnDirectedGraph(SparseDoubleMatrix sdm) {
		super(sdm);
	}

	@Override
	public int[] getPredecessorNodeIDs(int nodeID) {
		return getSuccessorNodeIDs(nodeID);
	}

	@Override
	public int[] getSuccessorNodeIDs(int nodeID) {
		return sdm.getCrossedElements(nodeID);
	}

	@Override
	public int[] getInDegree() {
		return getOutDegree();
	}

	@Override
	public int[] getOutDegree() {
		int numNodes = sdm.getColumnCount();
		int[] oud = new int[numNodes];
		for (int i = 0; i < numNodes; i++) {
			oud[i] = getSuccessorNodeIDs(i).length;
		}
		return oud;
	}

}
