/**
 * 
 */
package common.graph;

/**
 * @author Great
 * 
 */
public class StatusStackTable {

	private Status[][] objs;

	private int[] ptr;

	public StatusStackTable(int numNodes) {
		objs = new Status[numNodes][];
		ptr = new int[numNodes];
	}

	public boolean push(int nodeIndex, Status status) {
		if (objs[nodeIndex] == null) {
			objs[nodeIndex] = new Status[ptr.length > 100 ? 10
					: ptr.length > 10 ? 5 : 1];
		}

		if (ptr[nodeIndex] >= objs[nodeIndex].length) {
			resize(nodeIndex);
		}
		objs[nodeIndex][ptr[nodeIndex]++] = status;
		return true;
	}

	private void resize(int nodeIndex) {
		Status[] temp = new Status[ptr[nodeIndex] * 3 / 2 + 1];

		for (int i = 0; i < ptr[nodeIndex]; i++) {
			temp[i] = objs[nodeIndex][i];
		}

		objs[nodeIndex] = temp;
	}

	public Status pop(int nodeIndex) {
		if (ptr[nodeIndex] == 0) {
			return Status.none;
		}
		Status st = objs[nodeIndex][--ptr[nodeIndex]];

		if (ptr[nodeIndex] == 0) {
			// release memory
			objs[nodeIndex] = null;
		} else if (ptr[nodeIndex] == 0) {
			objs[nodeIndex] = null;
		}

		return st;
	}

	public void changeTop(int nodeIndex, Status status) {
		if (ptr[nodeIndex] > 0) {
			objs[nodeIndex][--ptr[nodeIndex]] = status;
		}
	}

	public void repace(int nodeIndex, Status orig, Status tobe) {
		for (int i = 0; i < ptr[nodeIndex]; i++) {
			if (objs[nodeIndex][i] == orig) {
				objs[nodeIndex][i] = tobe;
			}
		}
	}

	public Status top(int nodeIndex) {
		if (ptr[nodeIndex] == 0) {
			return Status.none;
		}
		return objs[nodeIndex][ptr[nodeIndex] - 1];
	}

	public int length(int nodeIndex) {
		return ptr[nodeIndex];
	}

	public boolean isEmpty(int nodeIndex) {
		return length(nodeIndex) == 0;
	}

	public void clear(int nodeIndex) {
		ptr[nodeIndex] = 0;
	}

	public void destroy() {
		objs = null;
		for (int i = 0; i < ptr.length; i++) {
			ptr[i] = 0;
		}
	}

}
