package common.graph;

public enum Status {
	none, toPop, toProcessSucc, toPostProcess, processed

}
