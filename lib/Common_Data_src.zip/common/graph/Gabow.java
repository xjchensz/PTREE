package common.graph;

import java.util.ArrayList;

import common.utils.collection.IntStack;
import common.utils.collection.OrderedIntArraySet;

public class Gabow {

	public enum NODEORDER {
		TOP, REVERSETOP
	}

	IDirectedGraph graph;
	private int nodeNum;
	private int[][] topOrder;
	private int[] Order;
	private int OrderNum = 0;
	private int Part[];
	private int PartNum = 0;
	private int[] pathStack;
	private int pathPtr = 0;
	private int[] rootStack;
	private int rootPtr = 0;
	private IntStack processStack;
	private StatusStackTable status;

	private ArrayList<Integer> Sink;

	private OrderedIntArraySet m_Set = new OrderedIntArraySet();

	public Gabow(IDirectedGraph graph) {
		this.graph = graph;
		nodeNum = graph.numNodes();
	}

	public void run() {
		Sink = new ArrayList<Integer>();
		this.Order = new int[nodeNum];
		this.topOrder = new int[nodeNum][];
		this.Part = new int[nodeNum];
		pathStack = new int[nodeNum];
		rootStack = new int[nodeNum];
		status = new StatusStackTable(nodeNum);

		pathPtr = rootPtr = -1;
		OrderNum = PartNum = 0;
		for (int i = 0; i < nodeNum; i++) {
			Order[i] = Part[i] = -1;
		}

		processStack = new IntStack(nodeNum);

		for (int i = 0; i < nodeNum; i++) {
			if (Order[i] < 0) {
				gabow(i);
			}
		}

		int[][] top = new int[PartNum][];
		for (int i = 0; i < PartNum; i++) {
			top[i] = topOrder[PartNum - 1 - i];
		}
		topOrder = top;

		for (int i = 0; i < Part.length; i++) {
			Part[i] = PartNum - 1 - Part[i];
		}

		// clear something
		processStack.destroy();
		status.destroy();
		pathStack = null;
		rootStack = null;
		Order = null;
		Sink.clear();
	}

	private void gabow(int nodeID) {

		processStack.push(nodeID);
		status.push(nodeID, Status.toProcessSucc);

		int succNodeID;
		int[] succ;
		Status temp;
		while (!processStack.isEmpty()) {
			nodeID = processStack.top();
			switch (status.top(nodeID)) {
			case toProcessSucc:
				// not visited

				Order[nodeID] = OrderNum++;
				pathStack[++pathPtr] = nodeID;
				rootStack[++rootPtr] = nodeID;
				succ = graph.getSuccessorNodeIDs(nodeID);

				if (succ.length == 0) {
					// nodeID is a sink node

					rootPtr--;
					Part[pathStack[pathPtr--]] = PartNum;
					topOrder[PartNum] = new int[] { nodeID };
					Sink.add(PartNum);
					processStack.pop();
					status.pop(nodeID);
					status.repace(nodeID, Status.toPostProcess,
							Status.processed);
					status.repace(nodeID, Status.toProcessSucc,
							Status.processed);
					PartNum++;
				} else {
					for (int i = 0; i < succ.length; i++) {
						succNodeID = succ[i];
						temp = status.top(succNodeID);
						if (succNodeID != nodeID && Order[succNodeID] >= 0) {
							if (Part[succNodeID] == -1
									&& (temp == Status.toPop || temp == Status.toPostProcess)) {
								processStack.push(succNodeID);
								status.push(succNodeID, Status.toPop);
							}
						}
					}

					for (int i = 0; i < succ.length; i++) {
						succNodeID = succ[i];
						temp = status.top(succNodeID);
						if (succNodeID != nodeID && Order[succNodeID] < 0) {
							// to process
							processStack.push(succNodeID);
							status.push(succNodeID, Status.toProcessSucc);
						}
					}
					status.push(nodeID, Status.toPostProcess);
				}
				break;
			case toPop:
				// visited and not label the connectivity
				while (Order[rootStack[rootPtr]] > Order[nodeID]) {
					--rootPtr;
				}
				processStack.pop();
				status.pop(nodeID);
				break;
			case toPostProcess:
				if (rootStack[rootPtr] == nodeID) {
					rootPtr--;
					if (pathStack[pathPtr] == nodeID) {
						Part[pathStack[pathPtr--]] = PartNum;
						topOrder[PartNum] = new int[] { nodeID };
					} else {
						int num = 1;
						do {
							Part[pathStack[pathPtr]] = PartNum;
							num++;
						} while (pathPtr > 0 && pathStack[--pathPtr] != nodeID);
						Part[pathStack[pathPtr--]] = PartNum;
						topOrder[PartNum] = new int[num];
						for (int i = 1; i <= num; i++) {
							topOrder[PartNum][i - 1] = pathStack[pathPtr + i];
						}
					}
					PartNum++;
				}

				// pop
				processStack.pop();
				status.pop(nodeID);
				status.repace(nodeID, Status.toPostProcess, Status.processed);
				status.repace(nodeID, Status.toProcessSucc, Status.processed);
				break;
			default:
				processStack.pop();
				status.pop(nodeID);
				break;
			}
		}
	}

	public int[] getSinkNodes() {
		if (Sink.isEmpty()) {
			for (int i = 0; i < PartNum; i++) {
				if (topOrder[i].length > 1) {
					if (getSuccessorNodeIDs(PartNum - 1 - i).length == 0) {
						Sink.add(PartNum - 1 - i);
					}
				}
			}
			for (int i = 0; i < Sink.size(); i++) {
				Sink.set(i, PartNum - 1 - Sink.get(i));
			}

			if (PartNum == 1) {
				Sink.add(0);
			}
		}

		int[] sink = new int[Sink.size()];
		for (int i = 0; i < sink.length; i++) {
			sink[i] = Sink.get(i);
		}
		return sink;
	}

	public int[] getSuccessorNodeIDs(int nodeID) {
		m_Set.clear();
		for (int i = 0; i < topOrder[nodeID].length; i++) {
			m_Set.addAll(graph.getSuccessorNodeIDs(topOrder[nodeID][i]));
		}
		int[] succ = m_Set.values();

		if (succ.length == 1) {
			return new int[] { Part[succ[0]] };
		} else if (succ.length > 1) {
			m_Set.clear();
			for (int i = 0; i < succ.length; i++) {
				m_Set.add(Part[succ[i]]);
			}
			m_Set.removeValue(nodeID);
			return m_Set.values();
		}
		return succ;
	}

	public boolean hasCycle() {
		return PartNum < nodeNum;
	}

	public int numOrigNodes() {
		return nodeNum;
	}

	public int numIndependentComponents() {
		return PartNum;
	}

	public int[] getPart() {
		return Part;
	}

	public int[][] getTopOrderNodes() {
		return topOrder;
	}

	public void close() {
		graph = null;
		processStack = null;
		Order = null;
		Part = null;
		rootStack = null;
		pathStack = null;
		topOrder = null;
		Sink.clear();
		Sink = null;
	}

}
