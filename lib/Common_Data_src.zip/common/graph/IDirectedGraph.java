package common.graph;

/**
 * 
 * Created by Xiaojun Chen at 2016/2/10
 * */
public interface IDirectedGraph {

	public int numNodes();

	public void addConnection(int start, int end, double value);

	public double getConnection(int start, int end);

	/**
	 * ordered by id
	 * */
	public int[] getPredecessorNodeIDs(int nodeID);

	/**
	 * ordered by id
	 * */
	public int[] getSuccessorNodeIDs(int nodeID);

	public int[] getInDegree();

	public int[] getOutDegree();

	public void close();
}
