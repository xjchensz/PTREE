/**
 * Created by Xiaojun Chen at 2012-3-28
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data;

import common.Configuration;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class DataConfiguration extends Configuration {

	public static int BUFFER_SIZE;

	static {
		// load values from bundle file
		initializeProperties(DataConfiguration.class.getName(),
				DataConfiguration.class);
	}
}
