/**
 * 
 */
package common.data;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import common.data.instance.IInstance;
import common.data.instance.numeric.INumericInstance;
import common.data.meta.MetaData;
import common.data.meta.NominalAttribute;
import common.utils.RandomUtils;
import common.utils.histogram.HistogramSet;

/**
 * @author xjchen
 * 
 */
public class InMemoryDataset {

	private MetaData m_MetaData;
	private ArrayList<INumericInstance> instances;

	/**
	 * 
	 */
	public InMemoryDataset(MetaData metaData) {
		m_MetaData = metaData;
		instances = new ArrayList<INumericInstance>();
	}

	public InMemoryDataset(IDataIterator<? extends INumericInstance> itr) {
		m_MetaData = itr.getMetaData();
		instances = new ArrayList<INumericInstance>();
		while (itr.hasNext()) {
			instances.add(itr.next());
		}
	}

	public MetaData getMetaData() {
		return m_MetaData;
	}

	public void addInstance(INumericInstance instance) {
		instances.add(instance);
	}

	public boolean isEmpty() {
		return instances.isEmpty();
	}

	public INumericInstance getInstance(int index) {
		return instances.get(index);
	}

	public int size() {
		return instances.size();
	}

	/**
	 * checks if all the vectors have identical attribute values
	 * 
	 * @return true is all the vectors are identical or the data is empty<br>
	 *         false otherwise
	 */
	public boolean isIdentical() {
		if (isEmpty()) {
			return true;
		}

		INumericInstance instance = instances.get(0);
		Iterator<INumericInstance> itr = instances.iterator();
		itr.next();

		while (itr.hasNext()) {
			if (!instance.equals(itr.next())) {
				return false;
			}
		}
		return true;
	}

	public boolean isIdentical(int attributeIndex) {
		if (isEmpty()) {
			return true;
		}

		IInstance instance = instances.get(0);
		Iterator<INumericInstance> itr = instances.iterator();
		itr.next();

		while (itr.hasNext()) {
			if (!instance.equalsInAttribute(itr.next(), attributeIndex)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * checks if all the vectors have identical label values
	 */
	public boolean isIdenticalLabel() {
		if (instances.size() == 0) {
			return true;
		}

		MetaData md = instances.get(0).getMetaData();
		int lid = md.getLabelId();
		if (lid < 0) {
			return true;
		}

		return isIdentical(lid);
	}

	public int[] getLabels() {
		if (instances.size() == 0) {
			return new int[0];
		}

		int[] labels = new int[instances.size()];

		Iterator<INumericInstance> itr = instances.iterator();

		int index = 0;

		while (itr.hasNext()) {
			labels[index++] = (int) itr.next().getLabel();
		}

		return labels;

	}

	/**
	 * finds the majority label, breaking ties randomly
	 * 
	 * @return the majority label value
	 */
	public int majorityLabel(Random rng) {
		if (instances.size() == 0) {
			return -1;
		}
		// count the frequency of each label value
		MetaData md = instances.get(0).getMetaData();

		int length = md.numLabels();
		int[] counts = new int[length];

		Iterator<INumericInstance> itr = instances.iterator();
		while (itr.hasNext()) {
			counts[(int) itr.next().getLabel()]++;
		}

		// find the label values that appears the most
		return RandomUtils.maxIndex(rng, counts);
	}

	public HistogramSet buildHistogram(int id, int attribteIndex, int maxBins) {
		if (instances == null || instances.size() == 0) {
			return null;
		}

		if (m_MetaData.isCategorical(attribteIndex)) {
			// categorical attribute
			int numValues = ((NominalAttribute) m_MetaData
					.getAttributeAt(attribteIndex)).numValues();
			maxBins = numValues > maxBins ? maxBins : numValues;
		}

		HistogramSet hgs = new HistogramSet(id, -1, maxBins, getMetaData()
				.numLabels(), attribteIndex);
		Iterator<INumericInstance> itr = instances.iterator();
		INumericInstance ins;
		while (itr.hasNext()) {
			ins = itr.next();
			hgs.update(ins.doubleValue(attribteIndex), (int) ins.getLabel());
		}
		return hgs;
	}

	public InMemoryDataset[] splitNumericalAttribute(int attributeIndex,
			double split) {
		InMemoryDataset[] datasets = new InMemoryDataset[2];

		datasets[0] = new InMemoryDataset(m_MetaData);
		datasets[1] = new InMemoryDataset(m_MetaData);
		Iterator<INumericInstance> itr = instances.iterator();
		INumericInstance instance;
		while (itr.hasNext()) {
			instance = itr.next();
			if (instance.doubleValue(attributeIndex) < split) {
				datasets[0].addInstance(instance);
			} else {
				datasets[1].addInstance(instance);
			}
		}

		return datasets;
	}

	public InMemoryDataset[] splitCategoricalAttribute(int attributeIndex) {
		if (!m_MetaData.isCategorical(attributeIndex)) {
			return null;
		}

		int numValues = ((NominalAttribute) m_MetaData
				.getAttributeAt(attributeIndex)).numValues();
		InMemoryDataset[] datasets = new InMemoryDataset[numValues];

		for (int i = 0; i < numValues; i++) {
			datasets[i] = new InMemoryDataset(m_MetaData);
		}

		Iterator<INumericInstance> itr = instances.iterator();
		INumericInstance instance;
		while (itr.hasNext()) {
			instance = itr.next();
			datasets[(int) instance.doubleValue(attributeIndex)]
					.addInstance(instance);
		}
		return datasets;

	}

	public void clear() {
		instances.clear();
	}

	public void dispose() {
		Iterator<INumericInstance> itr = instances.iterator();
		while (itr.hasNext()) {
			itr.next().clear();
		}
		instances = null;
	}
}
