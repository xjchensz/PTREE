/**
 * Created by Xiaojun Chen at 2011-9-20
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data;

import common.data.instance.IInstance;
import common.data.meta.MetaData;
import common.utils.ICloseableIterator;
import common.utils.IReuseableIterator;

/**
 * @author xjc
 * 
 */
public interface IDataIterator<T extends IInstance> extends
		ICloseableIterator<T>, IReuseableIterator<T> {

	public MetaData getMetaData();

}
