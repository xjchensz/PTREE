/**
 * Created by Xiaojun Chen at 2011-9-20
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data;

import common.data.instance.IInstance;

/**
 * @author xjc
 * 
 */
public interface ISizeChangeAbleDataIterator<T extends IInstance> extends
		IDataIterator<T> {

	/**
	 * try to scan whether contains more data
	 * 
	 * @return <code>true</code> if scan more data
	 * */
	public boolean scanMore(int numRows);

}
