/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package common.data;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import common.EqualsUtils;
import common.data.instance.IInstance;
import common.data.meta.MetaData;

/**
 * Holds a list of vectors and their corresponding Dataset. contains various
 * operations that deals with the vectors (subset, count,...)
 * 
 */
public class Data<T extends IInstance> {

	protected MetaData metaData;
	protected List<T> instances;

	public Data(MetaData metaData, List<T> instances) {
		this.metaData = metaData;
		this.instances = instances;
	}

	public Data(IDataIterator<T> dataIterator) {
		if (dataIterator != null) {
			this.metaData = dataIterator.getMetaData();
			instances = new ArrayList<T>();
			while (dataIterator.hasNext()) {
				instances.add(dataIterator.next());
			}
		}
	}

	/**
	 * @return the number of elements
	 */
	public int size() {
		return instances != null ? instances.size() : 0;
	}

	/**
	 * @return true if this data contains no element
	 */
	public boolean isEmpty() {
		return instances != null ? instances.isEmpty() : true;
	}

	/**
	 * @param v
	 *            element whose presence in this list if to be searched
	 * @return true is this data contains the specified element.
	 */
	public boolean contains(T v) {
		return instances != null ? instances.contains(v) : false;
	}

	/**
	 * @param v
	 *            element to search for
	 * @return the index of the first occurrence of the element in this data or
	 *         -1 if the element is not found
	 */
	public int indexof(IInstance v) {
		return instances != null ? instances.indexOf(v) : -1;
	}

	/**
	 * Returns the element at the specified position
	 * 
	 * @param index
	 *            index of element to return
	 * @return the element at the specified position
	 * @throws IndexOutOfBoundsException
	 *             if the index is out of range
	 */
	public T get(int index) {
		return instances != null ? instances.get(index) : null;
	}

	/**
	 * @return the subset of the data
	 */
	public Data<T> subData(int rowStart, int rowEnd) {
		if (instances == null) {
			return null;
		}
		List<T> subset = new ArrayList<T>(rowEnd - rowStart);

		for (int i = rowStart; i < rowEnd; i++) {
			subset.add(instances.get(i));
		}

		return new Data<T>(metaData, subset);
	}

	/**
	 * @param rng
	 *            Random number generator
	 * @param ratio
	 *            [0,1]
	 * @return a random subset without modifying the current data
	 */
	public Data<T> rsubset(Random rng, double ratio) {
		if (instances == null) {
			return null;
		}
		List<T> subset = new ArrayList<T>();

		for (T instance : instances) {
			if (rng.nextDouble() < ratio) {
				subset.add(instance);
			}
		}

		return new Data<T>(metaData, subset);
	}

	/**
	 * if data has N cases, sample N cases at random -but with replacement.
	 * 
	 * @param rng
	 */
	public Data<T> bagging(Random rng) {
		if (instances == null) {
			return null;
		}
		int datasize = size();
		List<T> bag = new ArrayList<T>(datasize);

		for (int i = 0; i < datasize; i++) {
			bag.add(instances.get(rng.nextInt(datasize)));
		}

		return new Data<T>(metaData, bag);
	}

	/**
	 * if data has N cases, sample N cases at random -but with replacement.
	 * 
	 * @param rng
	 * @param sampled
	 *            indicating which instance has been sampled
	 * 
	 * @return sampled data
	 */
	public Data<T> bagging(Random rng, boolean[] sampled) {
		if (instances == null) {
			return null;
		}
		int datasize = size();
		List<T> bag = new ArrayList<T>(datasize);

		for (int i = 0; i < datasize; i++) {
			int index = rng.nextInt(datasize);
			bag.add(instances.get(index));
			sampled[index] = true;
		}

		return new Data<T>(metaData, bag);
	}

	/**
	 * Splits the data in two, returns one part, and this gets the rest of the
	 * data. <b>VERY SLOW!</b>
	 * 
	 * @param rng
	 */
	public Data<T> rsplit(Random rng, int subsize) {
		if (instances == null) {
			return null;
		}
		List<T> subset = new ArrayList<T>(subsize);

		for (int i = 0; i < subsize; i++) {
			subset.add(instances.remove(rng.nextInt(instances.size())));
		}

		return new Data<T>(metaData, subset);
	}

	@Override
	public Data<T> clone() {
		if (instances == null) {
			return null;
		}
		ArrayList ins = new ArrayList(instances.size());
		Iterator<T> itr = instances.iterator();
		while (itr.hasNext()) {
			ins.add(itr.next().clone());
		}
		return new Data<T>(metaData, ins);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof Data)) {
			return false;
		}
		Data data = (Data) obj;
		return EqualsUtils.equals(instances, data.instances)
				&& EqualsUtils.equals(metaData, data.metaData);
	}

	@Override
	public int hashCode() {
		if (instances == null) {
			return 0;
		}
		return instances.hashCode() + metaData.hashCode();
	}

	public MetaData getMetaData() {
		return metaData;
	}

	public List<T> getInstances() {
		return instances;
	}

	public IDataIterator<T> toIterator() {
		if (instances == null) {
			return new IDataIterator<T>() {

				@Override
				public MetaData getMetaData() {
					return metaData;
				}

				@Override
				public boolean hasNext() {
					return false;
				}

				@Override
				public T next() {
					return null;
				}

				@Override
				public void remove() {

				}

				public void close() {

				}

				@Override
				public void reset() {

				}

				@Override
				public boolean isClosed() {
					return false;
				}
			};
		} else {
			return new IDataIterator<T>() {
				Iterator<T> itr = instances.iterator();

				@Override
				public MetaData getMetaData() {
					return metaData;
				}

				@Override
				public boolean hasNext() {
					return itr.hasNext();
				}

				@Override
				public T next() {
					return itr.next();
				}

				@Override
				public void remove() {
					itr.remove();
				}

				public void close() {

				}

				@Override
				public void reset() {
					itr = instances.iterator();
				}

				@Override
				public boolean isClosed() {
					return false;
				}
			};
		}
	}

	public void clear() {
		if (metaData != null) {
			metaData.destroy();
			metaData = null;
		}

		if (instances != null) {
			instances.clear();
			instances = null;
		}
	}
}
