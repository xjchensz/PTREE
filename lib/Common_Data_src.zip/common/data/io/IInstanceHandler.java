/**
 * 
 */
package common.data.io;

import common.data.instance.IInstance;

/**
 * @author xjc
 * 
 */
public interface IInstanceHandler<T extends IInstance> {

	public void handle(T instance);
}
