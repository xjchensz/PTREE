/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.indexed;

import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

import common.data.IIndexedDataIterator;
import common.data.instance.IInstance;
import common.data.io.SerializedDataConstants;
import common.data.io.SerializedDataInputStream;
import common.data.meta.MetaData;
import common.utils.DataIndex;
import common.utils.io.CountableInputStream;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class IndexedSerializedDataStreamReader<T extends IInstance> implements
		IIndexedDataIterator<T> {

	private Object lock = new Object();

	private MetaData metaData;
	protected CountableInputStream cis;
	protected long endDataPosition;
	private DataInputStream input;
	private T instance;

	private DataIndex di;

	public IndexedSerializedDataStreamReader(InputStream is) throws IOException {
		cis = new CountableInputStream(is);
		input = new DataInputStream(is);

		int flag = is.read();
		switch (flag) {
		case SerializedDataConstants.DATA:
			throw new IOException("No metadata and data index!");
		case SerializedDataConstants.META_DATA:
			throw new IOException("No data index!");
		case SerializedDataConstants.META_DATA_INDEX:
			// skip the size of metadata
			is.skip(SerializedDataInputStream.NBYTES_SIZE_FLAG);
			// read the size of data
			long dataSize = input.readLong();
			metaData = MetaData.readMetaData(input);
			endDataPosition = dataSize;
			input = new DataInputStream(cis);
			break;
		default:
			throw new IOException("Unknown data type: " + flag + "!");
		}
	}

	public DataIndex getDataIndex() {
		if (cis.getReadBytes() < endDataPosition) {
			throw new IllegalStateException("Unreach the data index!");
		}
		return di;
	}

	public MetaData getMetaData() {
		return metaData;
	}

	@Override
	public boolean hasNext() {
		synchronized (lock) {
			readInstance();
			return instance != null;
		}
	}

	@Override
	public T next() {
		synchronized (lock) {
			readInstance();
			T ret = instance;
			if (ret != null) {
				numRead++;
			}
			instance = null;
			return ret;
		}
	}

	private int numRead = 0;

	@Override
	public int numRead() {
		return numRead;
	}

	@Override
	public int numInstances() {
		return metaData.numInstances();
	}

	@Override
	public void skipTo(int newPosition) throws ArrayIndexOutOfBoundsException,
			IOException {
		skip(newPosition - numRead);
	}

	@Override
	public void skip(int numToSkip) throws ArrayIndexOutOfBoundsException,
			IOException {
		synchronized (lock) {
			if (numToSkip == 0) {
				return;
			}
			if (numToSkip < 0) {
				throw new IllegalArgumentException();
			}

			for (int i = 0; i < numToSkip; i++) {
				next();
			}
		}
	}

	@Override
	public T get(int index) throws ArrayIndexOutOfBoundsException, IOException,
			Exception {
		skipTo(index);
		synchronized (lock) {
			return next();
		}
	}

	private void readInstance() {
		if (instance == null) {
			if (cis.getReadBytes() < endDataPosition) {
				try {
					instance = (T) metaData.readInstance(input, null);
				} catch (IOException e) {
				}
			} else {
				if (di == null) {
					// read data index
					try {
						di = new DataIndex(cis);
					} catch (IOException e) {
					}
				}
			}
		}
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void reset() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void close() throws Exception {
		synchronized (lock) {
			if (input instanceof Closeable) {
				((Closeable) input).close();
			}
			input = null;
		}
	}

	@Override
	public boolean isClosed() {
		return input == null;
	}

}
