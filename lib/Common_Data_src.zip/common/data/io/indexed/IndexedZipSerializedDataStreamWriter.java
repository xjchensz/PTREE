/**
 * Created by Xiaojun Chen at 2012-3-23
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.indexed;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

import common.data.io.SerializedDataConstants;
import common.utils.io.ExtendedIOUtils;

/**
 * 
 * @author Xiaojun Chen
 * @version 1..0.0
 * 
 */
public class IndexedZipSerializedDataStreamWriter {

	public static final String META_INF = "META_INF";

	private InputStream is;

	public IndexedZipSerializedDataStreamWriter(InputStream is) {
		this.is = is;
	}

	private boolean write = false;

	public void writeTo(File file) throws IOException, ArchiveException {
		if (!file.exists()) {
			file.createNewFile();
		}
		FileOutputStream bos = new FileOutputStream(file);
		writeTo(bos);
	}

	public void writeTo(OutputStream os) throws IOException, ArchiveException {
		if (is != null) {
			if (write) {
				throw new IOException("Already write the input stream!");
			}
			writeOutputStream(os);
			write = true;
		}
	}

	private void writeOutputStream(OutputStream os) throws IOException,
			ArchiveException {

		ArchiveOutputStream zos = new ArchiveStreamFactory()
				.createArchiveOutputStream(ArchiveStreamFactory.ZIP,
						new BufferedOutputStream(os));
		int flag = is.read();
		switch (flag) {
		case SerializedDataConstants.DATA:
			throw new IOException("No metadata and data index!");
		case SerializedDataConstants.META_DATA:
			throw new IOException("No data index!");
		case SerializedDataConstants.META_DATA_INDEX:
			// read size of metadata and data
			DataInputStream dis = new DataInputStream(is);
			long metadataSize = dis.readLong();
			long dataSize = dis.readLong();

			// write meta_inf entry
			zos.putArchiveEntry(new ZipArchiveEntry(META_INF));
			DataOutputStream dos = new DataOutputStream(zos);
			dos.write(SerializedDataConstants.META_DATA_INDEX);
			dos.writeLong(metadataSize);
			dos.writeLong(dataSize);
			zos.closeArchiveEntry();

			// write metadata entry
			zos.putArchiveEntry(new ZipArchiveEntry(
					SerializedDataConstants.META_FILE));
			ExtendedIOUtils.copy(is, zos, metadataSize);
			zos.closeArchiveEntry();

			// write data entry
			zos.putArchiveEntry(new ZipArchiveEntry(
					SerializedDataConstants.DATA_FILE));
			ExtendedIOUtils.copy(is, zos, dataSize);
			zos.closeArchiveEntry();

			// write index entry
			zos.putArchiveEntry(new ZipArchiveEntry(
					SerializedDataConstants.INDEX_FILE));
			ExtendedIOUtils.copy(is, zos);
			zos.closeArchiveEntry();
			zos.close();
			dos.close();
			break;
		default:
			throw new IOException("Unknow data type!");
		}
	}

	public void close(boolean closeInputStream) throws IOException {
		if (is != null && closeInputStream) {
			try {
				is.close();
			} finally {
				is = null;
			}
		}
		is = null;
	}
}
