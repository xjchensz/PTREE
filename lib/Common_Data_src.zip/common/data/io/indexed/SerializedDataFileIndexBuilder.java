package common.data.io.indexed;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import common.data.instance.IInstance;
import common.data.io.SerializedDataConstants;
import common.data.io.SerializedDataFileReader;
import common.data.meta.MetaData;
import common.utils.DataIndex;
import common.utils.io.CountableInputStream;

public class SerializedDataFileIndexBuilder {

	private File dir;
	private DataIndex di;

	public SerializedDataFileIndexBuilder(File dir, int numInstanceOneBlock,
			boolean overide) throws Exception {
		this.dir = dir;
		if (!dir.isDirectory()) {
			throw new IllegalArgumentException("Directoyc required!");
		}

		File indexFile = SerializedDataConstants.indexFile(dir);
		if (indexFile.exists() && !overide) {
			return;
		}

		SerializedDataFileReader<?> reader = new SerializedDataFileReader(dir);
		MetaData metaData = reader.getMetaData();
		reader.close();
		CountableInputStream cis = new CountableInputStream(
				new FileInputStream(SerializedDataConstants.dataFile(dir)));

		DataInputStream dis = new DataInputStream(cis);
		IInstance ins = null;
		int index = 0;
		ArrayList<Long> ponters = new ArrayList<Long>();
		try {
			while (metaData.readInstance(dis, ins) != null) {
				if (++index % numInstanceOneBlock == 0) {
					ponters.add(cis.getReadBytes());
				}
			}
		} catch (Exception e) {

		}

		di = new DataIndex(index, numInstanceOneBlock, ponters);
	}

	/**
	 * write to the current directory
	 * 
	 * @throws IOException
	 * */
	public void writeTo() throws IOException {
		writeTo(dir);
	}

	/**
	 * write to the current directory
	 * 
	 * @throws IOException
	 * */
	public void writeTo(File dir) throws IOException {
		di.writeTo(SerializedDataConstants.indexFile(dir));
	}
}
