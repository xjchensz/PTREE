/**
 * Created by Xiaojun Chen at 2012-3-23
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.indexed;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Vector;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

import common.data.io.SerializedDataConstants;
import common.data.io.ZipSerializedDataWriter;
import common.utils.SimpleByteArrayInputStream;
import common.utils.SimpleByteArrayOutputStream;
import common.utils.io.UnCloseableInputStream;

/**
 * 
 * @author Xiaojun Chen
 * @version 1..0.0
 * 
 *          the structure of the input stream: FLAG
 *          (DATA/META_DATA/META_DATA_INDEX) if the FLAG is DATA, then the
 *          following part is only the data; if the FLAG is META_DATA, then the
 *          following is the size of metadata data, the metadata and the data;
 *          if the FLAG is META_DATA_INDEX, then the following part is the size
 *          of meta data, the size of data, the metadata, the data and the data
 *          index;
 */
public class IndexedSerializedDataInputStream extends InputStream {

	// the number of bytes of each size flag takes
	public static final int NBYTES_SIZE_FLAG = 8;

	private InputStream in;
	protected Enumeration<InputStream> emr;

	protected IndexedSerializedDataInputStream() {

	}

	/**
	 * if f is directory, then will read the files in the directory to construct
	 * the inputStream; if f is a file, then will read the zip file
	 * 
	 * @throws ArchiveException
	 * */
	public IndexedSerializedDataInputStream(File f) throws IOException,
			ArchiveException {
		if (f.isDirectory()) {
			fileInputStream(f);
		} else {
			zipInputStream(f);
		}
	}

	private void fileInputStream(File directory) throws IOException {
		// metadata
		File metaFile = SerializedDataConstants.metaDataFile(directory);
		InputStream mfs = new BufferedInputStream(new FileInputStream(metaFile));
		long metaSize = mfs.available();

		// data
		File dataFile = SerializedDataConstants.dataFile(directory);
		InputStream dfs = new BufferedInputStream(new FileInputStream(dataFile));
		long dataSize = dfs.available();

		// flag+length flag
		SimpleByteArrayOutputStream bo = new SimpleByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bo);
		dos.writeByte(SerializedDataConstants.META_DATA_INDEX);
		// size of metadata
		dos.writeLong(metaSize);
		// size of data
		dos.writeLong(dataSize);
		SimpleByteArrayInputStream flagInputStream = new SimpleByteArrayInputStream(
				bo);

		// data index
		File indexFile = SerializedDataConstants.indexFile(directory);
		InputStream ifs = new BufferedInputStream(
				new FileInputStream(indexFile));

		Vector<InputStream> vector = new Vector<InputStream>(4);
		vector.add(flagInputStream);
		vector.add(mfs);
		vector.add(dfs);
		vector.add(ifs);
		setInputStreams(vector.elements());
	}

	/**
	 * zip input stream
	 * 
	 * @throws ArchiveException
	 * */
	private void zipInputStream(File zipFile) throws IOException,
			ArchiveException {
		final ArchiveInputStream ais = new ArchiveStreamFactory()
				.createArchiveInputStream(ArchiveStreamFactory.ZIP,
						new BufferedInputStream(new FileInputStream(zipFile)));

		// meta_inf
		ZipArchiveEntry entry = (ZipArchiveEntry) ais.getNextEntry();
		if (!ZipSerializedDataWriter.META_INF.equals(entry.getName())) {
			throw new IOException("No meta_inf!");
		}
		DataInputStream input = new DataInputStream(ais);
		long metaSize = input.readLong();
		long dataSize = input.readLong();
		SimpleByteArrayOutputStream bo1 = new SimpleByteArrayOutputStream();
		DataOutputStream dos1 = new DataOutputStream(bo1);
		dos1.writeByte(SerializedDataConstants.META_DATA_INDEX);
		dos1.writeLong(metaSize);
		dos1.writeLong(dataSize);
		final SimpleByteArrayInputStream flagInputStream = new SimpleByteArrayInputStream(
				bo1);

		setInputStreams(new Enumeration<InputStream>() {
			// -1:end, 0: flag, 1: meta, 2: data 3: data index
			byte flag = 0;

			@Override
			public boolean hasMoreElements() {
				switch (flag) {
				case 0:
				case 1:
				case 2:
				case 3:
					return true;
				case -1:
				default:
					return false;
				}
			}

			@Override
			public InputStream nextElement() {
				switch (flag) {
				case 0:
					flag++;
					return flagInputStream;
				case 1:
					flag++;
					// meta
					try {
						ZipArchiveEntry me = (ZipArchiveEntry) ais
								.getNextEntry();
						if (!SerializedDataConstants.META_FILE.equals(me
								.getName())) {
							throw new IOException("No metadata!");
						}
						return new UnCloseableInputStream(ais);
					} catch (IOException e) {
						return null;
					}
				case 2:
					flag++;
					// data
					try {
						ZipArchiveEntry de = (ZipArchiveEntry) ais
								.getNextEntry();
						if (!SerializedDataConstants.DATA_FILE.equals(de
								.getName())) {
							throw new IOException("No data!");
						}
						return new UnCloseableInputStream(ais);
					} catch (IOException e) {
						return null;
					}
				case 3:
					flag = -1;
					// data index
					try {
						ZipArchiveEntry de = (ZipArchiveEntry) ais
								.getNextEntry();
						if (!SerializedDataConstants.INDEX_FILE.equals(de
								.getName())) {
							throw new IOException("No data!");
						}
						return ais;
					} catch (IOException e) {
						return null;
					}
				case -1:
				default:
					return null;
				}
			}
		});
	}

	private void setInputStreams(Enumeration<InputStream> emr) {
		this.emr = emr;
		in = emr.nextElement();
	}

	/**
	 * Continues reading in the next stream if an EOF is reached.
	 */
	final void nextStream() throws IOException {
		if (in != null) {
			in.close();
		}

		if (emr.hasMoreElements()) {
			in = emr.nextElement();
		} else
			in = null;
	}

	public int read() throws IOException {
		if (in == null) {
			return -1;
		}
		int c = in.read();
		if (c == -1) {
			nextStream();
			return read();
		}
		return c;
	}

	public int read(byte b[], int off, int len) throws IOException {
		if (in == null) {
			return -1;
		} else if (b == null) {
			throw new NullPointerException();
		} else if (off < 0 || len < 0 || len > b.length - off) {
			throw new IndexOutOfBoundsException();
		} else if (len == 0) {
			return 0;
		}

		int n = in.read(b, off, len);
		if (n <= 0) {
			nextStream();
			return read(b, off, len);
		}
		return n;
	}

	public int available() throws IOException {
		return 0; // no way to signal EOF from available()
	}

	public void close() throws IOException {
		do {
			nextStream();
		} while (in != null);
	}

}
