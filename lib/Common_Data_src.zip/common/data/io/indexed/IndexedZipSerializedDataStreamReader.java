/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.indexed;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

import common.data.IIndexedDataIterator;
import common.data.instance.IInstance;
import common.data.io.SerializedDataConstants;
import common.data.io.ZipSerializedDataWriter;
import common.data.meta.MetaData;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class IndexedZipSerializedDataStreamReader<T extends IInstance>
		implements IIndexedDataIterator<T> {

	public static final int NUM_TO_ITERATE_SKIP = 20;

	private Object lock = new Object();

	private ArchiveInputStream ais;
	private DataInputStream dataIs;
	private MetaData metaData = null;

	public IndexedZipSerializedDataStreamReader(InputStream in)
			throws IOException, ArchiveException {
		ais = new ArchiveStreamFactory().createArchiveInputStream(
				ArchiveStreamFactory.ZIP, new BufferedInputStream(in));
		DataInputStream input = new DataInputStream(ais);

		// read meta_inf
		ZipArchiveEntry entry = (ZipArchiveEntry) ais.getNextEntry();
		if (ZipSerializedDataWriter.META_INF.equals(entry.getName())) {
			switch (input.read()) {
			case SerializedDataConstants.DATA:
				throw new IOException("No metadata and data index!");
			case SerializedDataConstants.META_DATA:
				throw new IOException("No data index!");
			case SerializedDataConstants.META_DATA_INDEX:
				break;
			default:
				throw new IOException("Unknown data type!");
			}
		}

		// read metadata
		entry = (ZipArchiveEntry) ais.getNextEntry();
		if (entry.getName().equals(SerializedDataConstants.META_FILE)) {
			metaData = MetaData.readMetaData(input);
		}

		if (metaData == null) {
			throw new IOException("No metaData!");
		}

		// read data
		ais.getNextEntry();
		dataIs = new DataInputStream(ais);

	}

	private T instance;

	public MetaData getMetaData() {
		return metaData;
	}

	private int numRead = 0;

	@Override
	public int numRead() {
		return numRead;
	}

	@Override
	public int numInstances() {
		return metaData.numInstances();
	}

	@Override
	public boolean hasNext() {
		synchronized (lock) {
			readInstance();
			return instance != null;
		}
	}

	@Override
	public T next() {
		synchronized (lock) {
			readInstance();
			T ret = instance;
			if (ret != null) {
				numRead++;
			}
			instance = null;
			return ret;
		}
	}

	private void readInstance() {
		if (instance == null) {
			try {
				instance = (T) metaData.readInstance(dataIs, null);
			} catch (IOException e) {
			}
		}
	}

	@Override
	public void close() throws Exception {
		synchronized (lock) {
			dataIs.close();
			dataIs = null;
		}
	}

	@Override
	public boolean isClosed() {
		return dataIs == null;
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void reset() throws ArchiveException, IOException {
		throw new UnsupportedOperationException();
	}

	@Override
	public void skipTo(int newPosition) throws ArrayIndexOutOfBoundsException,
			IOException, ArchiveException {

		if (newPosition == numRead) {
			// do nothing
			return;
		}
		skip(newPosition - numRead);
	}

	@Override
	public void skip(int numToSkip) throws ArrayIndexOutOfBoundsException,
			IOException, ArchiveException {
		synchronized (lock) {
			if (numToSkip < 0) {
				throw new ArrayIndexOutOfBoundsException(
						"The number to skip should be more thant zero!");
			}
			for (int i = 0; i < numToSkip; i++) {
				next();
			}
		}
	}

	@Override
	public synchronized T get(int index) throws ArrayIndexOutOfBoundsException,
			IOException, Exception {
		skipTo(index);
		synchronized (lock) {
			return next();
		}
	}

}
