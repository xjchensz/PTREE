/**
 * Created by Xiaojun Chen at 2012-3-27
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.indexed;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.SequenceInputStream;
import java.util.Enumeration;

import common.data.IndexedInputStream;
import common.data.instance.IInstance;
import common.data.io.SerializedDataConstants;
import common.data.meta.MetaData;
import common.utils.DataIndex;
import common.utils.IndexItem;
import common.utils.SimpleByteArrayInputStream;
import common.utils.SimpleByteArrayOutputStream;
import common.utils.io.BufferedRandomAccessFile;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class SerializedDataFileIndexedInputStream implements IndexedInputStream {

	public static final int NUM_TO_ITERATE_SKIP = 20;

	private boolean closed = false;

	private DataIndex di;

	private MetaData metaData;
	protected BufferedRandomAccessFile braf;
	private SimpleByteArrayOutputStream flagMetaOS;

	public SerializedDataFileIndexedInputStream(File directory)
			throws IOException {
		DataInputStream input = null;
		// metadata
		try {
			input = new DataInputStream(new FileInputStream(
					SerializedDataConstants.metaDataFile(directory)));
			metaData = MetaData.readMetaData(input);
			flagMetaOS = new SimpleByteArrayOutputStream();
			DataOutputStream dos = new DataOutputStream(flagMetaOS);
			metaData.write(dos);
			long metaSize = dos.size();
			flagMetaOS.reset();
			dos.writeByte(SerializedDataConstants.META_DATA);
			dos.writeLong(metaSize);
			metaData.write(dos);
		} finally {
			if (input != null) {
				input.close();
			}
		}
		// data index
		di = new DataIndex(SerializedDataConstants.indexFile(directory));
		// data
		braf = new BufferedRandomAccessFile(
				SerializedDataConstants.dataFile(directory), "r");
	}

	@Override
	public InputStream subInputStream(final int rowStart, final int rowEnd)
			throws IOException {
		checkUnClosed();
		if (rowStart < 0 || rowEnd > di.numInstances() || rowStart > rowEnd) {
			throw new ArrayIndexOutOfBoundsException();
		}

		IndexItem it = di.getPosition(rowStart);
		int rowIndex = it.rowIndex;
		braf.seek(it.position);
		skipInstances(rowStart - rowIndex);
		// construct stream
		final SimpleByteArrayInputStream flagMetaInputStream = new SimpleByteArrayInputStream(
				flagMetaOS);

		final SimpleByteArrayOutputStream bo = new SimpleByteArrayOutputStream();
		final DataOutputStream dos = new DataOutputStream(bo);
		final SimpleByteArrayInputStream bis = new SimpleByteArrayInputStream(
				bo);
		return new SequenceInputStream(new Enumeration<InputStream>() {

			private boolean readMeta = false;
			private int rowIndex = rowStart;

			@Override
			public boolean hasMoreElements() {
				return rowIndex < rowEnd;
			}

			@Override
			public InputStream nextElement() {
				if (!readMeta) {
					readMeta = true;
					return flagMetaInputStream;
				} else if (rowIndex < rowEnd) {
					bo.reset();
					try {
						IInstance instance = metaData.readInstance(braf, null);
						instance.write(dos);
						instance.destroy();
						bis.reset(bo);
						return bis;
					} catch (IOException e) {
						return null;
					}
				} else {
					return null;
				}
			}
		});
	}

	private void skipInstances(int n) throws IOException {
		while (n-- > 0) {
			metaData.readInstance(braf, null).destroy();
		}
	}

	@Override
	public void close() {
		if (closed) {
			return;
		}
		try {
			braf.close();
		} catch (IOException e) {
		}
	}

	private void checkUnClosed() throws IOException {
		if (this.closed) {
			throw new IOException("Closed!");
		}
	}

}
