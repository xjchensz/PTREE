/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.indexed;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import common.data.io.SerializedDataConstants;
import common.utils.io.ExtendedIOUtils;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class IndexedSerializedDataStreamWriter {

	private InputStream is;

	public IndexedSerializedDataStreamWriter(InputStream is) {
		this.is = is;
	}

	private boolean write = false;

	// directory contains: meta.dsd, data.dsd, index.idx
	public void writeToFiles(File directory) throws IOException {
		if (is != null) {
			if (write) {
				throw new IOException("Already write the input stream!");
			}
			writeOutputStream(directory);
			write = true;
		}
	}

	private void writeOutputStream(File directory) throws IOException {
		int flag = is.read();
		BufferedOutputStream output = null;
		switch (flag) {
		case SerializedDataConstants.DATA:
			// write data
			try {
				File dataFile = SerializedDataConstants.dataFile(directory);
				dataFile.createNewFile();
				output = new BufferedOutputStream(
						new FileOutputStream(dataFile));
				ExtendedIOUtils.copy(is, output);
			} finally {
				if (output != null) {
					output.close();
				}
				is.close();
			}

		case SerializedDataConstants.META_DATA:
			// read size of metadata
			DataInputStream dis = new DataInputStream(is);
			long metadataSize = dis.readLong();

			// write metadata
			try {
				File metaFile = SerializedDataConstants.metaDataFile(directory);
				metaFile.createNewFile();
				output = new BufferedOutputStream(
						new FileOutputStream(metaFile));
				ExtendedIOUtils.copy(is, output, metadataSize);
			} finally {
				if (output != null) {
					output.close();
				}
			}

			// write data
			try {
				File dataFile = SerializedDataConstants.dataFile(directory);
				dataFile.createNewFile();
				output = new BufferedOutputStream(
						new FileOutputStream(dataFile));
				ExtendedIOUtils.copy(is, output);
			} finally {
				if (output != null) {
					output.close();
				}
			}
			break;
		case SerializedDataConstants.META_DATA_INDEX:
			// read size of metadata and data
			dis = new DataInputStream(is);
			metadataSize = dis.readLong();
			long dataSize = dis.readLong();

			// write metadata
			try {
				File metaFile = SerializedDataConstants.metaDataFile(directory);
				metaFile.createNewFile();
				output = new BufferedOutputStream(
						new FileOutputStream(metaFile));
				ExtendedIOUtils.copy(is, output, metadataSize);
			} finally {
				if (output != null) {
					output.close();
				}
			}

			// write data
			try {
				File dataFile = SerializedDataConstants.dataFile(directory);
				dataFile.createNewFile();
				output = new BufferedOutputStream(
						new FileOutputStream(dataFile));
				ExtendedIOUtils.copy(is, output, dataSize);
			} finally {
				if (output != null) {
					output.close();
				}
			}

			// write data index
			try {
				File dataIndexFile = SerializedDataConstants
						.indexFile(directory);
				dataIndexFile.createNewFile();
				output = new BufferedOutputStream(new FileOutputStream(
						dataIndexFile));
				ExtendedIOUtils.copy(is, output);
			} finally {
				if (output != null) {
					output.close();
				}
			}
			break;
		}
	}

	public void close() throws IOException {
		try {
			is.close();
		} finally {
			is = null;
		}
	}
}
