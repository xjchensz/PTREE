/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.indexed;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.data.io.SerializedDataConstants;
import common.data.meta.MetaData;
import common.utils.SimpleByteArrayOutputStream;
import common.utils.io.IndexedBufferedRandomAccessFile;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class IndexedSerializedDataWriter {

	private IDataIterator<? extends IInstance> dataIterator;

	public IndexedSerializedDataWriter(
			IDataIterator<? extends IInstance> dataIterator) {
		this.dataIterator = dataIterator;
	}

	public void writeToDirectory(File directory) throws IOException {
		writeToDirectory(directory, false);
	}

	// directory contains: meta.dsd, data.dsd, index.idx
	public void writeToDirectory(File directory, boolean closeInstance)
			throws IOException {
		if (dataIterator == null) {
			throw new NullPointerException();
		}

		if (!directory.exists()) {
			directory.mkdirs();
		}

		// write metadata
		DataOutputStream output = null;
		try {
			File metaFile = SerializedDataConstants.metaDataFile(directory);
			if (metaFile.exists()) {
				metaFile.delete();
			}
			metaFile.createNewFile();

			output = new DataOutputStream(new BufferedOutputStream(
					new FileOutputStream(metaFile)));
			dataIterator.getMetaData().write(output);
		} finally {
			if (output != null) {
				output.close();
			}
		}

		// write data
		IndexedBufferedRandomAccessFile brfile = null;
		try {
			File dataFile = SerializedDataConstants.dataFile(directory);
			if (dataFile.exists()) {
				dataFile.delete();
			}
			dataFile.createNewFile();

			brfile = new IndexedBufferedRandomAccessFile(dataFile, "rw");
			brfile.start();
			IInstance ins;
			if (closeInstance) {
				while (dataIterator.hasNext()) {
					(ins = dataIterator.next()).write(brfile);
					ins.destroy();
					brfile.finishOneRecord();
				}
			} else {
				while (dataIterator.hasNext()) {
					dataIterator.next().write(brfile);
					brfile.finishOneRecord();
				}
			}
			brfile.finish();

			// write data index
			File indexFile = SerializedDataConstants.indexFile(directory);
			if (indexFile.exists()) {
				indexFile.delete();
			}
			indexFile.createNewFile();
			brfile.getDataIndex().writeTo(indexFile);

		} finally {
			if (brfile != null) {
				brfile.close();
			}
		}
	}

	public void writeToOutputStream(OutputStream out) throws IOException {
		writeToOutputStream(out, false);
	}

	/**
	 * write SerializedDataConstants.META_DATA type of data
	 * */
	public void writeToOutputStream(OutputStream out, boolean closeInstance)
			throws IOException {
		final SimpleByteArrayOutputStream bo1 = new SimpleByteArrayOutputStream();
		final DataOutputStream dos1 = new DataOutputStream(bo1);
		dataIterator.getMetaData().write(dos1);

		// write flag
		DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(
				out));
		dos.write(SerializedDataConstants.META_DATA);
		dos.writeLong(dos1.size());

		// write metadata
		dataIterator.getMetaData().write(dos);
		// write data
		if (closeInstance) {
			IInstance ins;
			while (dataIterator.hasNext()) {
				(ins = dataIterator.next()).write(dos);
				ins.destroy();
			}
		} else {
			while (dataIterator.hasNext()) {
				dataIterator.next().write(dos);
			}
		}

		dos.close();
	}

	public void updateMetaData(MetaData metaData, File directory)
			throws IOException {
		if (directory == null | !directory.exists() || directory.isFile()) {
			throw new IllegalArgumentException();
		}

		// write metadata
		DataOutputStream output = null;
		try {
			File metaFile = SerializedDataConstants.metaDataFile(directory);
			if (metaFile.exists()) {
				metaFile.delete();
			}

			output = new DataOutputStream(new BufferedOutputStream(
					new FileOutputStream(metaFile)));
			metaData.write(output);
		} finally {
			if (output != null) {
				output.close();
			}
		}
	}

	public void close() throws Exception {
		close(false);
	}

	public void close(boolean closeDataIterator) throws Exception {
		if (dataIterator != null) {
			try {
				if (closeDataIterator) {
					dataIterator.close();
				}
			} finally {
				dataIterator = null;
			}
		}
	}

}
