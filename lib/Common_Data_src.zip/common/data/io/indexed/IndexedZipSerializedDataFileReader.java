/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.indexed;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

import common.data.IIndexedDataIterator;
import common.data.instance.IInstance;
import common.data.io.SerializedDataConstants;
import common.data.io.ZipSerializedDataWriter;
import common.data.meta.MetaData;
import common.utils.DataIndex;
import common.utils.IndexItem;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class IndexedZipSerializedDataFileReader<T extends IInstance> implements
		IIndexedDataIterator<T> {

	private Object lock = new Object();

	public static final int NUM_TO_ITERATE_SKIP = 20;

	private File zipFile;
	private ArchiveInputStream ais;
	private DataInputStream dataIs;
	private MetaData metaData = null;

	private DataIndex di;

	public IndexedZipSerializedDataFileReader(File zipFile) throws IOException,
			ArchiveException {
		this.zipFile = zipFile;
		ais = new ArchiveStreamFactory().createArchiveInputStream(
				ArchiveStreamFactory.ZIP, new BufferedInputStream(
						new FileInputStream(zipFile)));
		DataInputStream input = new DataInputStream(ais);

		// read meta_inf
		ZipArchiveEntry entry = (ZipArchiveEntry) ais.getNextEntry();
		if (ZipSerializedDataWriter.META_INF.equals(entry.getName())) {
			switch (input.read()) {
			case SerializedDataConstants.DATA:
				throw new IOException("No metadata!");
			case SerializedDataConstants.META_DATA:
			case SerializedDataConstants.META_DATA_INDEX:
				break;
			default:
				throw new IOException("Unknown data type!");
			}
		}

		// read metadata
		entry = (ZipArchiveEntry) ais.getNextEntry();
		if (entry.getName().equals(SerializedDataConstants.META_FILE)) {
			metaData = MetaData.readMetaData(input);
		}

		if (metaData == null) {
			throw new IOException("No metaData!");
		}

		// read data index
		ais.getNextEntry();
		entry = (ZipArchiveEntry) ais.getNextEntry();
		if (entry != null
				&& SerializedDataConstants.INDEX_FILE.equals(entry.getName())) {
			di = new DataIndex(input);
		}

		reset();
	}

	private T instance;

	public MetaData getMetaData() {
		return metaData;
	}

	private int numRead = 0;

	@Override
	public int numRead() {
		return numRead;
	}

	@Override
	public int numInstances() {
		return metaData.numInstances();
	}

	@Override
	public boolean hasNext() {
		synchronized (lock) {
			readInstance();
			return instance != null;
		}
	}

	@Override
	public T next() {
		synchronized (lock) {
			readInstance();
			T ret = instance;
			if (ret != null) {
				numRead++;
			}
			instance = null;
			return ret;
		}
	}

	private void readInstance() {
		if (instance == null) {
			try {
				instance = (T) metaData.readInstance(dataIs, null);
			} catch (IOException e) {
			}
		}
	}

	@Override
	public void close() throws Exception {
		synchronized (lock) {
			dataIs.close();
			dataIs = null;
		}
	}

	@Override
	public boolean isClosed() {
		return dataIs == null;
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void reset() throws ArchiveException, IOException {
		synchronized (lock) {
			numRead = 0;
			ais.close();
			ais = new ArchiveStreamFactory().createArchiveInputStream(
					ArchiveStreamFactory.ZIP, new BufferedInputStream(
							new FileInputStream(zipFile)));
			// skip two entries
			ais.getNextEntry();
			ais.getNextEntry();
			// data entry
			ais.getNextEntry();
			dataIs = new DataInputStream(ais);
		}
	}

	@Override
	public void skipTo(int newPosition) throws ArrayIndexOutOfBoundsException,
			IOException, ArchiveException {
		synchronized (lock) {
			if (newPosition == numRead) {
				// do nothing
				return;
			}
			if (di != null) {
				int numToSkip = newPosition - numRead;
				if (numToSkip > 0 && numToSkip < NUM_TO_ITERATE_SKIP) {
					iterateSkip(numToSkip);
				} else {
					resetSkip(newPosition);
				}
			} else {
				if (newPosition > numRead) {
					iterateSkip(newPosition - numRead);
				} else {
					reset();
					iterateSkip(newPosition);
				}
			}
		}
	}

	@Override
	public void skip(int numToSkip) throws ArrayIndexOutOfBoundsException,
			IOException, ArchiveException {
		skipTo(numRead + numToSkip);
	}

	@Override
	public synchronized T get(int index) throws ArrayIndexOutOfBoundsException,
			IOException, Exception {
		skipTo(index);
		synchronized (lock) {
			return next();
		}
	}

	protected void resetSkip(int newPosition) throws IOException,
			ArchiveException {
		// start again
		reset();
		IndexItem it = di.getPosition(newPosition);
		numRead = it.rowIndex;
		ais.skip(it.position);
		iterateSkip(newPosition - numRead);
	}

	protected void iterateSkip(int numToSkip) throws IOException {
		if (numToSkip < 0) {
			throw new ArrayIndexOutOfBoundsException(
					"The number to skip should be more thant zero!");
		}
		for (int i = 0; i < numToSkip; i++) {
			next();
		}
	}

}
