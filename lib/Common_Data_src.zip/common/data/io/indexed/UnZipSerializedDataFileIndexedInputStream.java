/**
 * Created by Xiaojun Chen at 2012-3-27
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.indexed;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.SequenceInputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;

import common.data.IndexedInputStream;
import common.data.instance.IInstance;
import common.data.io.SerializedDataConstants;
import common.data.io.ZipSerializedDataWriter;
import common.data.meta.MetaData;
import common.utils.DataIndex;
import common.utils.IndexItem;
import common.utils.SimpleByteArrayInputStream;
import common.utils.SimpleByteArrayOutputStream;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class UnZipSerializedDataFileIndexedInputStream implements
		IndexedInputStream {

	public static final int NUM_TO_ITERATE_SKIP = 20;

	private boolean closed = false;

	private File zipFile;
	private DataIndex di;

	private MetaData metaData;
	private SimpleByteArrayOutputStream flagMetaOS;
	private DataInputStream input;

	public UnZipSerializedDataFileIndexedInputStream(File zipFile)
			throws IOException, ArchiveException {
		this.zipFile = zipFile;
		// metadata
		try {

			ArchiveInputStream ais = new ArchiveStreamFactory()
					.createArchiveInputStream(ArchiveStreamFactory.ZIP,
							new BufferedInputStream(
									new FileInputStream(zipFile)));
			// read meta_inf
			ZipEntry entry = (ZipEntry) ais.getNextEntry();
			if (!ZipSerializedDataWriter.META_INF.equals(entry.getName())) {
				throw new IOException("No meta_inf entry!");
			}
			input = new DataInputStream(ais);
			if (input.readByte() != SerializedDataConstants.META_DATA_INDEX) {
				throw new IOException(
						"The data type should be META_DATA_INDEX!");
			}
			// read metadata
			ais.getNextEntry();
			metaData = MetaData.readMetaData(input);

			flagMetaOS = new SimpleByteArrayOutputStream();
			DataOutputStream dos = new DataOutputStream(flagMetaOS);
			metaData.write(dos);
			long metaSize = dos.size();
			flagMetaOS.reset();
			dos.writeByte(SerializedDataConstants.META_DATA);
			dos.writeLong(metaSize);
			metaData.write(dos);

			// skip data
			ais.getNextEntry();
			// data index
			ais.getNextEntry();
			di = new DataIndex(input);

			ais.close();
		} finally {
			if (input != null) {
				input.close();
				input = null;
			}
		}
	}

	@Override
	public InputStream subInputStream(final int rowStart, final int rowEnd)
			throws IOException, ArchiveException {
		checkUnClosed();
		if (rowStart < 0 || rowEnd > di.numInstances() || rowStart > rowEnd) {
			throw new ArrayIndexOutOfBoundsException();
		}
		if (input != null) {
			input.close();
		}

		// reposition to data
		ArchiveInputStream ais = new ArchiveStreamFactory()
				.createArchiveInputStream(ArchiveStreamFactory.ZIP,
						new BufferedInputStream(new FileInputStream(zipFile)));
		input = new DataInputStream(ais);

		// skip meta_inf
		ais.getNextEntry();
		// skip metadata
		ais.getNextEntry();
		// data
		ais.getNextEntry();

		IndexItem it = di.getPosition(rowStart);
		int rowIndex = it.rowIndex;
		ais.skip(it.position);
		skipInstances(rowStart - rowIndex);
		// construct stream
		final SimpleByteArrayInputStream flagMetaInputStream = new SimpleByteArrayInputStream(
				flagMetaOS);

		final SimpleByteArrayOutputStream bo = new SimpleByteArrayOutputStream();
		final DataOutputStream dos = new DataOutputStream(bo);
		final SimpleByteArrayInputStream bis = new SimpleByteArrayInputStream(
				bo);
		return new SequenceInputStream(new Enumeration<InputStream>() {

			private boolean readMeta = false;
			private int rowIndex = rowStart;

			@Override
			public boolean hasMoreElements() {
				return rowIndex < rowEnd;
			}

			@Override
			public InputStream nextElement() {
				if (!readMeta) {
					readMeta = true;
					return flagMetaInputStream;
				} else if (rowIndex < rowEnd) {
					bo.reset();
					try {
						IInstance instance = metaData.readInstance(input, null);
						instance.write(dos);
						instance.destroy();
						bis.reset(bo);
						return bis;
					} catch (IOException e) {
						return null;
					}
				} else {
					return null;
				}
			}
		});
	}

	private void skipInstances(int n) throws IOException {
		while (n-- > 0) {
			metaData.readInstance(input, null).destroy();
		}
	}

	@Override
	public void close() {
		if (closed) {
			return;
		}
		try {
			if (input != null) {
				input.close();
			}
		} catch (IOException e) {
		}
	}

	private void checkUnClosed() throws IOException {
		if (this.closed) {
			throw new IOException("Closed!");
		}
	}

}
