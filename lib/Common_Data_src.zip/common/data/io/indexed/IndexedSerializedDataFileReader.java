package common.data.io.indexed;

import java.io.File;
import java.io.IOException;

import common.data.IIndexedDataIterator;
import common.data.instance.IInstance;
import common.data.io.SerializedDataConstants;
import common.data.io.SerializedDataFileReader;
import common.utils.DataIndex;
import common.utils.IndexItem;

public class IndexedSerializedDataFileReader<T extends IInstance> extends
		SerializedDataFileReader<T> implements IIndexedDataIterator<T> {

	private Object lock = new Object();

	public static final int NUM_TO_ITERATE_SKIP = 20;

	private DataIndex di;

	private int numRead;
	private int limit = Integer.MAX_VALUE;

	public IndexedSerializedDataFileReader(File directory) throws IOException,
			InstantiationException, IllegalAccessException,
			ClassNotFoundException {
		super(directory);

		// data index
		File indexFile = SerializedDataConstants.indexFile(directory);
		if (indexFile.exists()) {
			di = new DataIndex(indexFile);
		}
	}

	@Override
	public int numRead() {
		return numRead;
	}

	@Override
	public int numInstances() {
		return getMetaData().numInstances();
	}

	@Override
	public void reset() throws IOException {
		synchronized (lock) {
			numRead = 0;
			super.reset();
		}
	}

	@Override
	public T next() {
		synchronized (lock) {
			T ret = super.next();
			if (ret != null) {
				numRead++;
			}
			return ret;
		}
	}

	protected void readInstance() {
		if (numRead >= limit) {

		} else {
			super.readInstance();
		}
	}

	@Override
	public void skipTo(int newPosition) throws ArrayIndexOutOfBoundsException,
			IOException {
		synchronized (lock) {
			if (newPosition == numRead) {
				// do nothing
				return;
			}
			if (di != null) {
				int numToSkip = newPosition - numRead;
				if (numToSkip > 0 && numToSkip < NUM_TO_ITERATE_SKIP) {
					iterateSkip(numToSkip);
				} else {
					resetSkip(newPosition);
				}
			} else {
				if (newPosition > numRead) {
					iterateSkip(newPosition - numRead);
				} else {
					reset();
					iterateSkip(newPosition);
				}
			}
		}
	}

	@Override
	public void skip(int numToSkip) throws ArrayIndexOutOfBoundsException,
			IOException {
		skipTo(numRead + numToSkip);
	}

	@Override
	public synchronized T get(int index) throws ArrayIndexOutOfBoundsException,
			IOException, Exception {
		skipTo(index);
		synchronized (lock) {
			return next();
		}
	}

	public void limit(int limit) {
		this.limit = limit;
	}

	protected void resetSkip(int newPosition) throws IOException {
		if (newPosition > limit) {
			throw new ArrayIndexOutOfBoundsException("Outof limit!");
		}
		// start again
		IndexItem it = di.getPosition(newPosition);
		numRead = it.rowIndex;
		braf.seek(it.position);
		iterateSkip(newPosition - numRead);
	}

	protected void iterateSkip(int numToSkip) throws IOException {
		if (numToSkip < 0) {
			throw new ArrayIndexOutOfBoundsException(
					"The number to skip should be more thant zero!");
		}
		if (numRead + numToSkip > limit) {
			throw new ArrayIndexOutOfBoundsException("Outof limit!");
		}
		for (int i = 0; i < numToSkip; i++) {
			next();
		}
	}

}
