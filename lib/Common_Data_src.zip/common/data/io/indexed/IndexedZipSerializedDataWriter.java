/**
 * Created by Xiaojun Chen at 2012-3-23
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.indexed;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.data.io.SerializedDataConstants;
import common.data.io.ZipSerializedDataWriter;
import common.utils.DataIndex;
import common.utils.io.IndexedBigDataOutputStream;
import common.utils.io.NullOutputStream;

/**
 * 
 * @author Xiaojun Chen
 * @version 1.0.0
 * 
 */
public class IndexedZipSerializedDataWriter {

	private IDataIterator<? extends IInstance> dataIterator;

	public IndexedZipSerializedDataWriter(
			IDataIterator<? extends IInstance> dataIterator) throws Exception {
		this.dataIterator = dataIterator;
	}

	public void writeToFile(File file) throws Exception {
		writeToFile(file, false);
	}

	public void writeToFile(File file, boolean closeInstance) throws Exception {
		if (dataIterator == null) {
			throw new NullPointerException("Empty data!");
		}
		if (!file.exists()) {
			file.createNewFile();
		}

		FileOutputStream fos = new FileOutputStream(file);
		try {
			writeToOutputStream(fos, closeInstance);
		} finally {
			fos.close();
		}
	}

	public void writeToOutputStream(OutputStream os) throws IOException,
			ArchiveException, Exception {
		writeToOutputStream(os, false);
	}

	public void writeToOutputStream(OutputStream os, boolean closeInstance)
			throws IOException, ArchiveException, Exception {
		DataOutputStream dos = new DataOutputStream(new NullOutputStream());
		dataIterator.getMetaData().write(dos);
		int metaSize = dos.size();

		IndexedBigDataOutputStream bdo = new IndexedBigDataOutputStream(
				new NullOutputStream());
		bdo.start();
		if (closeInstance) {
			IInstance ins;
			while (dataIterator.hasNext()) {
				(ins = dataIterator.next()).write(bdo);
				ins.destroy();
				bdo.finishOneRecord();
			}
		} else {
			while (dataIterator.hasNext()) {
				dataIterator.next().write(bdo);
				bdo.finishOneRecord();
			}
		}

		bdo.finish();

		long dataSize = bdo.size();
		DataIndex di = bdo.getDataIndex();
		bdo.close();

		writeToOutputStream(os, di, metaSize, dataSize, closeInstance);
	}

	protected void writeToOutputStream(OutputStream os, DataIndex di,
			int metaSize, long dataSize, boolean closeInstance)
			throws Exception {
		if (dataIterator == null) {
			throw new NullPointerException("Empty data!");
		}
		dataIterator.reset();

		ArchiveOutputStream zos = new ArchiveStreamFactory()
				.createArchiveOutputStream(ArchiveStreamFactory.ZIP,
						new BufferedOutputStream(os));

		// write meta_inf entry
		DataOutputStream dos = new DataOutputStream(zos);
		zos.putArchiveEntry(new ZipArchiveEntry(
				ZipSerializedDataWriter.META_INF));
		dos.write(SerializedDataConstants.META_DATA_INDEX);
		dos.writeLong(metaSize);
		dos.writeLong(dataSize);
		zos.closeArchiveEntry();

		// write metadata entry
		zos.putArchiveEntry(new ZipArchiveEntry(
				SerializedDataConstants.META_FILE));
		dataIterator.getMetaData().write(dos);
		zos.closeArchiveEntry();

		// write data entry
		zos.putArchiveEntry(new ZipArchiveEntry(
				SerializedDataConstants.DATA_FILE));
		if (closeInstance) {
			IInstance ins;
			while (dataIterator.hasNext()) {
				(ins = dataIterator.next()).write(dos);
				ins.destroy();
			}
		} else {
			while (dataIterator.hasNext()) {
				dataIterator.next().write(dos);
			}
		}

		zos.closeArchiveEntry();

		// write data index entry
		zos.putArchiveEntry(new ZipArchiveEntry(
				SerializedDataConstants.INDEX_FILE));
		di.writeTo(dos);
		zos.closeArchiveEntry();

		zos.close();
		dos.close();
	}

	public void close() throws Exception {
		close(false);
	}

	public void close(boolean closeData) throws Exception {
		try {
			if (closeData && dataIterator != null) {
				dataIterator.close();
			}
		} finally {
			dataIterator = null;
		}
	}
}
