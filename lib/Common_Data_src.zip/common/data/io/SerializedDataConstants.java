/**
 * Created by Xiaojun Chen at 2011-12-13
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.File;

/**
 * contains three parts: metadata, data and data index
 * 
 * @author Xiaojun Chen
 * @version 0.1
 */
public class SerializedDataConstants {

	// types
	public static final byte DATA = 1;
	public static final byte META_DATA = 2;
	public static final byte META_DATA_INDEX = 3;

	// files
	public static final String META_FILE_SUFFIX = ".msd";
	public static final String DATA_FILE_SUFFIX = ".dsd";
	public static final String INDEX_FILE_SUFFIX = ".idx";

	public static final String META_FILE = "meta" + META_FILE_SUFFIX;
	public static final String DATA_FILE = "data" + DATA_FILE_SUFFIX;
	public static final String INDEX_FILE = "index" + INDEX_FILE_SUFFIX;

	public static File metaDataFile(File directory) {
		return new File(directory, META_FILE);
	}

	public static File dataFile(File directory) {
		return new File(directory, DATA_FILE);
	}

	public static File indexFile(File directory) {
		return new File(directory, INDEX_FILE);
	}
}
