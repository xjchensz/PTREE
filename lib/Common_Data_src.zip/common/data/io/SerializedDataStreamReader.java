/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.Closeable;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.data.meta.MetaData;
import common.utils.io.LimitedInputStream;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class SerializedDataStreamReader<T extends IInstance> implements
		IDataIterator<T> {

	private MetaData metaData;
	private DataInputStream input;
	private T instance;

	public SerializedDataStreamReader(InputStream is) throws IOException {
		input = new DataInputStream(is);
		parseInputStream(is);
	}

	public SerializedDataStreamReader(MetaData metadata, InputStream is)
			throws IOException {
		this.metaData = metadata;
		input = new DataInputStream(is);
	}

	protected void parseInputStream(InputStream is) throws IOException {
		int flag = is.read();
		switch (flag) {
		case SerializedDataConstants.META_DATA:
			// skip the size of metadata
			is.skip(SerializedDataInputStream.NBYTES_SIZE_FLAG);
			metaData = MetaData.readMetaData(input);
			break;
		case SerializedDataConstants.META_DATA_INDEX:
			// skip the size of metadata
			is.skip(SerializedDataInputStream.NBYTES_SIZE_FLAG);
			// read the size of data
			long dataSize = input.readLong();
			metaData = MetaData.readMetaData(input);
			input = new DataInputStream(new LimitedInputStream(is, dataSize));
			break;
		default:
			throw new IOException("No metadata");
		}
	}

	public MetaData getMetaData() {
		return metaData;
	}

	@Override
	public boolean hasNext() {
		readInstance();
		return instance != null;
	}

	@Override
	public T next() {
		readInstance();
		T ret = instance;
		instance = null;
		return ret;
	}

	private void readInstance() {
		if (instance == null) {
			try {
				instance = (T) metaData.readInstance(input, null);
			} catch (IOException e) {
			}
		}
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void reset() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void close() throws Exception {
		if (input instanceof Closeable) {
			((Closeable) input).close();
		}
		input = null;
	}

	@Override
	public boolean isClosed() {
		return input == null;
	}
}
