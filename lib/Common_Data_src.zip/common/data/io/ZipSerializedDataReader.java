/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.data.meta.MetaData;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class ZipSerializedDataReader<T extends IInstance> implements
		IDataIterator<T> {

	private ArchiveInputStream ais;
	private DataInputStream dis;
	private MetaData metaData = null;

	public ZipSerializedDataReader(File zipFile) throws IOException,
			ArchiveException, InstantiationException, IllegalAccessException,
			ClassNotFoundException {
		this(new FileInputStream(zipFile));
	}

	public ZipSerializedDataReader(InputStream in) throws IOException,
			ArchiveException {

		ais = new ArchiveStreamFactory().createArchiveInputStream(
				ArchiveStreamFactory.ZIP, new BufferedInputStream(in));
		// read meta_inf
		ZipArchiveEntry entry = (ZipArchiveEntry) ais.getNextEntry();

		// read metadata
		entry = (ZipArchiveEntry) ais.getNextEntry();
		if (SerializedDataConstants.META_FILE.equals(entry.getName())) {
			DataInputStream input = new DataInputStream(ais);
			metaData = MetaData.readMetaData(input);
			input = null;
		}

		if (metaData == null) {
			throw new IOException("No metaData!");
		}

		// read data
		entry = (ZipArchiveEntry) ais.getNextEntry();
		if (!SerializedDataConstants.DATA_FILE.equals(entry.getName())) {
			throw new IOException("No Data!");
		}
		dis = new DataInputStream(ais);
	}

	private T instance;

	public MetaData getMetaData() {
		return metaData;
	}

	@Override
	public boolean hasNext() {
		readInstance();
		return instance != null;
	}

	@Override
	public T next() {
		readInstance();
		T ret = instance;
		instance = null;
		return ret;
	}

	private void readInstance() {
		if (instance == null) {
			try {
				instance = (T) metaData.readInstance(dis, null);
			} catch (IOException e) {
			}
		}
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void reset() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void close() throws Exception {
		if (dis != null) {
			dis.close();
			dis = null;
		}
	}

	@Override
	public boolean isClosed() {
		return dis == null;
	}

}
