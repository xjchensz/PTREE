/**
 * Created by Xiaojun Chen at 2012-3-23
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Vector;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.utils.SimpleByteArrayInputStream;
import common.utils.SimpleByteArrayOutputStream;
import common.utils.io.UnCloseableInputStream;

/**
 * 
 * @author Xiaojun Chen
 * @version 1..0.0
 * 
 *          the structure of the input stream: FLAG (DATA/META_DATA) if the FLAG
 *          is DATA, then the following part is only the data; if the FLAG is
 *          META_DATA, then the following is the size of metadata, the metadata
 *          and the data.
 */
public class SerializedDataInputStream extends InputStream {

	// the number of bytes of each size flag takes
	public static final int NBYTES_SIZE_FLAG = 8;

	private InputStream in;
	protected Enumeration<InputStream> emr;

	private static final Logger log = LoggerFactory
			.getLogger(SerializedDataInputStream.class);

	protected SerializedDataInputStream() {

	}

	/**
	 * @throws IOException
	 * 
	 */
	public SerializedDataInputStream(
			final IDataIterator<? extends IInstance> dataIterator,
			boolean containsMetaData) throws IOException {
		if (containsMetaData) {
			InputStreamWithMetaData(dataIterator);
		} else {
			InputStreamWithOutMetaData(dataIterator);
		}
	}

	private void InputStreamWithMetaData(
			final IDataIterator<? extends IInstance> dataIterator)
			throws IOException {
		// metadata
		final SimpleByteArrayOutputStream bo1 = new SimpleByteArrayOutputStream();
		final DataOutputStream dos1 = new DataOutputStream(bo1);
		dataIterator.getMetaData().write(dos1);
		final SimpleByteArrayInputStream bis1 = new SimpleByteArrayInputStream(
				bo1);

		// flag+length flag
		SimpleByteArrayOutputStream bo2 = new SimpleByteArrayOutputStream();
		DataOutputStream dos2 = new DataOutputStream(bo2);
		dos2.writeByte(SerializedDataConstants.META_DATA);
		// size of metadata
		dos2.writeLong(dos1.size());
		final SimpleByteArrayInputStream flagInputStream = new SimpleByteArrayInputStream(
				bo2);

		setInputStreams(new Enumeration<InputStream>() {
			// -1:end, 0: flag, 1: meta, 2: data
			byte flag = 0;

			@Override
			public boolean hasMoreElements() {
				switch (flag) {

				case 0:
				case 1:
					return true;
				case 2:
					if (dataIterator.hasNext()) {
						return true;
					} else {
						return false;
					}
				case -1:
				default:
					return false;
				}
			}

			@Override
			public InputStream nextElement() {
				switch (flag) {
				case 0:
					flag++;
					return flagInputStream;
				case 1:
					flag++;
					return bis1;
				case 2:
					bo1.reset();
					if (dataIterator.hasNext()) {
						try {
							dataIterator.next().write(dos1);
						} catch (IOException e) {
							log.error("data error!", e);
							return null;
						}
					}
					bis1.reset(bo1);
					return bis1;
				case -1:
				default:
					return null;
				}
			}

		});
	}

	private void InputStreamWithOutMetaData(
			final IDataIterator<? extends IInstance> dataIterator)
			throws IOException {

		// flag+length flag
		SimpleByteArrayOutputStream bo2 = new SimpleByteArrayOutputStream();
		DataOutputStream dos2 = new DataOutputStream(bo2);
		dos2.writeByte(SerializedDataConstants.DATA);
		// size of metadata
		final SimpleByteArrayInputStream flagInputStream = new SimpleByteArrayInputStream(
				bo2);

		final SimpleByteArrayOutputStream bo1 = new SimpleByteArrayOutputStream();
		final DataOutputStream dos1 = new DataOutputStream(bo1);
		final SimpleByteArrayInputStream bis1 = new SimpleByteArrayInputStream(
				bo1);

		setInputStreams(new Enumeration<InputStream>() {
			// -1:end, 0: flag, 1: data
			byte flag = 0;

			@Override
			public boolean hasMoreElements() {
				switch (flag) {

				case 0:
					return true;
				case 1:
					if (dataIterator.hasNext()) {
						return true;
					} else {
						return false;
					}
				case -1:
				default:
					return false;
				}
			}

			@Override
			public InputStream nextElement() {
				switch (flag) {
				case 0:
					flag++;
					return flagInputStream;
				case 2:
					bo1.reset();
					if (dataIterator.hasNext()) {
						try {
							dataIterator.next().write(dos1);
						} catch (IOException e) {
							log.error("data error!", e);
							return null;
						}
					}
					bis1.reset(bo1);
					return bis1;
				case -1:
				default:
					return null;
				}
			}

		});
	}

	public SerializedDataInputStream(File f) throws IOException,
			ArchiveException {
		this(f, true);
	}

	/**
	 * if f is directory, then will read the files in the directory to construct
	 * the inputStream; if f is a file, then will read the zip file
	 * 
	 * @throws ArchiveException
	 * */
	public SerializedDataInputStream(File f, boolean containsMetaData)
			throws IOException, ArchiveException {
		if (f.isDirectory()) {
			if (containsMetaData) {
				fileInputStreamWithMetaData(f);
			} else {
				fileInputStreamWithOutMetaData(f);
			}
		} else {
			if (containsMetaData) {
				zipInputStreamWithMetaData(f);
			} else {
				zipInputStreamWithOutMetaData(f);
			}
		}
	}

	private void fileInputStreamWithMetaData(File directory) throws IOException {
		// metadata
		File metaFile = SerializedDataConstants.metaDataFile(directory);
		BufferedInputStream mfs = new BufferedInputStream(new FileInputStream(
				metaFile));
		long metaSize = mfs.available();

		// data
		File dataFile = SerializedDataConstants.dataFile(directory);
		BufferedInputStream dfs = new BufferedInputStream(new FileInputStream(
				dataFile));

		// flag+length flag
		SimpleByteArrayOutputStream bo = new SimpleByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bo);
		dos.writeByte(SerializedDataConstants.META_DATA);
		// size of metadata
		dos.writeLong(metaSize);
		SimpleByteArrayInputStream flagInputStream = new SimpleByteArrayInputStream(
				bo);

		Vector<InputStream> vector = new Vector<InputStream>(4);
		vector.add(flagInputStream);
		vector.add(mfs);
		vector.add(dfs);
		setInputStreams(vector.elements());
	}

	private void fileInputStreamWithOutMetaData(File directory)
			throws IOException {
		// data
		File dataFile = SerializedDataConstants.dataFile(directory);
		BufferedInputStream dfs = new BufferedInputStream(new FileInputStream(
				dataFile));

		// flag+length flag
		SimpleByteArrayOutputStream bo = new SimpleByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bo);
		dos.writeByte(SerializedDataConstants.DATA);
		// size of metadata
		SimpleByteArrayInputStream flagInputStream = new SimpleByteArrayInputStream(
				bo);

		Vector<InputStream> vector = new Vector<InputStream>(4);
		vector.add(flagInputStream);
		vector.add(dfs);
		setInputStreams(vector.elements());
	}

	/**
	 * zip input stream
	 * 
	 * @throws ArchiveException
	 * */
	private void zipInputStreamWithMetaData(File zipFile) throws IOException,
			ArchiveException {
		final ArchiveInputStream ais = new ArchiveStreamFactory()
				.createArchiveInputStream(ArchiveStreamFactory.ZIP,
						new BufferedInputStream(new FileInputStream(zipFile)));

		// meta_inf
		ZipArchiveEntry entry = (ZipArchiveEntry) ais.getNextEntry();
		if (!ZipSerializedDataWriter.META_INF.equals(entry.getName())) {
			throw new IOException("No meta_inf!");
		}
		DataInputStream input = new DataInputStream(ais);
		long metaSize = input.readLong();
		SimpleByteArrayOutputStream bo1 = new SimpleByteArrayOutputStream();
		DataOutputStream dos1 = new DataOutputStream(bo1);
		dos1.writeByte(SerializedDataConstants.META_DATA);
		dos1.writeLong(metaSize);
		final SimpleByteArrayInputStream flagInputStream = new SimpleByteArrayInputStream(
				bo1);

		setInputStreams(new Enumeration<InputStream>() {
			// -1:end, 0: flag, 1: meta, 2: data
			byte flag = 0;

			@Override
			public boolean hasMoreElements() {
				switch (flag) {
				case 0:
				case 1:
					return true;
				case 2:
					return true;
				case -1:
				default:
					return false;
				}
			}

			@Override
			public InputStream nextElement() {
				switch (flag) {
				case 0:
					flag++;
					return flagInputStream;
				case 1:
					flag++;
					// meta
					try {
						ZipArchiveEntry me = (ZipArchiveEntry) ais
								.getNextEntry();
						if (!SerializedDataConstants.META_FILE.equals(me
								.getName())) {
							throw new IOException("No metadata!");
						}
						return new UnCloseableInputStream(ais);
					} catch (IOException e) {
						return null;
					}
				case 2:
					flag = -1;
					// data
					try {
						ZipArchiveEntry de = (ZipArchiveEntry) ais
								.getNextEntry();
						if (!SerializedDataConstants.DATA_FILE.equals(de
								.getName())) {
							throw new IOException("No data!");
						}
						return ais;
					} catch (IOException e) {
						return null;
					}
				case -1:
				default:
					return null;
				}
			}
		});
	}

	private void zipInputStreamWithOutMetaData(File zipFile)
			throws IOException, ArchiveException {
		final ArchiveInputStream ais = new ArchiveStreamFactory()
				.createArchiveInputStream(ArchiveStreamFactory.ZIP,
						new BufferedInputStream(new FileInputStream(zipFile)));

		// meta_inf
		ZipArchiveEntry entry = (ZipArchiveEntry) ais.getNextEntry();
		if (!ZipSerializedDataWriter.META_INF.equals(entry.getName())) {
			throw new IOException("No meta_inf!");
		}
		SimpleByteArrayOutputStream bo1 = new SimpleByteArrayOutputStream();
		DataOutputStream dos1 = new DataOutputStream(bo1);
		dos1.writeByte(SerializedDataConstants.DATA);
		final SimpleByteArrayInputStream flagInputStream = new SimpleByteArrayInputStream(
				bo1);

		setInputStreams(new Enumeration<InputStream>() {
			// -1:end, 0: flag, 1: data
			byte flag = 0;

			@Override
			public boolean hasMoreElements() {
				switch (flag) {
				case 0:
				case 1:
					return true;
				case -1:
				default:
					return false;
				}
			}

			@Override
			public InputStream nextElement() {
				switch (flag) {
				case 0:
					flag++;
					return flagInputStream;
				case 1:
					flag = -1;
					// data
					try {
						ZipArchiveEntry de = (ZipArchiveEntry) ais
								.getNextEntry();
						if (!SerializedDataConstants.DATA_FILE.equals(de
								.getName())) {
							throw new IOException("No data!");
						}
						return ais;
					} catch (IOException e) {
						return null;
					}
				case -1:
				default:
					return null;
				}
			}
		});
	}

	protected void setInputStreams(Enumeration<InputStream> emr) {
		this.emr = emr;
		in = emr.nextElement();
	}

	/**
	 * Continues reading in the next stream if an EOF is reached.
	 */
	final void nextStream() throws IOException {
		if (in != null) {
			in.close();
		}

		if (emr.hasMoreElements()) {
			in = emr.nextElement();
		} else
			in = null;
	}

	public int read() throws IOException {
		if (in == null) {
			return -1;
		}
		int c = in.read();
		if (c == -1) {
			nextStream();
			return read();
		}
		return c;
	}

	public int read(byte b[], int off, int len) throws IOException {
		if (in == null) {
			return -1;
		} else if (b == null) {
			throw new NullPointerException();
		} else if (off < 0 || len < 0 || len > b.length - off) {
			throw new IndexOutOfBoundsException();
		} else if (len == 0) {
			return 0;
		}

		int n = in.read(b, off, len);
		if (n <= 0) {
			nextStream();
			return read(b, off, len);
		}
		return n;
	}

	public int available() throws IOException {
		return 0; // no way to signal EOF from available()
	}

	public void close() throws IOException {
		do {
			nextStream();
		} while (in != null);
	}

}
