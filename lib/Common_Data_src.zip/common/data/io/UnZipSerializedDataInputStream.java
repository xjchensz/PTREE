/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;

import common.utils.SimpleByteArrayInputStream;
import common.utils.SimpleByteArrayOutputStream;
import common.utils.io.UnCloseableInputStream;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class UnZipSerializedDataInputStream extends SerializedDataInputStream {

	public UnZipSerializedDataInputStream(File zipFile)
			throws ArchiveException, IOException {
		this(new FileInputStream(zipFile));
	}

	/**
	 * @throws ArchiveException
	 * @throws IOException
	 * 
	 */
	public UnZipSerializedDataInputStream(final InputStream is)
			throws ArchiveException, IOException {

		final ArchiveInputStream ais = new ArchiveStreamFactory()
				.createArchiveInputStream(ArchiveStreamFactory.ZIP, is);

		// read meta_inf
		ArchiveEntry entry = ais.getNextEntry();
		if (!ZipSerializedDataWriter.META_INF.equals(entry.getName())) {
			throw new IOException("No meta_inf entry!");
		}

		setInputStreams(new Enumeration<InputStream>() {
			// 0: flag, 1: meta, 2: data
			byte flag = 0;

			@Override
			public boolean hasMoreElements() {
				switch (flag) {
				case 0:
				case 1:
				case 2:
					return true;
				default:
					if (is != null) {
						try {
							is.close();
						} catch (IOException e) {
						}
					}
					return false;
				}
			}

			@Override
			public InputStream nextElement() {
				switch (flag) {
				case 0:
					// flag
					flag++;
					SimpleByteArrayOutputStream bo = new SimpleByteArrayOutputStream();
					DataOutputStream dos = new DataOutputStream(bo);
					try {
						DataInputStream di = new DataInputStream(ais);
						dos.writeByte(SerializedDataConstants.META_DATA);
						// size of metadata
						dos.writeLong(di.readLong());
						return new SimpleByteArrayInputStream(bo);
					} catch (IOException e) {
						return null;
					}

				case 1:
					// metadata
					flag++;
					try {
						ArchiveEntry mentry = ais.getNextEntry();
						if (!SerializedDataConstants.META_FILE.equals(mentry
								.getName())) {
							throw new IOException("No metadata entry!");
						}
						return new UnCloseableInputStream(ais);
					} catch (IOException e) {
						return null;
					}
				case 2:
					// data
					flag++;
					try {
						ArchiveEntry mentry = ais.getNextEntry();
						if (!SerializedDataConstants.DATA_FILE.equals(mentry
								.getName())) {
							throw new IOException("No data entry!");
						}
						return ais;
					} catch (IOException e) {
						return null;
					}
				default:
					return null;
				}
			}
		});

	}
}
