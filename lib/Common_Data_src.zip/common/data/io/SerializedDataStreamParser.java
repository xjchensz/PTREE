/**
 * Created by Xiaojun Chen at 2012-3-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

import common.data.IDataParser;
import common.data.meta.MetaData;
import common.utils.io.LimitedInputStream;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class SerializedDataStreamParser implements IDataParser {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8075477846782342809L;
	private MetaData m_MetaData;
	private InputStream dataStream;

	/**
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * 
	 */
	public SerializedDataStreamParser(InputStream in) throws IOException {
		DataInputStream di = new DataInputStream(in);
		switch (di.read()) {
		case SerializedDataConstants.META_DATA:
			// skip the size of metadata
			di.skip(SerializedDataInputStream.NBYTES_SIZE_FLAG);
			m_MetaData = MetaData.readMetaData(di);
			dataStream = in;
			break;
		case SerializedDataConstants.META_DATA_INDEX:
			// skip the size of metadata
			di.skip(SerializedDataInputStream.NBYTES_SIZE_FLAG);
			// read the size of data
			long dataSize = di.readLong();
			m_MetaData = MetaData.readMetaData(di);
			dataStream = new LimitedInputStream(in, dataSize);
			break;
		default:
			throw new IOException("No metadata");

		}
	}

	@Override
	public MetaData getMetaData() {
		return m_MetaData;
	}

	@Override
	public InputStream getDataStream() {
		return dataStream;
	}

}
