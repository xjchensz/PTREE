/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

import common.data.DataConfiguration;
import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.utils.io.ExtendedIOUtils;
import common.utils.io.NullOutputStream;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class ZipSerializedDataInputStream extends InputStream {

	// the number of bytes of each size flag takes
	public static final int NBYTES_SIZE_FLAG = 8;

	private InputStream in;
	protected Enumeration<InputStream> emr;

	public ZipSerializedDataInputStream(
			final IDataIterator<? extends IInstance> dataIterator)
			throws IOException, ArchiveException {
		this(dataIterator, DataConfiguration.BUFFER_SIZE);
	}

	/**
	 * @throws IOException
	 * @throws ArchiveException
	 * 
	 */
	public ZipSerializedDataInputStream(
			final IDataIterator<? extends IInstance> dataIterator,
			int bufferSize) throws IOException, ArchiveException {
		final File tempFile = File.createTempFile("tmp", ".zip");
		tempFile.createNewFile();
		ArchiveOutputStream aos = new ArchiveStreamFactory()
				.createArchiveOutputStream(ArchiveStreamFactory.ZIP,
						new BufferedOutputStream(
								new FileOutputStream(tempFile), bufferSize));

		DataOutputStream os = new DataOutputStream(new NullOutputStream());
		dataIterator.getMetaData().write(os);
		long metadataSize = os.size();
		DataOutputStream dos = new DataOutputStream(aos);

		// meta_inf
		aos.putArchiveEntry(new ZipArchiveEntry(
				ZipSerializedDataWriter.META_INF));
		dos.writeByte(SerializedDataConstants.META_DATA);
		// size of metadata
		dos.writeLong(metadataSize);
		aos.closeArchiveEntry();

		// metadata
		aos.putArchiveEntry(new ZipArchiveEntry(
				SerializedDataConstants.META_FILE));
		dataIterator.getMetaData().write(dos);
		aos.closeArchiveEntry();

		// data
		aos.putArchiveEntry(new ZipArchiveEntry(
				SerializedDataConstants.DATA_FILE));
		while (dataIterator.hasNext()) {
			dataIterator.next().write(dos);
		}
		aos.closeArchiveEntry();
		aos.close();

		final FileInputStream fis = new FileInputStream(tempFile);

		setInputStreams(new Enumeration<InputStream>() {
			boolean read = false;

			@Override
			public boolean hasMoreElements() {
				return !read;
			}

			@Override
			public InputStream nextElement() {
				if (read) {
					return null;

				}
				read = true;
				return new InputStream() {

					public int read() throws IOException {
						return fis.read();
					}

					public int read(byte b[]) throws IOException {
						return fis.read(b);
					}

					public int read(byte b[], int off, int len)
							throws IOException {
						return fis.read(b, off, len);
					}

					public long skip(long n) throws IOException {
						return fis.skip(n);
					}

					public int available() throws IOException {
						return fis.available();
					}

					public void close() throws IOException {
						try {
							fis.close();
						} finally {
							tempFile.delete();
						}
					}

					public synchronized void mark(int readlimit) {
						fis.mark(readlimit);
					}

					public synchronized void reset() throws IOException {
						fis.reset();
					}

					public boolean markSupported() {
						return fis.markSupported();
					}
				};
			}
		});
	}

	/**
	 * if f is directory, then will read the files in the directory to construct
	 * the inputStream; if f is a file, then will read the zip file
	 * 
	 * @throws ArchiveException
	 * */
	public ZipSerializedDataInputStream(File file) throws IOException,
			ArchiveException {
		if (file.isDirectory()) {
			fileInputStream(file, DataConfiguration.BUFFER_SIZE);
		} else {
			zipInputStream(file, DataConfiguration.BUFFER_SIZE);
		}
	}

	public ZipSerializedDataInputStream(File file, int buffersize)
			throws IOException, ArchiveException {
		if (file.isDirectory()) {
			fileInputStream(file, buffersize);
		} else {
			zipInputStream(file, buffersize);
		}
	}

	private void fileInputStream(final File directory, final int bufferSize)
			throws IOException, ArchiveException {

		// meta data
		File metaFile = SerializedDataConstants.metaDataFile(directory);
		BufferedInputStream mfs = new BufferedInputStream(new FileInputStream(
				metaFile), bufferSize);

		// data
		File dataFile = SerializedDataConstants.dataFile(directory);
		BufferedInputStream dfs = new BufferedInputStream(new FileInputStream(
				dataFile), bufferSize);

		final File tempFile = File.createTempFile("tmp", ".zip");
		tempFile.createNewFile();
		ArchiveOutputStream aos = new ArchiveStreamFactory()
				.createArchiveOutputStream(ArchiveStreamFactory.ZIP,
						new BufferedOutputStream(
								new FileOutputStream(tempFile), bufferSize));

		DataOutputStream dos = new DataOutputStream(aos);

		// meta_inf
		aos.putArchiveEntry(new ZipArchiveEntry(
				ZipSerializedDataWriter.META_INF));
		dos.writeByte(SerializedDataConstants.META_DATA);
		// size of metadata
		dos.writeLong(metaFile.length());
		aos.closeArchiveEntry();

		// metadata
		aos.putArchiveEntry(new ZipArchiveEntry(
				SerializedDataConstants.META_FILE));
		ExtendedIOUtils.copy(mfs, dos);
		aos.closeArchiveEntry();
		mfs.close();

		// data
		aos.putArchiveEntry(new ZipArchiveEntry(
				SerializedDataConstants.DATA_FILE));
		ExtendedIOUtils.copy(dfs, dos);
		dfs.close();
		aos.closeArchiveEntry();
		aos.close();

		final FileInputStream fis = new FileInputStream(tempFile);

		setInputStreams(new Enumeration<InputStream>() {
			boolean read = false;

			@Override
			public boolean hasMoreElements() {
				return !read;
			}

			@Override
			public InputStream nextElement() {
				if (read) {
					return null;

				}
				read = true;
				return new InputStream() {

					public int read() throws IOException {
						return fis.read();
					}

					public int read(byte b[]) throws IOException {
						return fis.read(b);
					}

					public int read(byte b[], int off, int len)
							throws IOException {
						return fis.read(b, off, len);
					}

					public long skip(long n) throws IOException {
						return fis.skip(n);
					}

					public int available() throws IOException {
						return fis.available();
					}

					public void close() throws IOException {
						try {
							fis.close();
						} finally {
							tempFile.delete();
						}
					}

					public synchronized void mark(int readlimit) {
						fis.mark(readlimit);
					}

					public synchronized void reset() throws IOException {
						fis.reset();
					}

					public boolean markSupported() {
						return fis.markSupported();
					}
				};
			}
		});

	}

	/**
	 * zip input stream
	 * 
	 * @throws ArchiveException
	 * */
	private void zipInputStream(File zipFile, int buffersize)
			throws IOException, ArchiveException {
		final BufferedInputStream is = new BufferedInputStream(
				new FileInputStream(zipFile), buffersize);

		setInputStreams(new Enumeration<InputStream>() {
			byte flag = 0;

			@Override
			public boolean hasMoreElements() {
				switch (flag) {
				case 0:
					return true;
				case 1:
				default:
					return false;
				}
			}

			@Override
			public InputStream nextElement() {
				switch (flag) {
				case 0:
					flag++;
					return is;
				case 1:
				default:
					return null;
				}
			}
		});
	}

	protected void setInputStreams(Enumeration<InputStream> emr) {
		this.emr = emr;
		in = emr.nextElement();
	}

	/**
	 * Continues reading in the next stream if an EOF is reached.
	 */
	final void nextStream() throws IOException {
		if (in != null) {
			in.close();
		}

		if (emr.hasMoreElements()) {
			in = emr.nextElement();
		} else
			in = null;
	}

	public int read() throws IOException {
		if (in == null) {
			return -1;
		}
		int c = in.read();
		if (c == -1) {
			nextStream();
			return read();
		}
		return c;
	}

	public int read(byte b[], int off, int len) throws IOException {
		if (in == null) {
			return -1;
		} else if (b == null) {
			throw new NullPointerException();
		} else if (off < 0 || len < 0 || len > b.length - off) {
			throw new IndexOutOfBoundsException();
		} else if (len == 0) {
			return 0;
		}

		int n = in.read(b, off, len);
		if (n <= 0) {
			nextStream();
			return read(b, off, len);
		}
		return n;
	}

	public int available() throws IOException {
		return 0; // no way to signal EOF from available()
	}

	public void close() throws IOException {
		do {
			nextStream();
		} while (in != null);
	}

}
