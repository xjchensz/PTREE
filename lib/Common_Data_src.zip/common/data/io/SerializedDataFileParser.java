/**
 * Created by Xiaojun Chen at 2012-3-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

import common.data.DataConfiguration;
import common.data.IDataParser;
import common.data.meta.MetaData;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class SerializedDataFileParser implements IDataParser {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8075477846782342809L;
	private MetaData m_MetaData;
	private InputStream dataStream;

	public SerializedDataFileParser(File file) throws IOException,
			ArchiveException, InstantiationException, IllegalAccessException,
			ClassNotFoundException {
		if (file.isDirectory()) {
			fileParser(file);
		} else {
			zipFileParser(file);
		}
	}

	/**
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * 
	 */
	private void fileParser(File directory) throws IOException,
			InstantiationException, IllegalAccessException,
			ClassNotFoundException {
		DataInputStream input = null;
		try {
			input = new DataInputStream(new BufferedInputStream(
					new FileInputStream(
							SerializedDataConstants.metaDataFile(directory)),
					DataConfiguration.BUFFER_SIZE));
			m_MetaData = MetaData.readMetaData(input);
		} finally {
			if (input != null) {
				input.close();
			}
		}

		if (m_MetaData == null) {
			throw new IOException("No metaData!");
		}

		dataStream = new BufferedInputStream(new FileInputStream(
				SerializedDataConstants.dataFile(directory)),
				DataConfiguration.BUFFER_SIZE);
	}

	private void zipFileParser(File zipFile) throws IOException,
			ArchiveException {
		ArchiveInputStream ais = new ArchiveStreamFactory()
				.createArchiveInputStream(ArchiveStreamFactory.ZIP,
						new BufferedInputStream(new FileInputStream(zipFile)));
		DataInputStream input = new DataInputStream(ais);

		// read meta_inf
		ZipArchiveEntry entry = (ZipArchiveEntry) ais.getNextEntry();
		if (input.read() == SerializedDataConstants.DATA) {
			throw new IOException("No metadata!");
		}

		// read metadata
		entry = (ZipArchiveEntry) ais.getNextEntry();
		if (entry.getName().equals(SerializedDataConstants.META_FILE)) {
			m_MetaData = MetaData.readMetaData(input);
		}

		if (m_MetaData == null) {
			throw new IOException("No metaData!");
		}

		// read data
		entry = (ZipArchiveEntry) ais.getNextEntry();
		if (!entry.getName().equals(SerializedDataConstants.DATA_FILE)) {
			throw new IOException("No Data!");
		}
		dataStream = ais;
	}

	@Override
	public MetaData getMetaData() {
		return m_MetaData;
	}

	@Override
	public InputStream getDataStream() {
		return dataStream;
	}

}
