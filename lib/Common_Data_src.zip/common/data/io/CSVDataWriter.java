/**
 * Created by Xiaojun Chen at 2012-3-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.util.LinkedList;

import common.data.DataConfiguration;
import common.data.IDataIterator;
import common.data.instance.numeric.INumericInstance;
import common.data.meta.IAttribute;
import common.data.meta.MetaData;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class CSVDataWriter {

	private boolean closeAble;
	private IDataIterator<? extends INumericInstance> dataIterator;

	public CSVDataWriter(IDataIterator<? extends INumericInstance> dataIterator) {
		this(dataIterator, false);
	}

	/**
	 * 
	 */
	public CSVDataWriter(
			IDataIterator<? extends INumericInstance> dataIterator,
			boolean closeAble) {
		this.dataIterator = dataIterator;
		this.closeAble = closeAble;
	}

	private boolean write = false;

	public void writeToFile(File file) throws Exception {
		writeToFile(file, true, false, ",");
	}

	public void writeToFile(File file, boolean hasColumnNames, boolean hasID,
			String delimiter) throws Exception {
		BufferedWriter bw = new BufferedWriter(new FileWriter(file),
				DataConfiguration.BUFFER_SIZE);
		try {
			writeToOutputStream(bw, hasColumnNames, hasID, delimiter);
		} finally {
			bw.close();
		}
	}

	public void writeToOutputStream(Writer writer) throws Exception {
		writeToOutputStream(writer, true, false, ",");
	}

	public void writeToOutputStream(Writer writer, boolean hasColumnNames,
			boolean hasID, String delimiter) throws Exception {
		if (!write) {
			write = true;
		} else {
			dataIterator.reset();
		}

		StringBuilder sb = new StringBuilder();
		MetaData metaData = dataIterator.getMetaData();
		IAttribute[] attrs = metaData.getAttributes();

		LinkedList<Integer> columns = new LinkedList<Integer>();
		for (int i = 0; i < attrs.length; i++) {
			if (!attrs[i].isIgnored()) {
				columns.add(i);
			}
		}

		int[] writeColumns = new int[columns.size()];
		for (int i = 0; i < writeColumns.length; i++) {
			writeColumns[i] = columns.get(i);
		}

		columns.clear();
		columns = null;

		// column name
		if (hasColumnNames) {
			if (hasID) {
				sb.append("ID").append(delimiter);
			}
			if (hasColumnNames) {
				for (int i = 0; i < writeColumns.length; i++) {
					sb.append(attrs[writeColumns[i]].getName()).append(
							delimiter);
				}
				if (sb.length() > 0) {
					sb.setLength(sb.length() - 1);
				}
				sb.append('\n');
			}
			writer.append(sb);
			sb.setLength(0);
		}

		// data
		INumericInstance instance;

		while (dataIterator.hasNext()) {
			instance = dataIterator.next();
			if (hasID) {
				sb.append(instance.getID()).append(delimiter);
			}
			for (int i = 0; i < writeColumns.length; i++) {
				sb.append(instance.stringValue(writeColumns[i])).append(
						delimiter);
			}
			if (sb.length() > 0) {
				sb.setLength(sb.length() - 1);
			}
			sb.append('\n');
			writer.append(sb);
			sb.setLength(0);
		}
	}

	public void close() {
		if (closeAble) {
			try {
				dataIterator.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		dataIterator = null;
	}
}
