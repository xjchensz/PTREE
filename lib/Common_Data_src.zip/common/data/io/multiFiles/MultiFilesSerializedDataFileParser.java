/**
 * Created by Xiaojun Chen at 2012-3-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.multiFiles;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.SequenceInputStream;
import java.util.Enumeration;
import java.util.List;

import org.apache.commons.compress.archivers.ArchiveException;

import common.data.DataConfiguration;
import common.data.IDataParser;
import common.data.meta.MetaData;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class MultiFilesSerializedDataFileParser implements IDataParser {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8075477846782342809L;
	private MetaData m_MetaData;
	private InputStream dataStream;

	public MultiFilesSerializedDataFileParser(File directory)
			throws IOException, ArchiveException {

		DataInputStream input = null;
		try {
			input = new DataInputStream(new BufferedInputStream(
					new FileInputStream(
							MultiFilesSerializedDataConstants
									.metaDataFile(directory)),
					DataConfiguration.BUFFER_SIZE));
			m_MetaData = MetaData.readMetaData(input);
		} finally {
			if (input != null) {
				input.close();
			}
		}

		if (m_MetaData == null) {
			throw new IOException("No metaData!");
		}

		final List<File> files = MultiFilesSerializedDataConstants
				.dataFiles(directory);

		dataStream = new BufferedInputStream(new SequenceInputStream(
				new Enumeration<InputStream>() {
					int index;

					@Override
					public boolean hasMoreElements() {
						return index < files.size();
					}

					@Override
					public InputStream nextElement() {
						try {
							return new FileInputStream(files.get(index++));
						} catch (FileNotFoundException e) {
							e.printStackTrace();
							return null;
						}
					}
				}), DataConfiguration.BUFFER_SIZE);

	}

	@Override
	public MetaData getMetaData() {
		return m_MetaData;
	}

	@Override
	public InputStream getDataStream() {
		return dataStream;
	}

}
