/**
 * 
 */
package common.data.io.multiFiles;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import common.data.io.SerializedDataConstants;

/**
 * @author xjc
 * 
 */
public class MultiFilesSerializedDataConstants extends SerializedDataConstants {

	public static List<File> dataFiles(File directory) {
		return dataFiles(directory, null);
	}

	public static List<File> dataFiles(File directory,
			Comparator<File> comparator) {
		File[] files = directory.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				return name.endsWith(DATA_FILE_SUFFIX);
			}
		});

		if (comparator != null) {
			Arrays.sort(files, comparator);
		}

		ArrayList<File> list = new ArrayList<File>(files.length);

		for (File file : files) {
			list.add(file);
		}

		return list;
	}

}
