/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io.multiFiles;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.data.io.SerializedDataConstants;
import common.utils.SimpleByteArrayOutputStream;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class MultiFilesSerializedDataWriter {

	private IDataIterator<? extends IInstance> dataIterator;

	public MultiFilesSerializedDataWriter(
			IDataIterator<? extends IInstance> dataIterator) {
		this.dataIterator = dataIterator;
	}

	private File m_Directory;

	// directory contains: meta.dsd, data.dsd, index.idx
	public void writeToDirectory(File directory,
			IGenerater<String> fileGenerater, int sizePerFile)
			throws IOException {
		if (dataIterator == null) {
			throw new NullPointerException();
		}
		m_Directory = directory;

		// write metadata
		writeMetaDataInDirectory();

		// write data
		int numWrite = 0;
		DataOutputStream output = null;

		try {
			File dataFile = null;
			while (dataIterator.hasNext()) {
				if (numWrite++ % sizePerFile == 0) {
					// create new file
					dataFile = new File(directory, fileGenerater.next() + "."
							+ SerializedDataConstants.DATA_FILE_SUFFIX);
					if (!dataFile.exists()) {
						dataFile.createNewFile();
					}
					output = new DataOutputStream(new BufferedOutputStream(
							new FileOutputStream(dataFile)));
					dataIterator.next().write(output);
				}
			}

		} finally {
			if (output != null) {
				output.close();
			}
		}
	}

	private void writeMetaDataInDirectory() throws IOException {
		// write metadata
		DataOutputStream output = null;
		try {
			File metaFile = SerializedDataConstants.metaDataFile(m_Directory);
			if (!metaFile.exists()) {
				if (!metaFile.getParentFile().exists()) {
					metaFile.getParentFile().mkdirs();
				}
				metaFile.createNewFile();
			}
			output = new DataOutputStream(new BufferedOutputStream(
					new FileOutputStream(metaFile)));
			dataIterator.getMetaData().write(output);
		} finally {
			if (output != null) {
				output.close();
			}
		}
	}

	public void writeToOutputStream(OutputStream out) throws IOException {
		m_Directory = null;

		final SimpleByteArrayOutputStream bo1 = new SimpleByteArrayOutputStream();
		final DataOutputStream dos1 = new DataOutputStream(bo1);
		dataIterator.getMetaData().write(dos1);

		// write flag
		DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(
				out));
		dos.write(SerializedDataConstants.META_DATA);
		dos.writeLong(dos1.size());

		// write metadata
		dataIterator.getMetaData().write(dos);
		// write data
		while (dataIterator.hasNext()) {
			dataIterator.next().write(dos);
		}
		dos.close();
	}

	/**
	 * update meta data in data directory
	 * 
	 * @throws IOException
	 * */
	public void updateMetaData() throws IOException {
		// update meta data
		if (m_Directory != null) {
			writeMetaDataInDirectory();
		}
	}

	public void close(boolean closeDataIterator) throws Exception {
		if (dataIterator != null) {
			try {
				if (closeDataIterator) {
					dataIterator.close();
				}
			} finally {
				dataIterator = null;
			}
		}
	}

}
