/**
 * 
 */
package common.data.io.multiFiles;

/**
 * @author xjchen
 * 
 */
public interface IGenerater<I> {

	public I next();

	public int size();
}
