/**
 * Created by Xiaojun Chen at 2012-3-23
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

import common.utils.io.ExtendedIOUtils;

/**
 * 
 * @author Xiaojun Chen
 * @version 1..0.0
 * 
 *          the structure of the input stream: FLAG
 *          (DATA/META_DATA/META_DATA_INDEX) if the FLAG is DATA, then the
 *          following part is only the data, if the FLAG is META_DATA, then the
 *          following is the start pointer of data, the metadata and the data;
 *          if the FLAG is META_DATA_INDEX, then the following part is the start
 *          pointer of data, the start pointer of data index, the metadata, the
 *          data and the data index;
 */
public class ZipSerializedDataStreamWriter {

	private InputStream is;

	public ZipSerializedDataStreamWriter(InputStream is) {
		this.is = is;
	}

	private boolean write = false;

	public void writeTo(File file) throws IOException, ArchiveException {
		if (!file.exists()) {
			file.createNewFile();
		}
		FileOutputStream bos = new FileOutputStream(file);
		writeTo(bos);
	}

	public void writeTo(OutputStream os) throws IOException, ArchiveException {
		if (is != null) {
			if (write) {
				throw new IOException("Already write the input stream!");
			}
			writeOutputStream(os);
			write = true;
		}
	}

	private void writeOutputStream(OutputStream os) throws IOException,
			ArchiveException {

		ArchiveOutputStream zos = new ArchiveStreamFactory()
				.createArchiveOutputStream(ArchiveStreamFactory.ZIP,
						new BufferedOutputStream(os));
		int flag = is.read();
		switch (flag) {
		case SerializedDataConstants.META_DATA:
			// read size of metadata
			DataInputStream dis = new DataInputStream(is);
			long metadataSize = dis.readLong();

			// write meta_inf entry
			zos.putArchiveEntry(new ZipArchiveEntry(
					ZipSerializedDataWriter.META_INF));
			DataOutputStream dos = new DataOutputStream(zos);
			dos.write(SerializedDataConstants.META_DATA);
			dos.writeLong(metadataSize);
			zos.closeArchiveEntry();

			// write metadata entry
			zos.putArchiveEntry(new ZipArchiveEntry(
					SerializedDataConstants.META_FILE));
			ExtendedIOUtils.copy(is, zos, metadataSize);
			zos.closeArchiveEntry();

			// write data entry
			zos.putArchiveEntry(new ZipArchiveEntry(
					SerializedDataConstants.DATA_FILE));
			ExtendedIOUtils.copy(is, zos);
			zos.closeArchiveEntry();
			zos.close();
			break;
		case SerializedDataConstants.META_DATA_INDEX:
			// read size of metadata and data
			dis = new DataInputStream(is);
			metadataSize = dis.readLong();
			long dataSize = dis.readLong();

			// write meta_inf entry
			zos.putArchiveEntry(new ZipArchiveEntry(
					ZipSerializedDataWriter.META_INF));
			dos = new DataOutputStream(zos);
			dos.write(SerializedDataConstants.META_DATA);
			dos.writeLong(metadataSize);
			zos.closeArchiveEntry();

			// write metadata entry
			zos.putArchiveEntry(new ZipArchiveEntry(
					SerializedDataConstants.META_FILE));
			ExtendedIOUtils.copy(is, zos, metadataSize);
			zos.closeArchiveEntry();

			// write data entry
			zos.putArchiveEntry(new ZipArchiveEntry(
					SerializedDataConstants.DATA_FILE));
			ExtendedIOUtils.copy(is, zos, dataSize);
			zos.closeArchiveEntry();
			zos.close();
			dos.close();
			break;
		default:
			throw new IOException("No metadata!");
		}

	}

	public void close() throws IOException {
		if (is != null) {
			try {
				is.close();
			} finally {
				is = null;
			}
		}
	}
}
