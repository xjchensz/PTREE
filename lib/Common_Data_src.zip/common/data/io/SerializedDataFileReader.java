/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import common.data.DataConfiguration;
import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.data.meta.MetaData;
import common.utils.io.BufferedRandomAccessFile;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class SerializedDataFileReader<T extends IInstance> implements
		IDataIterator<T> {

	private MetaData metaData;
	protected BufferedRandomAccessFile braf;

	/**
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * 
	 */
	public SerializedDataFileReader(File directory) throws IOException {
		DataInputStream input = null;
		try {
			input = new DataInputStream(new BufferedInputStream(
					new FileInputStream(
							SerializedDataConstants.metaDataFile(directory)),
					DataConfiguration.BUFFER_SIZE));
			metaData = MetaData.readMetaData(input);
		} finally {
			if (input != null) {
				input.close();
			}
		}

		if (metaData == null) {
			throw new IOException("No metaData!");
		}
		braf = new BufferedRandomAccessFile(
				SerializedDataConstants.dataFile(directory), "r");
	}

	private T instance;

	public MetaData getMetaData() {
		return metaData;
	}

	@Override
	public boolean hasNext() {
		readInstance();
		return instance != null;
	}

	@Override
	public T next() {
		readInstance();
		T ret = instance;
		instance = null;
		return ret;
	}

	protected void readInstance() {
		if (instance == null) {
			try {
				instance = (T) metaData.readInstance(braf, null);
			} catch (IOException e) {
			}
		}
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void reset() throws IOException {
		braf.seek(0);
	}

	@Override
	public void close() throws Exception {
		if (braf != null) {
			braf.close();
			braf = null;
		}
	}

	@Override
	public boolean isClosed() {
		return braf == null;
	}

}
