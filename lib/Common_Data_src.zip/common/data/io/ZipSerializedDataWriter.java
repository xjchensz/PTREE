/**
 * Created by Xiaojun Chen at 2012-3-23
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.io;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;

import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.utils.io.NullOutputStream;

/**
 * 
 * @author Xiaojun Chen
 * @version 1..0.0
 * 
 *          the structure of the input stream: FLAG
 *          (DATA/META_DATA/META_DATA_INDEX) if the FLAG is DATA, then the
 *          following part is only the data, if the FLAG is META_DATA, then the
 *          following is the start pointer of data, the metadata and the data;
 *          if the FLAG is META_DATA_INDEX, then the following part is the start
 *          pointer of data, the start pointer of data index, the metadata, the
 *          data and the data index;
 */
public class ZipSerializedDataWriter {

	public static final String META_INF = "META_INF";

	private IDataIterator<? extends IInstance> dataIterator;

	public ZipSerializedDataWriter(
			IDataIterator<? extends IInstance> dataIterator) {
		this.dataIterator = dataIterator;
	}

	public void writeToFile(File file) throws IOException, ArchiveException {
		writeToFile(file, true);
	}

	public void writeToFile(File file, boolean writeMetaData)
			throws IOException, ArchiveException {
		if (!file.exists()) {
			file.createNewFile();
		}
		FileOutputStream bos = new FileOutputStream(file);
		try {
			writeToOutputStream(bos, writeMetaData);
		} finally {
			if (bos != null) {
				bos.close();
			}
		}
	}

	public void writeToOutputStream(OutputStream os, boolean writeMetaData)
			throws IOException, ArchiveException {
		if (dataIterator == null) {
			throw new NullPointerException("Empty data!");
		}

		DataOutputStream dos = new DataOutputStream(new NullOutputStream());
		dataIterator.getMetaData().write(dos);
		int metaSize = dos.size();

		ArchiveOutputStream zos = new ArchiveStreamFactory()
				.createArchiveOutputStream(ArchiveStreamFactory.ZIP,
						new BufferedOutputStream(os));

		dos = new DataOutputStream(zos);
		// write meta_inf entry
		zos.putArchiveEntry(new ZipArchiveEntry(META_INF));
		if (writeMetaData) {
			dos.write(SerializedDataConstants.META_DATA);
			dos.writeLong(metaSize);
		} else {
			dos.write(SerializedDataConstants.DATA);
		}

		zos.closeArchiveEntry();

		if (writeMetaData) {
			// write metadata entry
			zos.putArchiveEntry(new ZipArchiveEntry(
					SerializedDataConstants.META_FILE));
			dataIterator.getMetaData().write(dos);
			zos.closeArchiveEntry();
		}

		// write data entry
		zos.putArchiveEntry(new ZipArchiveEntry(
				SerializedDataConstants.DATA_FILE));
		while (dataIterator.hasNext()) {
			dataIterator.next().write(dos);
		}
		zos.closeArchiveEntry();
		zos.close();
		dos.close();
	}

	public void close(boolean closeData) throws Exception {
		if (closeData && dataIterator != null) {
			try {
				dataIterator.close();
			} finally {
				dataIterator = null;
			}
		}
		dataIterator = null;
	}
}
