/**
 * Created by Xiaojun Chen at 2012-6-19
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data;

import common.data.instance.IInstance;
import common.data.meta.MetaData;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class SingleInstanceData<T extends IInstance> implements
		IDataIterator<T> {

	private T ins;
	private T current;

	/**
	 * 
	 */
	public SingleInstanceData(T ins) {
		this.ins = ins;
		current = ins;
	}

	@Override
	public boolean hasNext() {
		return current != null;
	}

	@Override
	public T next() {
		T ret = current;
		current = null;
		return ret;
	}

	@Override
	public void remove() {
		current = null;
	}

	@Override
	public void reset() throws Exception {
		current = ins;
	}

	@Override
	public MetaData getMetaData() {
		return ins.getMetaData();
	}

	@Override
	public void close() throws Exception {
		ins = null;
		current = null;
	}

	@Override
	public boolean isClosed() {
		return ins == null;
	}

}
