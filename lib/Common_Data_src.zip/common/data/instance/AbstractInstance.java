/**
 * Created by Xiaojun Chen at 2011-11-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance;

import common.data.meta.MetaData;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public abstract class AbstractInstance implements IInstance {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6088771161384083377L;

	protected int m_ID;

	protected MetaData m_MetaData;

	/**
	 * 
	 */
	public AbstractInstance(int id, MetaData metaData) {
		if (metaData == null) {
			throw new NullPointerException("Null MetaData!");
		}
		this.m_MetaData = metaData;
		this.m_ID = id;
	}

	protected AbstractInstance(MetaData metaData) {
		if (metaData == null) {
			throw new NullPointerException("Null MetaData!");
		}
		this.m_MetaData = metaData;
	}

	@Override
	public MetaData getMetaData() {
		return m_MetaData;
	}

	@Override
	public int getID() {
		return m_ID;
	}

	public abstract IInstance clone();

	/**
	 * Get the string of attributes for the instance
	 * 
	 * @return the string of instance
	 */
	public String toString() {
		return toFileRecordString();
	}

	@Override
	public int hashCode() {
		return m_ID;
	}
}
