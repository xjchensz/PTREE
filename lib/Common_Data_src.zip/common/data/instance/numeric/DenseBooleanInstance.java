/**
 * Created by Xiaojun Chen at 2012-7-2
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.numeric;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Iterator;

import common.data.instance.IInstance;
import common.data.instance.math.CardinalityException;
import common.data.instance.math.EmptyValueException;
import common.data.instance.math.UnexpectedInstanceTypeException;
import common.data.instance.numeric.sparse.INonEmptyValueHandler;
import common.data.meta.MetaData;
import common.utils.collection.ORDER;
import common.utils.collection.OrderedIntArraySet;
import common.utils.entry.IBooleanEntry;
import common.utils.entry.INumericEntry;
import common.utils.math.Varint;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class DenseBooleanInstance extends AbstractNumericInstance implements
		IBooleanInstance {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9038673840424990475L;

	// store all values
	protected boolean[] m_Values;

	private long m_NoOfOccurrence = 1;
	private double m_Label = -1;

	public DenseBooleanInstance(int id, MetaData metaData) {
		this(id, metaData, new boolean[metaData.numAllAttributes()], -1);
	}

	/**
	 * 
	 */
	public DenseBooleanInstance(int id, MetaData metaData, boolean[] values) {
		this(id, metaData, values, -1);
	}

	/**
	 * 
	 */
	public DenseBooleanInstance(int id, MetaData metaData, boolean[] values,
			double label) {
		super(id, metaData);
		this.m_Values = values;
		this.m_Label = label;
	}

	protected DenseBooleanInstance(MetaData metadata) {
		super(metadata);
	}

	@Override
	public int size() {
		if (m_Label >= 0) {
			return m_Values.length + 1;
		} else {
			return m_Values.length;
		}
	}

	@Override
	public void assign(IInstance other) throws EmptyValueException,
			UnexpectedInstanceTypeException, CardinalityException {

		if (!(other instanceof DenseBooleanInstance)) {
			throw new UnexpectedInstanceTypeException(
					DenseBooleanInstance.class, other.getClass());
		}

		DenseBooleanInstance bsi = (DenseBooleanInstance) other;

		if (bsi.size() == 0) {
			throw new EmptyValueException();
		}

		m_Values = bsi.booleanValues();

	}

	@Override
	public void setValue(int attr, boolean value) {
		if (attr < 0 || attr >= m_Values.length) {
			throw new ArrayIndexOutOfBoundsException();
		}

		m_Values[attr] = value;
	}

	@Override
	public void setLabel(double label) {
		m_Label = label;
	}

	@Override
	public double getLabel() {
		int lableId = m_MetaData.getLabelId();
		if (lableId < 0) {
			return -1;
		}
		return m_Label;
	}

	@Override
	public boolean trueValue(int attr) {
		if (attr < 0 || attr >= m_Values.length) {
			throw new ArrayIndexOutOfBoundsException();
		}
		return m_Values[attr];
	}

	@Override
	public String stringValue(int attr) {
		if (m_MetaData.getLabelId() == attr) {
			// label
			return String.valueOf(m_Label);
		} else {
			return m_Values[attr] ? "true" : "false";
		}
	}

	@Override
	public int[] getAllTrueAttributes() {
		OrderedIntArraySet list = new OrderedIntArraySet(ORDER.ASC);
		for (int i = 0; i < m_Values.length; i++) {
			if (m_Values[i]) {
				list.add(i);
			}
		}
		int[] attrs = list.values();
		list.destroy();
		return attrs;
	}

	@Override
	public int[] getAllFalseAttributes() {
		OrderedIntArraySet list = new OrderedIntArraySet(ORDER.ASC);
		for (int i = 0; i < m_Values.length; i++) {
			if (!m_Values[i]) {
				list.add(i);
			}
		}
		int[] attrs = list.values();
		list.destroy();
		return attrs;

	}

	@Override
	public boolean[] booleanValues() {
		boolean[] values = new boolean[m_Values.length];
		System.arraycopy(m_Values, 0, values, 0, values.length);
		if (m_MetaData.numIgnored() > 0) {
			int[] ignored = m_MetaData.getIgnored();
			for (int i = 0; i < ignored.length; i++) {
				values[ignored[i]] = false;
			}
		}
		return values;
	}

	@Override
	public boolean containAttribute(int attribute) {
		if (attribute < 0 || attribute >= m_Values.length)
			return false;
		return true;
	}

	@Override
	public Iterator<? extends IBooleanEntry> iterateValues() {
		return new Iterator<IBooleanEntry>() {
			int ptr = 0;

			@Override
			public boolean hasNext() {
				return ptr < m_Values.length;
			}

			@Override
			public IBooleanEntry next() {
				final int index = ptr++;
				return new IBooleanEntry() {

					@Override
					public boolean setValue(boolean newValue) {
						boolean oldValue = m_Values[index];
						m_Values[index] = newValue;
						return oldValue;
					}

					@Override
					public int getAttribute() {
						return index;
					}

					@Override
					public boolean getValue() {
						return m_Values[index];
					}

					@Override
					public double doubleValue() {
						return m_Values[index] ? 1 : 0;
					}

					@Override
					public void times(double m) {
						// do nothing
					}

					@Override
					public void divide(double m) {
						// do nothing
					}
				};
			}

			@Override
			public void remove() {

			}
		};
	}

	@Override
	public double doubleValue(int attr) {
		if (attr >= 0 && attr < m_Values.length) {
			return m_Values[attr] ? 1 : 0;
		} else if (attr == m_Values.length) {
			return getLabel();
		} else {
			throw new ArrayIndexOutOfBoundsException();
		}

	}

	@Override
	public void setValue(int attribute, double value) {
		if (value <= 0) {
			m_Values[attribute] = false;
		} else {
			m_Values[attribute] = true;
		}
	}

	@Override
	public void setErrorValue(int attribute) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isErrorValue(int attribute) {
		return false;
	}

	@Override
	public void assign(INumericEntry entry) throws CardinalityException {
		if (entry instanceof IBooleanEntry) {
			m_Values[entry.getAttribute()] = ((IBooleanEntry) entry).getValue();
		} else {
			setValue(entry.getAttribute(), entry.doubleValue());
		}
	}

	@Override
	public void plus(INumericEntry entry) throws CardinalityException {
		int attr = entry.getAttribute();
		if (!m_Values[attr]) {
			if (entry instanceof IBooleanEntry
					&& ((IBooleanEntry) entry).getValue()) {
				m_Values[attr] = true;
			} else {
				setValue(attr, entry.doubleValue());
			}
		}
	}

	@Override
	public void minus(INumericEntry entry) throws CardinalityException {
		int attr = entry.getAttribute();
		if (m_Values[attr]) {
			if (entry instanceof IBooleanEntry
					&& ((IBooleanEntry) entry).getValue()) {
				m_Values[attr] = false;
			} else {
				if (entry.doubleValue() > 0) {
					m_Values[attr] = false;
				}
			}
		}
	}

	@Override
	public void times(INumericEntry entry) {
		int attr = entry.getAttribute();
		if (m_Values[attr]) {
			if (entry instanceof IBooleanEntry
					&& !((IBooleanEntry) entry).getValue()) {
				m_Values[attr] = false;
			} else {
				if (entry.doubleValue() <= 0) {
					m_Values[attr] = false;
				}
			}
		}
	}

	@Override
	public void divide(INumericEntry entry) {
		// non-change
	}

	@Override
	public void processNonEmptyValues(INonEmptyValueHandler handler) {
		int size = size();
		for (int i = 0; i < size; i++) {
			handler.handle(i, m_Values[i] ? 1 : 0);
		}
	}

	@Override
	protected void logNormalize(double power, double normLength) {
		// non-change
	}

	@Override
	public void setOccurrence(long noOfOccurrence)
			throws IllegalArgumentException {
		if (noOfOccurrence <= 0) {
			throw new IllegalArgumentException(
					"The argument should be more than 0!");
		}
		m_NoOfOccurrence = noOfOccurrence;
	}

	@Override
	public long numOfOccurrence() {
		return m_NoOfOccurrence;
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		m_ID = Varint.readUnsignedVarInt(in);
		int size = Varint.readUnsignedVarInt(in);
		m_Values = new boolean[size];
		for (int i = 0; i < size; i++) {
			m_Values[i] = in.readBoolean();
		}
		m_NoOfOccurrence = Varint.readUnsignedVarLong(in);
		m_Label = in.readDouble();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		Varint.writeUnsignedVarInt(getID(), out);
		Varint.writeUnsignedVarInt(m_Values.length, out);
		for (int i = 0; i < m_Values.length; i++) {
			out.writeBoolean(m_Values[i]);
		}
		Varint.writeUnsignedVarLong(m_NoOfOccurrence, out);
		out.writeDouble(m_Label);
	}

	@Override
	public int getStoreBytes() {
		int numBytes = Varint.numBytesToWriteUnsignedVarInt(getID())
				+ Varint.numBytesToWriteUnsignedVarInt(m_Values.length)
				+ m_Values.length
				+ Varint.numBytesToWriteUnsignedVarLong(m_NoOfOccurrence)
				+ Double.SIZE / 8;
		return numBytes;
	}

	@Override
	public String toSQLString() {
		StringBuilder sb = new StringBuilder();
		sb.append(m_ID).append(MetaData.SEPARATOR_DATA);
		for (int i = 0; i < m_Values.length; i++) {
			if (!m_MetaData.isIgnored(i)) {
				sb.append(m_Values[i]).append(MetaData.SEPARATOR_DATA);
			}
		}
		sb.append(m_NoOfOccurrence);
		return sb.toString();
	}

	@Override
	public String toFileRecordString() {
		StringBuilder sb = new StringBuilder();
		sb.append(m_ID).append(MetaData.SEPARATOR_ID);
		for (int i = 0; i < m_Values.length; i++) {
			sb.append(m_Values[i]).append(MetaData.SEPARATOR_DATA);
		}
		sb.append(m_NoOfOccurrence);
		return sb.toString();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof DenseBooleanInstance)) {
			return false;
		}

		DenseBooleanInstance instance = (DenseBooleanInstance) obj;
		if (!instance.m_MetaData.equals(m_MetaData)) {
			return false;
		}

		if (m_Values.length == instance.m_Values.length) {
			for (int i = 0; i < m_Values.length; i++) {
				if (m_Values[i] != instance.m_Values[i]) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	@Override
	public boolean equalsInAttribute(Object obj, int attributeIndex) {

		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof DenseBooleanInstance)) {
			return false;
		}

		DenseBooleanInstance instance = (DenseBooleanInstance) obj;
		if (!instance.m_MetaData.equals(m_MetaData)) {
			return false;
		}

		return m_Values[attributeIndex] != instance.m_Values[attributeIndex];
	}

	@Override
	public DenseBooleanInstance like() {
		return new DenseBooleanInstance(getID(), getMetaData(),
				new boolean[m_Values.length]);
	}

	@Override
	public DenseBooleanInstance clone() {
		boolean[] values = new boolean[m_Values.length];
		System.arraycopy(m_Values, 0, values, 0, values.length);
		DenseBooleanInstance db = new DenseBooleanInstance(getID(),
				getMetaData(), values, getLabel());
		db.m_NoOfOccurrence = this.m_NoOfOccurrence;
		return db;
	}

	@Override
	public void clear() {
		m_Values = new boolean[m_Values.length];
		m_Label = -1;
		m_NoOfOccurrence = 1;
	}

	@Override
	public void destroy() {
		m_Values = null;
	}

	public static DenseBooleanInstance read(DataInput in, MetaData metaData,
			DenseBooleanInstance instance) throws IOException {
		if (instance == null) {
			instance = new DenseBooleanInstance(metaData);
		}
		instance.readFields(in);
		return instance;
	}

	public static DenseBooleanInstance parseText(MetaData metaData, int ID,
			String[] text, DenseBooleanInstance instance) {

		if (text != null) {
			if (instance == null) {
				instance = new DenseBooleanInstance(ID, metaData);
			}
			instance.m_ID = ID;
			for (String t : text) {
				try {
					instance.setValue(Integer.parseInt(t), true);
				} catch (NumberFormatException e) {

				}
			}
			return instance;
		}
		return null;
	}

	public static DenseBooleanInstance emptyInstance(MetaData metaData) {
		return new DenseBooleanInstance(metaData);
	}

}
