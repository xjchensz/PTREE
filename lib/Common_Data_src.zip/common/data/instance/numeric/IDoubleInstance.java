/**
 * Created by Xiaojun Chen at 2012-6-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.numeric;

import java.util.Iterator;

import common.utils.entry.IDoubleEntry;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public interface IDoubleInstance extends INumericInstance {

	/**
	 * Returns all used values, excluding label
	 * 
	 * @return the array of all values
	 */
	public double[] getUsedValues();

	/**
	 * Returns all values, including label
	 * 
	 * @return the array of all values
	 */
	public double[] getAllValues();

	/**
	 * Iterate all values
	 * */
	public Iterator<IDoubleEntry> iterateValues();

	/**
	 * Clone instance
	 * */
	public IDoubleInstance clone();

	/**
	 * @return a new value with all elements as zero
	 * 
	 * */
	public IDoubleInstance like();
}
