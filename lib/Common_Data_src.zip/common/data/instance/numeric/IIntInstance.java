/**
 * Created by Xiaojun Chen at 2012-6-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.numeric;

import java.util.Iterator;

import common.utils.entry.IIntEntry;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public interface IIntInstance extends INumericInstance {

	/**
	 * Set the value of attribute
	 * 
	 * @param attribute
	 *            the index of attribute
	 * @param value
	 *            a given value
	 */
	public void setValue(int attribute, int value);

	/**
	 * Get the value of attribute
	 * 
	 * @param attribute
	 *            the index of attribute
	 * @return the value of attribute
	 */
	public int getValue(int attribute);

	/**
	 * Returns all used values, excluding label
	 * 
	 * @return the array of all values
	 */
	public int[] getUsedValues();

	/**
	 * Returns all values, including label
	 * 
	 * @return the array of all values
	 */
	public int[] getAllValues();

	/**
	 * Iterate all values
	 * */
	public Iterator<IIntEntry> iterateValues();

	/**
	 * Clone instance
	 * */
	public IIntInstance clone();

	/**
	 * @return a new value with all elements as zero
	 * 
	 * */
	public IIntInstance like();
}
