/**
 * Created by Xiaojun Chen at 2012-6-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.numeric;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Iterator;

import common.data.instance.math.CardinalityException;
import common.data.instance.numeric.sparse.INonEmptyValueHandler;
import common.data.meta.BooleanAttribute;
import common.data.meta.CountAttribute;
import common.data.meta.IAttribute;
import common.data.meta.MetaData;
import common.data.meta.NominalAttribute;
import common.utils.entry.IIntEntry;
import common.utils.entry.INumericEntry;
import common.utils.math.Varint;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class DenseIntInstance extends AbstractNumericInstance implements
		IIntInstance {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1108937968466877936L;
	protected int[] m_Values;

	public DenseIntInstance(int id, MetaData metaData) {
		this(id, metaData, new int[metaData.numAllAttributes()]);
	}

	/**
	 * @param metaData
	 * @param id
	 */
	public DenseIntInstance(int id, MetaData metaData, int[] values) {
		super(id, metaData);
		m_Values = values;
	}

	/**
	 * @param metaData
	 */
	protected DenseIntInstance(MetaData metaData) {
		super(metaData);
	}

	/**
	 * Set the value at the given index
	 * 
	 * @param index
	 *            the index of the attribute
	 * @param value
	 *            a double value to set
	 */
	public void set(int index, int value) {
		m_Values[index] = value;
	}

	@Override
	public void setLabel(double label) {
		int labelId = m_MetaData.getLabelId();
		if (labelId < 0 || labelId > m_Values.length) {
			throw new IllegalArgumentException("No label attribute!");
		}
		m_Values[labelId] = (int) label;
	}

	public double getLabel() {
		int index = m_MetaData.getLabelId();
		if (index < 0) {
			return -1;
		} else {
			return (int) m_Values[index];
		}
	}

	@Override
	public int size() {
		return m_Values.length;
	}

	@Override
	public void setValue(int attribute, int value) {
		m_Values[attribute] = value;
	}

	@Override
	public void setValue(int attribute, double value) {
		m_Values[attribute] = (int) value;
	}

	@Override
	public int getValue(int attribute) {
		return m_Values[attribute];
	}

	@Override
	public double doubleValue(int attribute) {
		return m_Values[attribute];
	}

	@Override
	public void processNonEmptyValues(INonEmptyValueHandler handler) {
		int size = size();
		for (int i = 0; i < size; i++) {
			handler.handle(i, m_Values[i]);
		}
	}

	@Override
	public String stringValue(int attr) {
		IAttribute attribute = m_MetaData.getAttributeAt(attr);
		switch (attribute.getType()) {
		case NOMINAL:
		case ORDINAL:
			if (m_Values[attr] == NominalAttribute.ERROR_INT_VALUE) {
				return ERROR_VALUE;
			} else {
				return ((NominalAttribute) attribute).decode(m_Values[attr]);
			}

		case COUNT:
			if (m_Values[attr] == CountAttribute.ERROR_INT_VALUE) {
				return ERROR_VALUE;
			} else {
				return String.valueOf((int) m_Values[attr]);
			}
		case BOOLEAN:
			if (m_Values[attr] == BooleanAttribute.ERROR_INT_VALUE) {
				return ERROR_VALUE;
			} else {
				return m_Values[attr] == 1 ? "true" : "false";
			}

		case NUMERIC:
		default:
			return String.valueOf(m_Values[attr]);
		}
	}

	@Override
	public boolean containAttribute(int attribute) {
		if (attribute < 0 || attribute >= m_Values.length)
			return false;
		return true;
	}

	@Override
	public int[] getUsedValues() {
		int numUsedAttributes = m_MetaData.numUsedAttributes();
		if (numUsedAttributes == m_Values.length) {
			return m_Values;
		} else {
			int ptr = 0;
			int[] usedValues = new int[numUsedAttributes];
			int labelID = m_MetaData.getLabelId();

			for (int i = 0; i < labelID; i++) {
				if (!m_MetaData.getAttributeAt(i).isIgnored()) {
					usedValues[ptr++] = m_Values[i];
				}
			}
			for (int i = labelID >= 0 ? labelID + 1 : 0; i < m_Values.length; i++) {
				if (!m_MetaData.getAttributeAt(i).isIgnored()) {
					usedValues[ptr++] = m_Values[i];
				}
			}
			return usedValues;
		}
	}

	@Override
	public int[] getAllValues() {
		return m_Values;
	}

	@Override
	public void setErrorValue(int attribute) {
		IAttribute attr = m_MetaData.getAttributeAt(attribute);
		switch (attr.getType()) {
		case NOMINAL:
		case ORDINAL:
			m_Values[attribute] = NominalAttribute.ERROR_INT_VALUE;
			break;
		case COUNT:
			m_Values[attribute] = CountAttribute.ERROR_INT_VALUE;
		case BOOLEAN:
			m_Values[attribute] = BooleanAttribute.ERROR_INT_VALUE;
			break;
		case NUMERIC:
		default:
			throw new UnsupportedOperationException();
		}
	}

	@Override
	public boolean isErrorValue(int attribute) {
		IAttribute attr = m_MetaData.getAttributeAt(attribute);
		switch (attr.getType()) {
		case NOMINAL:
		case ORDINAL:
			return m_Values[attribute] == NominalAttribute.ERROR_INT_VALUE;
		case COUNT:
			return m_Values[attribute] == CountAttribute.ERROR_INT_VALUE;
		case BOOLEAN:
			return m_Values[attribute] == BooleanAttribute.ERROR_INT_VALUE;
		case NUMERIC:
		default:
			return false;
		}
	}

	@Override
	public void assign(INumericEntry entry) throws CardinalityException {
		if (entry instanceof IIntEntry) {
			m_Values[entry.getAttribute()] = ((IIntEntry) entry).getValue();
		} else {
			m_Values[entry.getAttribute()] = (int) entry.doubleValue();
		}
	}

	@Override
	public void plus(INumericEntry entry) throws CardinalityException {
		if (entry instanceof IIntEntry) {
			m_Values[entry.getAttribute()] += ((IIntEntry) entry).getValue();
		} else {
			m_Values[entry.getAttribute()] += entry.doubleValue();
		}
	}

	@Override
	public void minus(INumericEntry entry) throws CardinalityException {
		if (entry instanceof IIntEntry) {
			m_Values[entry.getAttribute()] -= ((IIntEntry) entry).getValue();
		} else {
			m_Values[entry.getAttribute()] -= entry.doubleValue();
		}
	}

	@Override
	public void times(INumericEntry entry) {
		if (entry instanceof IIntEntry) {
			m_Values[entry.getAttribute()] *= ((IIntEntry) entry).getValue();
		} else {
			m_Values[entry.getAttribute()] *= entry.doubleValue();
		}
	}

	@Override
	public void divide(INumericEntry entry) {
		if (entry instanceof IIntEntry) {
			m_Values[entry.getAttribute()] /= ((IIntEntry) entry).getValue();
		} else {
			m_Values[entry.getAttribute()] /= entry.doubleValue();
		}
	}

	protected void logNormalize(double power, double normLength) {
		// we can special case certain powers
		if (Double.isInfinite(power) || power <= 1.0) {
			throw new IllegalArgumentException(
					"Power must be > 1 and < infinity");
		} else {
			double denominator = normLength * Math.log(power);
			for (int i = 0; i < m_Values.length; i++) {
				m_Values[i] = (int) (Math.log(1 + m_Values[i]) / denominator);
			}
		}
	}

	@Override
	public Iterator<IIntEntry> iterateValues() {
		return new Iterator<IIntEntry>() {
			int ptr = 0;
			int prt_Class = DenseIntInstance.this.getMetaData().getLabelId();

			@Override
			public boolean hasNext() {
				if (ptr == prt_Class) {
					ptr++;
				}
				return ptr < m_Values.length;
			}

			@Override
			public IIntEntry next() {
				final int index = ptr++;
				return new IIntEntry() {

					@Override
					public int setValue(int newValue) {
						int oldValue = m_Values[index];
						m_Values[index] = newValue;
						return oldValue;
					}

					@Override
					public int getAttribute() {
						return index;
					}

					@Override
					public int getValue() {
						return m_Values[index];
					}

					@Override
					public double doubleValue() {
						return m_Values[index];
					}

					@Override
					public void times(double m) {
						m_Values[index] *= m;
					}

					@Override
					public void divide(double m) {
						m_Values[index] /= m;
					}
				};
			}

			@Override
			public void remove() {

			}
		};
	}

	@Override
	public DenseIntInstance like() {
		int[] values = null;
		if (m_Values != null) {
			values = new int[m_Values.length];
		}
		return new DenseIntInstance(m_ID, m_MetaData, values);
	}

	@Override
	public void clear() {
		for (int i = 0; i < m_Values.length; i++) {
			m_Values[i] = 0;
		}
	}

	@Override
	public void destroy() {
		m_MetaData = null;
		m_Values = null;
	}

	public DenseIntInstance clone() {
		int[] values = null;
		if (m_Values != null) {
			values = new int[m_Values.length];
			System.arraycopy(m_Values, 0, values, 0, m_Values.length);
		}
		return new DenseIntInstance(m_ID, m_MetaData, values);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof DenseIntInstance)) {
			return false;
		}

		DenseIntInstance instance = (DenseIntInstance) obj;
		if (!instance.m_MetaData.equals(m_MetaData)) {
			return false;
		}

		if (m_Values.length == instance.m_Values.length) {
			for (int i = 0; i < m_Values.length; i++) {
				if (m_Values[i] != instance.m_Values[i]) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	@Override
	public boolean equalsInAttribute(Object obj, int attributeIndex) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof DenseIntInstance)) {
			return false;
		}

		DenseIntInstance instance = (DenseIntInstance) obj;
		if (!instance.m_MetaData.equals(m_MetaData)) {
			return false;
		}

		return m_Values[attributeIndex] != instance.m_Values[attributeIndex];
	}

	@Override
	public String toSQLString() {
		StringBuilder sb = new StringBuilder();

		sb.append(m_ID).append(MetaData.SEPARATOR_DATA);

		for (int i = 0; i < m_Values.length; i++) {
			sb.append(getValue(i)).append(MetaData.SEPARATOR_DATA);
		}
		sb.setLength(sb.length() - 1);
		return sb.toString();
	}

	@Override
	public String toFileRecordString() {
		StringBuilder sb = new StringBuilder();

		sb.append(m_ID).append(MetaData.SEPARATOR_ID);
		for (int i = 0; i < m_Values.length; i++) {
			if (m_MetaData.isIgnored(i)) {
				sb.append(stringValue(i)).append(MetaData.SEPARATOR_DATA);
			}
		}
		sb.setLength(sb.length() - 1);
		return sb.toString();
	}

	@Override
	public void readFields(DataInput input) throws IOException {
		m_ID = Varint.readUnsignedVarInt(input);
		int length = Varint.readUnsignedVarInt(input);
		m_Values = new int[length];
		for (int i = 0; i < length; i++) {
			switch (m_MetaData.getAttributeTypeAt(i)) {
			case COUNT:
			case NOMINAL:
			case ORDINAL:
				m_Values[i] = Varint.readUnsignedVarInt(input);
				break;
			case BOOLEAN:
				m_Values[i] = input.readBoolean() ? 1 : 0;
				break;
			case NUMERIC:
			default:
				m_Values[i] = Varint.readSignedVarInt(input);
				break;
			}
		}
	}

	@Override
	public void write(DataOutput out) throws IOException {
		Varint.writeUnsignedVarInt(getID(), out);
		if (m_Values == null || m_Values.length == 0) {
			Varint.writeUnsignedVarInt(0, out);
		} else {
			Varint.writeUnsignedVarInt(m_Values.length, out);
			for (int i = 0; i < m_Values.length; i++) {
				switch (m_MetaData.getAttributeTypeAt(i)) {
				case COUNT:
				case NOMINAL:
				case ORDINAL:
					Varint.writeUnsignedVarInt(m_Values[i], out);
					break;

				case BOOLEAN:
					out.writeBoolean(m_Values[i] == 1 ? true : false);
					break;
				case NUMERIC:
				default:
					Varint.writeSignedVarInt(m_Values[i], out);
					break;
				}
			}
		}
	}

	@Override
	public int getStoreBytes() {
		int numBytes = Varint.numBytesToWriteUnsignedVarInt(getID());
		if (m_Values == null || m_Values.length == 0) {
			numBytes += Varint.numBytesToWriteUnsignedVarInt(0);
		} else {
			numBytes += Varint.numBytesToWriteUnsignedVarInt(m_Values.length);
			for (int i = 0; i < m_Values.length; i++) {
				// Count data write as int
				switch (m_MetaData.getAttributeTypeAt(i)) {
				case COUNT:
				case NOMINAL:
				case ORDINAL:
					numBytes += Varint
							.numBytesToWriteUnsignedVarInt(m_Values[i]);
					break;
				case NUMERIC:
					numBytes += Varint.numBytesToWriteSignedVarInt(m_Values[i]);
					break;
				case BOOLEAN:
					numBytes++;
					break;
				}
			}
		}
		return numBytes;
	}

	public static DenseIntInstance read(DataInput in, MetaData metaData,
			DenseIntInstance instance) throws IOException {
		if (instance == null) {
			instance = new DenseIntInstance(metaData);
		}
		instance.readFields(in);
		return instance;
	}

	public static DenseIntInstance parseText(MetaData metaData, int ID,
			String[] text, DenseIntInstance instance) {

		if (text != null) {
			if (instance == null) {
				instance = new DenseIntInstance(ID, metaData);
			}
			instance.m_ID = ID;
			IAttribute[] attributes = metaData.getAttributes();
			IAttribute attr;
			int i = 0;
			for (; i < attributes.length && i < text.length; i++) {
				attr = attributes[i];
				switch (attr.getType()) {
				case COUNT:
					try {
						instance.setValue(i, Integer.parseInt(text[i]));
					} catch (NumberFormatException e) {
						instance.setErrorValue(i);
					}

					break;
				case NOMINAL:
				case ORDINAL:
					if (text[i] == null || text[i].isEmpty()) {
						instance.setErrorValue(i);
					} else {
						instance.setValue(i,
								((NominalAttribute) attr).encode(text[i], true));
					}

					break;
				case BOOLEAN:
					if (text[i] == null || text[i].isEmpty()) {
						instance.setValue(i, -1);
					} else {
						try {
							instance.setValue(i,
									Boolean.parseBoolean(text[i]) ? 1 : 0);
						} catch (NumberFormatException e) {
							instance.setErrorValue(i);
						}
					}

					break;
				case NUMERIC:
				default:
					try {
						instance.setValue(i, Integer.parseInt(text[i]));
					} catch (NumberFormatException e) {
						instance.setErrorValue(i);
					}
					break;
				}
			}
			for (; i < attributes.length; i++) {
				// missing values
				instance.setErrorValue(i);
			}
			return instance;
		}
		return null;
	}

	public static DenseIntInstance emptyInstance(MetaData metaData) {
		return new DenseIntInstance(metaData);
	}

}
