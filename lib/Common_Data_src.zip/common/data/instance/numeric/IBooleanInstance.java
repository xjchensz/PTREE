/**
 * Created by Xiaojun Chen at 2012-7-2
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.numeric;


/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public interface IBooleanInstance extends INumericInstance {

	/**
	 * set value for the given attribute
	 * */
	public void setValue(int attr, boolean value);

	/**
	 * @return whether the given attribute has value of true
	 * */
	public boolean trueValue(int attr);

	/**
	 * @return all true attributes
	 * */
	public int[] getAllTrueAttributes();

	/**
	 * @return all false attributes
	 * */
	public int[] getAllFalseAttributes();

	/**
	 * @return all boolean values
	 * */
	public boolean[] booleanValues();

	/**
	 * set the no. of occurrence of this instance in the whole data set.
	 * */
	public void setOccurrence(long noOfOccurrence);

	/**
	 * no. of occurrence in the whole data set, default is set as 1.
	 * */
	public long numOfOccurrence();

	/**
	 * Clone instance
	 * */
	public IBooleanInstance clone();

	/**
	 * @return a new value with all elements as zero
	 * 
	 * */
	public IBooleanInstance like();

}
