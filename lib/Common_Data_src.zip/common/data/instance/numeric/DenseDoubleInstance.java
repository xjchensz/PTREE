package common.data.instance.numeric;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Iterator;

import common.data.instance.math.CardinalityException;
import common.data.instance.numeric.sparse.INonEmptyValueHandler;
import common.data.meta.BooleanAttribute;
import common.data.meta.CountAttribute;
import common.data.meta.IAttribute;
import common.data.meta.MetaData;
import common.data.meta.NominalAttribute;
import common.data.meta.NumericAttribute;
import common.utils.entry.IDoubleEntry;
import common.utils.entry.INumericEntry;
import common.utils.math.Varint;

/**
 * Represents one non-sparse instance for Data.
 * 
 * @author Xiaojun Chen
 */
public class DenseDoubleInstance extends AbstractNumericInstance implements
		IDoubleInstance {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8248492300766598207L;
	/**
	 * attributes, all values.
	 */
	protected double[] m_Values;

	public DenseDoubleInstance(int id, MetaData metaData) {
		this(id, metaData, new double[metaData.numAllAttributes()]);
	}

	public DenseDoubleInstance(int id, MetaData metaData, double[] values) {
		super(id, metaData);
		this.m_Values = values;
	}

	protected DenseDoubleInstance(MetaData metaData) {
		super(metaData);
	}

	@Override
	public void setLabel(double label) {
		int labelId = m_MetaData.getLabelId();
		if (labelId < 0 || labelId > m_Values.length) {
			throw new IllegalArgumentException("No label attribute!");
		}
		m_Values[labelId] = label;
	}

	public double getLabel() {
		int index = m_MetaData.getLabelId();
		if (index < 0) {
			return -1;
		} else {
			return (int) m_Values[index];
		}
	}

	@Override
	public int size() {
		return m_Values.length;
	}

	@Override
	public void setValue(int attribute, double value) {
		m_Values[attribute] = value;
	}

	@Override
	public double doubleValue(int attribute) {
		return m_Values[attribute];
	}

	@Override
	public String stringValue(int attr) {
		IAttribute attribute = m_MetaData.getAttributeAt(attr);
		switch (attribute.getType()) {
		case NOMINAL:
		case ORDINAL:
			if (m_Values[attr] == NominalAttribute.ERROR_DOUBLE_VALUE) {
				return ERROR_VALUE;
			} else {
				return ((NominalAttribute) attribute)
						.decode((int) m_Values[attr]);
			}

		case COUNT:
			if (m_Values[attr] == CountAttribute.ERROR_DOUBLE_VALUE) {
				return ERROR_VALUE;
			} else {
				return String.valueOf((int) m_Values[attr]);
			}
		case BOOLEAN:
			if (m_Values[attr] == BooleanAttribute.ERROR_DOUBLE_VALUE) {
				return ERROR_VALUE;
			} else {
				return m_Values[attr] == 1 ? "true" : "false";
			}

		case NUMERIC:
		default:
			if (Double.isNaN(m_Values[attr])) {
				return ERROR_VALUE;
			} else {
				return String.valueOf(m_Values[attr]);
			}
		}
	}

	@Override
	public void setErrorValue(int attribute) {
		IAttribute attr = m_MetaData.getAttributeAt(attribute);
		switch (attr.getType()) {
		case NOMINAL:
		case ORDINAL:
			m_Values[attribute] = NominalAttribute.ERROR_DOUBLE_VALUE;
			break;
		case COUNT:
			m_Values[attribute] = CountAttribute.ERROR_DOUBLE_VALUE;
		case BOOLEAN:
			m_Values[attribute] = BooleanAttribute.ERROR_DOUBLE_VALUE;
			break;
		case NUMERIC:
		default:
			m_Values[attribute] = NumericAttribute.ERROR_DOUBLE_VALUE;
		}
	}

	@Override
	public boolean isErrorValue(int attribute) {
		IAttribute attr = m_MetaData.getAttributeAt(attribute);
		switch (attr.getType()) {
		case NOMINAL:
		case ORDINAL:
			return m_Values[attribute] == NominalAttribute.ERROR_DOUBLE_VALUE;
		case COUNT:
			return m_Values[attribute] == CountAttribute.ERROR_DOUBLE_VALUE;
		case BOOLEAN:
			return m_Values[attribute] == BooleanAttribute.ERROR_DOUBLE_VALUE;
		case NUMERIC:
		default:
			return Double.isNaN(m_Values[attribute]);
		}
	}

	@Override
	public boolean containAttribute(int attribute) {
		if (attribute < 0 || attribute >= m_Values.length)
			return false;
		return true;
	}

	@Override
	public double[] getUsedValues() {
		int numUsedAttributes = m_MetaData.numUsedAttributes();
		if (numUsedAttributes == m_Values.length) {
			return m_Values;
		} else {
			int ptr = 0;
			double[] usedValues = new double[numUsedAttributes];
			int labelID = m_MetaData.getLabelId();
			for (int i = 0; i < labelID; i++) {
				if (!m_MetaData.getAttributeAt(i).isIgnored()) {
					usedValues[ptr++] = m_Values[i];
				}
			}
			for (int i = labelID >= 0 ? labelID + 1 : 0; i < m_Values.length; i++) {
				if (!m_MetaData.getAttributeAt(i).isIgnored()) {
					usedValues[ptr++] = m_Values[i];
				}
			}
			return usedValues;
		}
	}

	@Override
	public double[] getAllValues() {
		return m_Values;
	}

	@Override
	public void assign(INumericEntry entry) throws CardinalityException {
		m_Values[entry.getAttribute()] = entry.doubleValue();
	}

	@Override
	public void plus(INumericEntry entry) throws CardinalityException {
		m_Values[entry.getAttribute()] += entry.doubleValue();
	}

	@Override
	public void minus(INumericEntry entry) throws CardinalityException {
		m_Values[entry.getAttribute()] -= entry.doubleValue();
	}

	@Override
	public void times(INumericEntry entry) {
		m_Values[entry.getAttribute()] *= entry.doubleValue();
	}

	@Override
	public void divide(INumericEntry entry) {
		m_Values[entry.getAttribute()] /= entry.doubleValue();
	}

	@Override
	public void processNonEmptyValues(INonEmptyValueHandler handler) {
		int size = size();
		for (int i = 0; i < size; i++) {
			handler.handle(i, m_Values[i]);
		}
	}

	protected void logNormalize(double power, double normLength) {
		// we can special case certain powers
		if (Double.isInfinite(power) || power <= 1.0) {
			throw new IllegalArgumentException(
					"Power must be > 1 and < infinity");
		} else {
			double denominator = normLength * Math.log(power);
			for (int i = 0; i < m_Values.length; i++) {
				m_Values[i] = Math.log(1 + m_Values[i]) / denominator;
			}
		}
	}

	@Override
	public Iterator<IDoubleEntry> iterateValues() {
		return new Iterator<IDoubleEntry>() {
			int ptr = 0;
			int prt_Class = DenseDoubleInstance.this.getMetaData().getLabelId();

			@Override
			public boolean hasNext() {
				if (ptr == prt_Class) {
					ptr++;
				}
				return ptr < m_Values.length;
			}

			@Override
			public IDoubleEntry next() {
				final int index = ptr++;
				return new IDoubleEntry() {

					@Override
					public double setValue(double newValue) {
						double oldValue = m_Values[index];
						m_Values[index] = newValue;
						return oldValue;
					}

					@Override
					public int getAttribute() {
						return index;
					}

					@Override
					public double doubleValue() {
						return m_Values[index];
					}

					@Override
					public void times(double m) {
						m_Values[index] *= m;
					}

					@Override
					public void divide(double m) {
						m_Values[index] /= m;
					}
				};
			}

			@Override
			public void remove() {

			}
		};
	}

	@Override
	public DenseDoubleInstance like() {
		double[] values = null;
		if (m_Values != null) {
			values = new double[m_Values.length];
		}
		return new DenseDoubleInstance(getID(), m_MetaData, values);
	}

	@Override
	public void clear() {
		for (int i = 0; i < m_Values.length; i++) {
			m_Values[i] = 0;
		}
	}

	@Override
	public void destroy() {
		m_MetaData = null;
		m_Values = null;
	}

	public DenseDoubleInstance clone() {
		double[] values = null;
		if (m_Values != null) {
			values = new double[m_Values.length];
			System.arraycopy(m_Values, 0, values, 0, m_Values.length);
		}
		return new DenseDoubleInstance(m_ID, m_MetaData, values);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof DenseDoubleInstance)) {
			return false;
		}

		DenseDoubleInstance instance = (DenseDoubleInstance) obj;
		if (!instance.m_MetaData.equals(m_MetaData)) {
			return false;
		}

		if (m_Values.length == instance.m_Values.length) {
			for (int i = 0; i < m_Values.length; i++) {
				if (m_Values[i] != instance.m_Values[i]) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	@Override
	public boolean equalsInAttribute(Object obj, int attributeIndex) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof DenseDoubleInstance)) {
			return false;
		}

		DenseDoubleInstance instance = (DenseDoubleInstance) obj;
		if (!instance.m_MetaData.equals(m_MetaData)) {
			return false;
		}

		return m_Values[attributeIndex] != instance.m_Values[attributeIndex];
	}

	@Override
	public String toSQLString() {
		StringBuilder sb = new StringBuilder();

		sb.append(m_ID).append(MetaData.SEPARATOR_DATA);
		for (int i = 0; i < m_Values.length; i++) {
			if (!m_MetaData.isIgnored(i)) {
				sb.append(doubleValue(i)).append(MetaData.SEPARATOR_DATA);
			}
		}
		sb.setLength(sb.length() - 1);
		return sb.toString();
	}

	@Override
	public String toFileRecordString() {
		StringBuilder sb = new StringBuilder();

		sb.append(m_ID).append(MetaData.SEPARATOR_ID);

		for (int i = 0; i < m_Values.length; i++) {
			sb.append(stringValue(i)).append(MetaData.SEPARATOR_DATA);
		}
		sb.setLength(sb.length() - 1);
		return sb.toString();
	}

	@Override
	public void readFields(DataInput input) throws IOException {
		m_ID = Varint.readUnsignedVarInt(input);
		int length = Varint.readUnsignedVarInt(input);
		m_Values = new double[length];
		for (int i = 0; i < length; i++) {
			switch (m_MetaData.getAttributeTypeAt(i)) {
			case COUNT:
			case NOMINAL:
			case ORDINAL:
				m_Values[i] = Varint.readUnsignedVarInt(input);
				break;
			case BOOLEAN:
				m_Values[i] = input.readBoolean() ? 1 : 0;
				break;
			case NUMERIC:
				m_Values[i] = input.readDouble();
				break;
			}
		}
	}

	@Override
	public void write(DataOutput out) throws IOException {
		Varint.writeUnsignedVarInt(getID(), out);
		if (m_Values == null || m_Values.length == 0) {
			Varint.writeUnsignedVarInt(0, out);
		} else {
			Varint.writeUnsignedVarInt(m_Values.length, out);
			for (int i = 0; i < m_Values.length; i++) {
				// Count data write as int
				switch (m_MetaData.getAttributeTypeAt(i)) {
				case COUNT:
				case NOMINAL:
				case ORDINAL:
					Varint.writeUnsignedVarInt((int) m_Values[i], out);
					break;
				case BOOLEAN:
					out.writeBoolean(m_Values[i] == 1 ? true : false);
					break;
				case NUMERIC:
					out.writeDouble(m_Values[i]);
					break;
				}
			}
		}
	}

	@Override
	public int getStoreBytes() {
		int numBytes = Varint.numBytesToWriteUnsignedVarInt(getID());
		if (m_Values == null || m_Values.length == 0) {
			numBytes += Varint.numBytesToWriteUnsignedVarInt(0);
		} else {
			numBytes += Varint.numBytesToWriteUnsignedVarInt(m_Values.length);
			for (int i = 0; i < m_Values.length; i++) {
				// Count data write as int
				switch (m_MetaData.getAttributeTypeAt(i)) {
				case COUNT:
				case NOMINAL:
				case ORDINAL:
					numBytes += Varint
							.numBytesToWriteUnsignedVarInt((int) m_Values[i]);
					break;
				case BOOLEAN:
					numBytes++;
					break;
				case NUMERIC:
					numBytes += Double.SIZE / 8;
					break;
				}
			}
		}
		return numBytes;
	}

	public static DenseDoubleInstance read(DataInput in, MetaData metaData,
			DenseDoubleInstance instance) throws IOException {
		if (instance == null) {
			instance = new DenseDoubleInstance(metaData);
		}
		instance.readFields(in);
		return instance;
	}

	public static DenseDoubleInstance parseText(MetaData metaData, int ID,
			String[] text, DenseDoubleInstance instance) {
		if (text != null) {
			if (instance == null) {
				instance = new DenseDoubleInstance(ID, metaData);
			}
			instance.m_ID = ID;
			IAttribute[] attributes = metaData.getAttributes();
			IAttribute attr;
			int i = 0;
			for (; i < attributes.length && i < text.length; i++) {
				attr = attributes[i];
				switch (attr.getType()) {
				case COUNT:
					try {
						instance.setValue(i, Integer.parseInt(text[i]));
					} catch (NumberFormatException e) {
						instance.setErrorValue(i);
					} catch (NullPointerException e) {
						instance.setErrorValue(i);
					}

					break;
				case NOMINAL:
				case ORDINAL:
					if (text[i] == null || text[i].isEmpty()) {
						instance.setErrorValue(i);
					} else {
						instance.setValue(i,
								((NominalAttribute) attr).encode(text[i], true));
					}

					break;
				case BOOLEAN:
					if (text[i] == null || text[i].isEmpty()) {
						instance.setValue(i, -1);
					} else {
						try {
							instance.setValue(i,
									Boolean.parseBoolean(text[i]) ? 1 : 0);
						} catch (NumberFormatException e) {
							instance.setErrorValue(i);
						} catch (NullPointerException e) {
							instance.setErrorValue(i);
						}
					}

					break;
				case NUMERIC:
				default:
					try {
						instance.setValue(i, Double.parseDouble(text[i]));
					} catch (NumberFormatException e) {
						instance.setErrorValue(i);
					} catch (NullPointerException e) {
						instance.setErrorValue(i);
					}
					break;
				}
			}
			for (; i < attributes.length; i++) {
				// missing values
				instance.setErrorValue(i);
			}
			return instance;
		}
		return null;
	}

	public static DenseDoubleInstance emptyInstance(MetaData metaData) {
		return new DenseDoubleInstance(metaData);
	}
}
