/**
 * 
 */
package common.data.instance.numeric;

import java.util.Iterator;

import common.utils.entry.ILongEntry;

/**
 * @author xjc
 * 
 */
public interface ILongInstance extends INumericInstance {

	/**
	 * Set the value of attribute
	 * 
	 * @param attribute
	 *            the index of attribute
	 * @param value
	 *            a given value
	 */
	public void setValue(int attribute, long value);

	/**
	 * Get the value of attribute
	 * 
	 * @param attribute
	 *            the index of attribute
	 * @return the value of attribute
	 */
	public long getValue(int attribute);

	/**
	 * Returns all used values, excluding label
	 * 
	 * @return the array of all values
	 */
	public long[] getUsedValues();

	/**
	 * Returns all values, including label
	 * 
	 * @return the array of all values
	 */
	public long[] getAllValues();

	/**
	 * Iterate all values
	 * */
	public Iterator<ILongEntry> iterateValues();

	/**
	 * Clone instance
	 * */
	public ILongInstance clone();

	/**
	 * @return a new value with all elements as zero
	 * 
	 * */
	public ILongInstance like();

}
