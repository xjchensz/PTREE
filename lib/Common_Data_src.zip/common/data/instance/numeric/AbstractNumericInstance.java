/**
 * Created by Xiaojun Chen at 2012-6-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.numeric;

import java.util.Iterator;

import common.data.distance.MinkowskiDistanceMeasure;
import common.data.instance.AbstractInstance;
import common.data.instance.IInstance;
import common.data.instance.ISparseInstance;
import common.data.instance.math.CardinalityException;
import common.data.instance.math.UnexpectedInstanceTypeException;
import common.data.instance.numeric.sparse.INonEmptyValueHandler;
import common.data.instance.numeric.sparse.INonEmptyValuePairHandler;
import common.data.instance.numeric.sparse.ISparseNumericInstance;
import common.data.meta.MetaData;
import common.utils.ChangeAbleDouble;
import common.utils.collection.ORDER;
import common.utils.collection.OrderedIntArraySet;
import common.utils.entry.INumericEntry;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public abstract class AbstractNumericInstance extends AbstractInstance
		implements INumericInstance {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8320480520461415678L;

	/**
	 * @param metaData
	 * @param id
	 */
	public AbstractNumericInstance(int id, MetaData metaData) {
		super(id, metaData);
	}

	/**
	 * @param metaData
	 */
	public AbstractNumericInstance(MetaData metaData) {
		super(metaData);
	}

	@Override
	public void assign(IInstance other) throws CardinalityException {
		if (!(other instanceof INumericInstance)) {
			throw new UnexpectedInstanceTypeException(INumericInstance.class,
					other.getClass());
		}
		if (other.getMetaData().numAllAttributes() != getMetaData()
				.numAllAttributes()) {
			throw new CardinalityException(other.getMetaData()
					.numAllAttributes(), getMetaData().numAllAttributes());
		}

		clear();
		Iterator<? extends INumericEntry> values = ((INumericInstance) other)
				.iterateValues();
		while (values.hasNext()) {
			assign(values.next());
		}
	}

	@Override
	public void plus(INumericInstance ins) throws CardinalityException {
		if (ins.getMetaData().numAllAttributes() != getMetaData()
				.numAllAttributes()) {
			throw new CardinalityException(
					ins.getMetaData().numAllAttributes(), getMetaData()
							.numAllAttributes());
		}

		Iterator<? extends INumericEntry> values = ins.iterateValues();
		while (values.hasNext()) {
			plus(values.next());
		}
	}

	@Override
	public void plus(int attr, INumericInstance ins)
			throws CardinalityException {
		if (ins.getMetaData().numAllAttributes() <= attr) {
			throw new CardinalityException(attr, getMetaData()
					.numAllAttributes());
		}
		setValue(attr, doubleValue(attr) + ins.doubleValue(attr));
	}

	@Override
	public void minus(INumericInstance ins) throws CardinalityException {
		if (ins.getMetaData().numAllAttributes() != getMetaData()
				.numAllAttributes()) {
			throw new CardinalityException(
					ins.getMetaData().numAllAttributes(), getMetaData()
							.numAllAttributes());
		}

		Iterator<? extends INumericEntry> values = ins.iterateValues();
		while (values.hasNext()) {
			minus(values.next());
		}
	}

	@Override
	public void times(double m) {
		Iterator<? extends INumericEntry> values = iterateValues();
		while (values.hasNext()) {
			values.next().times(m);
		}
	}

	@Override
	public void divide(double m) {
		Iterator<? extends INumericEntry> values = iterateValues();
		while (values.hasNext()) {
			values.next().divide(m);
		}
	}

	@Override
	public double length() {
		return Math.sqrt(lengthSquared());
	}

	@Override
	public double lengthSquared() {
		if (this instanceof ISparseNumericInstance) {
			final ChangeAbleDouble cd = new ChangeAbleDouble();
			processNonEmptyValues(new INonEmptyValueHandler() {

				@Override
				public void handle(int index, double value) {
					cd.add(Math.pow(value, 2));
				}

			});
			return cd.getValue();
		} else {
			int size = size();
			double result = 0;
			for (int i = 0; i < size; i++) {
				result += Math.pow(doubleValue(i), 2);
			}
			return result;
		}
	}

	@Override
	public void processNonEmptyValues(final INumericInstance ins,
			final INonEmptyValuePairHandler handler) {

		if (this instanceof ISparseNumericInstance) {
			if (ins instanceof ISparseNumericInstance) {
				final OrderedIntArraySet os = new OrderedIntArraySet(ORDER.ASC);
				processNonEmptyValues(new INonEmptyValueHandler() {

					@Override
					public void handle(int index, double value) {
						os.add(index);
						handler.handle(index, value, ins.doubleValue(index));
					}
				});
				ins.processNonEmptyValues(new INonEmptyValueHandler() {

					@Override
					public void handle(int index, double value) {
						if (!os.containsValue(index)) {
							handler.handle(index, doubleValue(index), value);
						}
					}
				});
				os.destroy();

			} else {
				ins.processNonEmptyValues(new INonEmptyValueHandler() {

					@Override
					public void handle(int index, double value) {
						handler.handle(index, doubleValue(index), value);
					}
				});
			}
		} else {
			processNonEmptyValues(new INonEmptyValueHandler() {

				@Override
				public void handle(int index, double value) {
					handler.handle(index, value, ins.doubleValue(index));
				}
			});
		}
	}

	@Override
	public void normalize() {
		divide(Math.sqrt(length()));
	}

	@Override
	public void normalize(double power) {
		divide(norm(power));
	}

	@Override
	public void logNormalize() {
		logNormalize(2.0, Math.sqrt(length()));
	}

	@Override
	public void logNormalize(double power) {
		logNormalize(power, norm(power));
	}

	protected abstract void logNormalize(double power, double normLength);

	@Override
	public double norm(double power) {
		if (power < 0.0) {
			throw new IllegalArgumentException("Power must be >= 0");
		}
		// we can special case certain powers
		if (Double.isInfinite(power)) {
			double val = 0.0;
			Iterator<? extends INumericEntry> iter = iterateValues();
			while (iter.hasNext()) {
				val = Math.max(val, Math.abs(iter.next().doubleValue()));
			}
			return val;
		} else if (power == 2.0) {
			return length();
		} else if (power == 1.0) {
			double val = 0.0;
			Iterator<? extends INumericEntry> iter = iterateValues();
			while (iter.hasNext()) {
				val += Math.abs(iter.next().doubleValue());
			}
			return val;
		} else if (power == 0.0) {
			// this is the number of non-zero elements
			double val = 0.0;
			Iterator<? extends INumericEntry> iter = iterateValues();
			while (iter.hasNext()) {
				val += iter.next().doubleValue() == 0 ? 0 : 1;
			}
			return val;
		} else {
			double val = 0.0;
			Iterator<? extends INumericEntry> iter = iterateValues();
			while (iter.hasNext()) {
				val += Math.pow(iter.next().doubleValue(), power);
			}
			return Math.pow(val, 1.0 / power);
		}
	}

	@Override
	public double dot(INumericInstance ins) throws CardinalityException {

		ISparseNumericInstance sin = null;
		INumericInstance ain = null;
		if (this instanceof ISparseNumericInstance) {
			sin = (ISparseNumericInstance) this;
			ain = ins;
		} else if (ins instanceof ISparseNumericInstance) {
			sin = (ISparseNumericInstance) ins;
			ain = this;
		}

		if (sin != null) {
			final INumericInstance in = ain;
			final ChangeAbleDouble cdb = new ChangeAbleDouble();
			sin.processNonEmptyValues(new INonEmptyValueHandler() {

				@Override
				public void handle(int index, double value) {
					cdb.add(in.doubleValue(index) * value);
				}
			});
			return cdb.getValue();
		} else {
			double result = 0;
			int size = size();
			for (int i = 0; i < size; i++) {
				result += doubleValue(i) * ins.doubleValue(i);
			}
			return result;
		}
	}

	@Override
	public double euclideanDistance(INumericInstance instance) {
		return minkowskiDistance(instance, 2);
	}

	@Override
	public double weightedEuclideanDistance(INumericInstance instance,
			INumericInstance weight) {
		return weightedminkowskiDistance(instance, weight, 2);
	}

	@Override
	public double weightedEuclideanDistance(INumericInstance instance,
			double[] weight) {
		return weightedminkowskiDistance(instance, weight, 2);
	}

	@Override
	public double minkowskiDistance(INumericInstance instance, double p) {
		return MinkowskiDistanceMeasure.distance(this, instance, p);
	}

	@Override
	public double weightedminkowskiDistance(INumericInstance instance,
			INumericInstance weights, double p) {
		if (instance.getMetaData().numUsedAttributes() != getMetaData()
				.numUsedAttributes()) {
			throw new CardinalityException(instance.getMetaData()
					.numUsedAttributes(), getMetaData().numUsedAttributes());
		}
		double result = 0;
		MetaData md = getMetaData();
		MetaData md2 = instance.getMetaData();
		if (instance instanceof ISparseInstance) {
			Iterator<? extends INumericEntry> itr = instance.iterateValues();
			INumericEntry entry;
			int attr;
			while (itr.hasNext()) {
				entry = itr.next();
				attr = entry.getAttribute();
				if (!md.getAttributeAt(attr).isIgnored()
						&& !md2.getAttributeAt(attr).isIgnored()) {
					result += Math.pow(
							(doubleValue(attr) - entry.doubleValue())
									* weights.doubleValue(attr), p);
				}
			}
		} else {
			Iterator<? extends INumericEntry> itr = iterateValues();
			INumericEntry entry;
			int attr;
			while (itr.hasNext()) {
				entry = itr.next();
				attr = entry.getAttribute();
				if (!md.getAttributeAt(attr).isIgnored()
						&& !md2.getAttributeAt(attr).isIgnored()) {
					result += Math.pow(
							(entry.doubleValue() - instance.doubleValue(attr))
									* weights.doubleValue(attr), p);
				}
			}

		}
		return Math.pow(result, 1.0 / p);
	}

	@Override
	public double weightedminkowskiDistance(INumericInstance instance,
			double[] weights, double p) {
		if (instance.getMetaData().numUsedAttributes() != getMetaData()
				.numUsedAttributes()) {
			throw new CardinalityException(instance.getMetaData()
					.numUsedAttributes(), getMetaData().numUsedAttributes());
		}
		double result = 0;
		MetaData md = getMetaData();
		MetaData md2 = instance.getMetaData();
		if (instance instanceof ISparseInstance) {
			Iterator<? extends INumericEntry> itr = instance.iterateValues();
			INumericEntry entry;
			int attr;
			while (itr.hasNext()) {
				entry = itr.next();
				attr = entry.getAttribute();
				if (!md.getAttributeAt(attr).isIgnored()
						&& !md2.getAttributeAt(attr).isIgnored()) {
					result += Math.pow(
							(doubleValue(attr) - entry.doubleValue())
									* weights[attr], p);
				}
			}
		} else {
			Iterator<? extends INumericEntry> itr = iterateValues();
			INumericEntry entry;
			int attr;
			while (itr.hasNext()) {
				entry = itr.next();
				attr = entry.getAttribute();
				if (!md.getAttributeAt(attr).isIgnored()
						&& !md2.getAttributeAt(attr).isIgnored()) {
					result += Math.pow(
							(entry.doubleValue() - instance.doubleValue(attr))
									* weights[attr], p);
				}
			}

		}
		return Math.pow(result, 1.0 / p);
	}
}
