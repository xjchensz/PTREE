/**
 * Created by Xiaojun Chen at 2012-6-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.numeric;

import java.util.Iterator;

import common.data.instance.IInstance;
import common.data.instance.math.CardinalityException;
import common.data.instance.numeric.sparse.INonEmptyValueHandler;
import common.data.instance.numeric.sparse.INonEmptyValuePairHandler;
import common.utils.entry.INumericEntry;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public interface INumericInstance extends IInstance {

	public static final String ERROR_VALUE = "Error";

	/**
	 * set the label
	 * */
	public void setLabel(double label);

	/**
	 * Get the class label of Instance.
	 * 
	 * @return the label of instance
	 * @return label
	 * */
	public double getLabel();

	/**
	 * Whether contains the attribute
	 * 
	 * @param attribute
	 *            the index of attribute
	 * @return true if it contains attribute
	 */
	public boolean containAttribute(int attribute);

	/**
	 * Iterate all non-empty values (excluding labels)
	 * */
	public Iterator<? extends INumericEntry> iterateValues();

	/**
	 * call the handler to process all non-empty values (excluding labels)
	 * */
	public void processNonEmptyValues(INonEmptyValueHandler handler);

	/**
	 * call the handler to process all non-empty values (excluding labels)
	 * */
	public void processNonEmptyValues(INumericInstance ins,
			INonEmptyValuePairHandler handler);

	/**
	 * @return the double value at the given attribute
	 * */
	public double doubleValue(int attr);

	/**
	 * @return the string value at the given attribute
	 * */
	public String stringValue(int attr);

	/**
	 * Set the value of attribute
	 * 
	 * @param attribute
	 *            the index of attribute
	 * @param value
	 *            a given value
	 */
	public void setValue(int attribute, double value);

	/**
	 * Set the error value for the given attribute
	 * */
	public void setErrorValue(int attribute);

	/**
	 * /** Check whether the given attribute is error value
	 * */
	public boolean isErrorValue(int attribute);

	// Algebraic operation

	/**
	 * compute this+ins
	 * */
	public void plus(INumericInstance ins) throws CardinalityException;

	/**
	 * compute this-ins
	 * */
	public void minus(INumericInstance ins) throws CardinalityException;

	/**
	 * compute the product of each value of the recipient and the argument,
	 * this.m
	 * */
	public void times(double m);

	/**
	 * compute this/m
	 * */
	public void divide(double m);

	/**
	 * Assign the entry values to the receiver
	 * 
	 * @param entry
	 *            an entry
	 * @throws CardinalityException
	 *             if the cardinalities differ
	 */
	public void assign(INumericEntry entry) throws CardinalityException;

	/**
	 * replace the value at the corresponding attribute as this+ins
	 * */
	public void plus(int attr, INumericInstance ins)
			throws CardinalityException;

	/**
	 * replace the value at the corresponding attribute as this+entry
	 * */
	public void plus(INumericEntry entry) throws CardinalityException;

	/**
	 * replace the value at the corresponding attribute as this-entry
	 * */
	public void minus(INumericEntry entry) throws CardinalityException;

	/**
	 * replace the value at the corresponding attribute as this*entry
	 * */
	public void times(INumericEntry entry);

	/**
	 * replace the value at the corresponding attribute as this/entry
	 * */
	public void divide(INumericEntry entry);

	/**
	 * @return the euclidean distance of this instance with given instance
	 * */
	public double euclideanDistance(INumericInstance instance);

	/**
	 * @return the weighted euclidean distance of this instance with given
	 *         instance
	 * */
	public double weightedEuclideanDistance(INumericInstance instance,
			INumericInstance weight);

	/**
	 * @return the weighted euclidean distance of this instance with given
	 *         instance
	 * */
	public double weightedEuclideanDistance(INumericInstance instance,
			double[] weight);

	/**
	 * @return the minkowski distance of this instance with given instance, this
	 *         - instance
	 * */
	public double minkowskiDistance(INumericInstance instance, double p);

	/**
	 * @return the weighted minkowski distance of this instance with given
	 *         instance
	 * */
	public double weightedminkowskiDistance(INumericInstance instance,
			INumericInstance weights, double p);

	/**
	 * @return the weighted minkowski distance of this instance with given
	 *         instance
	 * */
	public double weightedminkowskiDistance(INumericInstance instance,
			double[] weights, double p);

	/**
	 * @return the lenght of the instance
	 * */
	public double length();

	/**
	 * @return the squared length of the instance
	 * */
	public double lengthSquared();

	/**
	 * compute the dot product of this.ins
	 * */
	public double dot(INumericInstance ins) throws CardinalityException;

	/**
	 * Normalize (L_2 norm) values of the instance
	 * 
	 */
	public void normalize();

	/**
	 * Normalize (L_power norm) values of the recipient.
	 * <p/>
	 * See http://en.wikipedia.org/wiki/Lp_space
	 * <p/>
	 * Technically, when 0 < power < 1, we don't have a norm, just a metric, but
	 * we'll overload this here.
	 * <p/>
	 * Also supports power == 0 (number of non-zero elements) and power =
	 * {@link Double#POSITIVE_INFINITY} (max element). Again, see the Wikipedia
	 * page for more info
	 * 
	 * @param power
	 *            The power to use. Must be >= 0. May also be
	 *            {@link Double#POSITIVE_INFINITY}. See the Wikipedia link for
	 *            more on this.
	 */
	public void normalize(double power);

	/**
	 * log(1 + entry)/ L_2 norm values of the instance
	 * 
	 */
	public void logNormalize();

	/**
	 * normalized value calculated as log_power(1 + entry)/ L_power norm.
	 * <p/>
	 * 
	 * @param power
	 *            The power to use. Must be > 1. Cannot be
	 *            {@link Double#POSITIVE_INFINITY}.
	 */
	public void logNormalize(double power);

	/**
	 * Return the k-norm value of the instance.
	 * <p/>
	 * See http://en.wikipedia.org/wiki/Lp_space
	 * <p/>
	 * Technically, when 0 &gt; power &lt; 1, we don't have a norm, just a
	 * metric, but we'll overload this here. Also supports power == 0 (number of
	 * non-zero elements) and power = {@link Double#POSITIVE_INFINITY} (max
	 * element). Again, see the Wikipedia page for more info.
	 * 
	 * @param power
	 *            The power to use.
	 * @see #normalize(double)
	 */
	double norm(double power);

	// Algebraic operation

	/**
	 * Clone instance
	 * */
	public INumericInstance clone();

	/**
	 * @return a new value with all elements as zero
	 * 
	 * */
	public INumericInstance like();

}
