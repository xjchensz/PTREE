/**
 * 
 */
package common.data.instance.numeric.sparse;

/**
 * @author xiaojun chen
 *
 */
public interface INonEmptyValueHandler {

	public void handle(int index, double value);

}
