package common.data.instance.numeric.sparse;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Iterator;

import common.data.instance.math.CardinalityException;
import common.data.instance.numeric.AbstractNumericInstance;
import common.data.instance.numeric.IIntInstance;
import common.data.instance.utils.SparseIntEmptyMap;
import common.data.meta.BooleanAttribute;
import common.data.meta.CountAttribute;
import common.data.meta.IAttribute;
import common.data.meta.MetaData;
import common.data.meta.NominalAttribute;
import common.utils.StringUtils;
import common.utils.entry.IIntEntry;
import common.utils.entry.INumericEntry;
import common.utils.math.Varint;

/**
 * Represents one data instance which is sparse, the empty element is
 * represented as 0
 * 
 * @author Xiaojun Chen
 * 
 */
public class SparseIntInstance extends AbstractNumericInstance implements
		ISparseNumericInstance, IIntInstance {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1829676581885189887L;
	protected SparseIntEmptyMap m_Values;

	public SparseIntInstance(int id, SparseIntEmptyMap values) {
		super(id, values.getMetaData());
		if (values.getEmptyValue() != 0) {
			throw new IllegalArgumentException("Empty value should be zero!");
		}
		this.m_Values = values;
	}

	public SparseIntInstance(int id, MetaData md) {
		super(id, md);
		createMap();
	}

	protected void createMap() {
		this.m_Values = SparseIntEmptyMap.create(getMetaData());
	}

	protected SparseIntInstance(MetaData metadata) {
		super(metadata);
	}

	/**
	 * Get the iterator of non-zero elements
	 * 
	 * @return the iterator of attributes
	 */
	public Iterator<IIntEntry> iterateValues() {
		return m_Values.enties(getMetaData().getLabelId());
	}

	@Override
	public void setLabel(double label) {
		int labelId = m_MetaData.getLabelId();
		if (labelId < 0 || labelId > m_MetaData.numAllAttributes()) {
			throw new IllegalArgumentException("No label attribute!");
		}
		m_Values.put(labelId, (int) label);
	}

	@Override
	public double getLabel() {
		int lableId = m_MetaData.getLabelId();
		if (lableId < 0) {
			return -1;
		}

		double value = m_Values.get(lableId);
		if (!Double.isNaN(value)) {
			return (int) value;
		} else {
			return -1;
		}
	}

	@Override
	public void setValue(int attribute, int value) {
		if (attribute >= m_MetaData.numAllAttributes()) {
			throw new ArrayIndexOutOfBoundsException();
		}
		m_Values.put(attribute, value);
	}

	@Override
	public void setValue(int attribute, double value) {
		if (attribute >= m_MetaData.numAllAttributes()) {
			throw new ArrayIndexOutOfBoundsException();
		}
		m_Values.put(attribute, (int) value);
	}

	@Override
	public double doubleValue(int attribute) {
		int index = m_Values.findIndexForKey(0, attribute);
		if (index < m_Values.size() && index >= 0
				&& attribute == m_Values.getKeyAt(index)) {
			return m_Values.getValueAt(index);
		} else {
			return 0;
		}
	}

	@Override
	public void setErrorValue(int attribute) {
		IAttribute attr = m_MetaData.getAttributeAt(attribute);
		switch (attr.getType()) {
		case NOMINAL:
		case ORDINAL:
			m_Values.put(attribute, NominalAttribute.ERROR_INT_VALUE);
			break;
		case COUNT:
			m_Values.put(attribute, CountAttribute.ERROR_INT_VALUE);
		case BOOLEAN:
			m_Values.put(attribute, BooleanAttribute.ERROR_INT_VALUE);
			break;
		case NUMERIC:
		default:
			throw new UnsupportedOperationException();
		}
	}

	@Override
	public boolean isErrorValue(int attribute) {
		IAttribute attr = m_MetaData.getAttributeAt(attribute);
		switch (attr.getType()) {
		case NOMINAL:
		case ORDINAL:
			return m_Values.get(attribute) == NominalAttribute.ERROR_INT_VALUE;
		case COUNT:
			return m_Values.get(attribute) == CountAttribute.ERROR_INT_VALUE;
		case BOOLEAN:
			return m_Values.get(attribute) == BooleanAttribute.ERROR_INT_VALUE;
		case NUMERIC:
		default:
			return false;
		}
	}

	@Override
	public String stringValue(int attr) {
		IAttribute attribute = m_MetaData.getAttributeAt(attr);
		int index = m_Values.findIndexForKey(0, attr);
		switch (attribute.getType()) {
		case NOMINAL:
		case ORDINAL:
			if (index >= 0 && index < m_Values.size()
					&& attr == m_Values.getKeyAt(index)) {
				return ((NominalAttribute) attribute)
						.decode(m_Values.get(attr));
			} else {
				return String.valueOf(m_Values.getEmptyValue());
			}
		case BOOLEAN:
			if (!containAttribute(attr)) {
				return "false";
			} else {
				return m_Values.get(attr) == 1 ? "true" : "false";
			}
		case COUNT:
		case NUMERIC:
		default:
			if (index >= 0 && index < m_Values.size()
					&& attr == m_Values.getKeyAt(index)) {
				return String.valueOf(m_Values.getValueAt(index));
			} else {
				return String.valueOf(m_Values.getEmptyValue());
			}
		}
	}

	@Override
	public int size() {
		return m_Values.size();
	}

	@Override
	public int getValue(int attribute) {
		return m_Values.get(attribute);
	}

	@Override
	public int[] getUsedValues() {
		int[] usedValues = new int[m_MetaData.numUsedAttributes()];

		int ptr = 0;
		int labelID = m_MetaData.getLabelId();
		for (int i = 0; i < labelID; i++) {
			if (m_MetaData.isIgnored(i)) {
				usedValues[ptr++] = m_Values.get(i);
			}
		}
		int numAttributes = m_MetaData.numAllAttributes();
		for (int i = labelID >= 0 ? labelID + 1 : 0; i < numAttributes; i++) {
			if (m_MetaData.isIgnored(i)) {
				usedValues[ptr++] = m_Values.get(i);
			}
		}

		return usedValues;
	}

	@Override
	public int[] getAllValues() {
		int[] allValues = new int[m_MetaData.numAllAttributes()];

		int ptr = 0;
		for (int i = 0; i < allValues.length; i++) {
			allValues[ptr++] = m_Values.get(i);
		}

		return allValues;
	}

	@Override
	public boolean containAttribute(int attribute) {
		return m_Values.containsKey(attribute);
	}

	@Override
	public void assign(INumericEntry entry) throws CardinalityException {
		if (entry instanceof IIntEntry) {
			m_Values.put(entry.getAttribute(), ((IIntEntry) entry).getValue());
		} else {
			m_Values.put(entry.getAttribute(), (int) entry.doubleValue());
		}
	}

	@Override
	public void plus(INumericEntry entry) throws CardinalityException {
		if (entry instanceof IIntEntry) {
			m_Values.put(
					entry.getAttribute(),
					m_Values.get(entry.getAttribute())
							+ ((IIntEntry) entry).getValue());
		} else {
			m_Values.put(entry.getAttribute(), (int) (m_Values.get(entry
					.getAttribute()) + entry.doubleValue()));
		}
	}

	@Override
	public void minus(INumericEntry entry) throws CardinalityException {
		if (entry instanceof IIntEntry) {
			m_Values.put(
					entry.getAttribute(),
					m_Values.get(entry.getAttribute())
							- ((IIntEntry) entry).getValue());
		} else {
			m_Values.put(entry.getAttribute(), (int) (m_Values.get(entry
					.getAttribute()) - entry.doubleValue()));
		}
	}

	@Override
	public void times(INumericEntry entry) {
		if (entry instanceof IIntEntry) {
			m_Values.put(
					entry.getAttribute(),
					m_Values.get(entry.getAttribute())
							* ((IIntEntry) entry).getValue());
		} else {
			m_Values.put(entry.getAttribute(), (int) (m_Values.get(entry
					.getAttribute()) * entry.doubleValue()));
		}
	}

	@Override
	public void divide(INumericEntry entry) {
		if (entry instanceof IIntEntry) {
			m_Values.put(
					entry.getAttribute(),
					m_Values.get(entry.getAttribute())
							/ ((IIntEntry) entry).getValue());
		} else {
			m_Values.put(entry.getAttribute(), (int) (m_Values.get(entry
					.getAttribute()) / entry.doubleValue()));
		}
	}

	@Override
	public void processNonEmptyValues(INonEmptyValueHandler handler) {
		int size = size();
		for (int i = 0; i < size; i++) {
			handler.handle(m_Values.getKeyAt(i), m_Values.getValueAt(i));
		}
	}

	@Override
	protected void logNormalize(double power, double normLength) {

		// we can special case certain powers
		if (Double.isInfinite(power) || power <= 1.0) {
			throw new IllegalArgumentException(
					"Power must be > 1 and < infinity");
		} else {
			double denominator = normLength * Math.log(power);
			Iterator<IIntEntry> itr = iterateValues();
			IIntEntry entry;
			while (itr.hasNext()) {
				entry = itr.next();
				entry.setValue((int) (Math.log(1 + entry.doubleValue()) / denominator));
			}
		}
	}

	@Override
	public SparseIntInstance like() {
		return new SparseIntInstance(m_ID,
				m_Values != null ? m_Values.newInstance() : null);
	}

	public SparseIntInstance clone() {
		return new SparseIntInstance(m_ID, m_Values != null ? m_Values.clone()
				: null);
	}

	@Override
	public void clear() {
		m_Values.clear();
	}

	@Override
	public void destroy() {
		m_MetaData = null;
		if (m_Values != null) {
			m_Values.clear();
			m_Values = null;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof SparseIntInstance)) {
			return false;
		}

		return m_Values.equals(((SparseIntInstance) obj).m_Values);
	}

	@Override
	public boolean equalsInAttribute(Object obj, int attributeIndex) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof SparseIntInstance)) {
			return false;
		}

		return m_Values.getValueAt(attributeIndex) == ((SparseIntInstance) obj).m_Values
				.getValueAt(attributeIndex);
	}

	@Override
	public String toSQLString() {
		StringBuilder sb = new StringBuilder();
		sb.append(m_ID).append(MetaData.SEPARATOR_DATA);

		int numAttributes = m_MetaData.numAllAttributes();
		for (int i = 0; i < numAttributes; i++) {
			if (!m_MetaData.isIgnored(i)) {
				sb.append(getValue(i)).append(MetaData.SEPARATOR_DATA);
			}
		}
		if (sb.length() > 0) {
			sb.setLength(sb.length() - 1);
		}
		return sb.toString();
	}

	@Override
	public String toFileRecordString() {
		StringBuilder sb = new StringBuilder();
		sb.append(m_ID).append(MetaData.SEPARATOR_ID);

		int[] indices = m_Values.keys();
		for (int i = 0; i < indices.length; i++) {
			if (!m_MetaData.isIgnored(indices[i])) {
				sb.append(indices[i]).append(MetaData.SEPARATOR_DATA_INNER)
						.append(stringValue(indices[i]))
						.append(MetaData.SEPARATOR_DATA);
			}
		}
		if (sb.length() > 0) {
			sb.setLength(sb.length() - 1);
		}
		return sb.toString();
	}

	@Override
	public void readFields(DataInput input) throws IOException {
		m_ID = Varint.readUnsignedVarInt(input);
		m_Values = SparseIntEmptyMap.read(m_MetaData, input);
	}

	@Override
	public void write(DataOutput out) throws IOException {
		Varint.writeUnsignedVarInt(getID(), out);
		m_Values.write(out);
	}

	public int getStoreBytes() {
		return Integer.SIZE / 8 + m_Values.getStoreBytes();
	}

	public static SparseIntInstance read(DataInput input, MetaData metaData,
			SparseIntInstance instance) throws IOException {
		if (instance == null) {
			instance = new SparseIntInstance(metaData);
		}
		instance.readFields(input);
		return instance;
	}

	public static SparseIntInstance parseText(MetaData metaData, int ID,
			String[] text, SparseIntInstance instance) {

		if (text != null) {
			if (instance == null) {
				instance = new SparseIntInstance(ID, metaData);
			}
			instance.m_ID = ID;
			String[] array = new String[2];
			int len;
			for (String t : text) {
				len = StringUtils.splitTwoPart(t,
						MetaData.SEPARATOR_DATA_INNER, array);

				if (len == 1) {
					try {
						int index = Integer.parseInt(array[0]);
						if (index >= 0) {
							instance.setErrorValue(index);
						}
					} catch (NumberFormatException e) {

					}
				} else if (len == 2) {
					int index = -1;
					try {
						index = Integer.parseInt(array[0]);
					} catch (NumberFormatException e) {

					}

					if (index >= 0) {
						IAttribute attr = metaData.getAttributeAt(index);
						switch (attr.getType()) {
						case COUNT:
							try {
								instance.setValue(index,
										Integer.parseInt(array[1]));
							} catch (NumberFormatException e) {
								instance.setErrorValue(index);
							}
							break;
						case NOMINAL:
						case ORDINAL:
							if (array[1] == null || array[1].isEmpty()) {
								instance.setErrorValue(index);
							} else {
								instance.setValue(index,
										((NominalAttribute) attr).encode(
												array[1], true));
							}
							break;
						case BOOLEAN:
							if (array[1] == null || array[1].isEmpty()) {
								instance.setErrorValue(index);
							} else {
								try {
									instance.setValue(index, Boolean
											.parseBoolean(array[1]) ? 1 : 0);
								} catch (NumberFormatException e) {
									instance.setErrorValue(index);
								}
							}
							break;
						case NUMERIC:
						default:
							try {
								instance.setValue(index,
										Integer.parseInt(array[1]));
							} catch (NumberFormatException e) {
								instance.setErrorValue(index);
							}
							break;
						}
					}
				}

			}
			return instance;
		}
		return null;
	}

	public static SparseIntInstance emptyInstance(MetaData metaData) {
		SparseIntInstance instance = new SparseIntInstance(metaData);
		return instance;
	}

}
