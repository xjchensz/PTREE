/**
 * Created by Xiaojun Chen at 2012-6-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.numeric.sparse;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Iterator;

import common.data.instance.IInstance;
import common.data.instance.math.CardinalityException;
import common.data.instance.math.EmptyValueException;
import common.data.instance.math.UnexpectedInstanceTypeException;
import common.data.instance.numeric.AbstractNumericInstance;
import common.data.instance.utils.SparseIntArraySet;
import common.data.meta.MetaData;
import common.utils.entry.IBooleanEntry;
import common.utils.entry.INumericEntry;
import common.utils.math.Varint;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class SparseBooleanInstance extends AbstractNumericInstance implements
		IBooleanSparseInstance {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4702010986109984884L;
	// store true values
	protected SparseIntArraySet m_TrueValues;
	private long m_NoOfOccurrence = 1;
	private double m_Label = -1;

	public SparseBooleanInstance(int id, SparseIntArraySet trueValues,
			double label) {
		super(id, trueValues.getMetaData());
		this.m_TrueValues = trueValues;
		m_Label = label;
	}

	public SparseBooleanInstance(int id, SparseIntArraySet trueValues) {
		super(id, trueValues.getMetaData());
		this.m_TrueValues = trueValues;
	}

	public SparseBooleanInstance(int id, MetaData md) {
		super(id, md);
		createSet();
	}

	protected void createSet() {
		this.m_TrueValues = SparseIntArraySet.create(getMetaData());
	}

	protected SparseBooleanInstance(MetaData metadata) {
		super(metadata);
	}

	@Override
	public int size() {
		return m_TrueValues.size();
	}

	@Override
	public void assign(IInstance other) throws EmptyValueException,
			UnexpectedInstanceTypeException, CardinalityException {
		if (!(other instanceof SparseBooleanInstance)) {
			throw new UnexpectedInstanceTypeException(
					SparseBooleanInstance.class, other.getClass());
		}

		SparseBooleanInstance bsi = (SparseBooleanInstance) other;

		if (bsi.size() == 0) {
			throw new EmptyValueException();
		}

		m_TrueValues.destroy();
		m_TrueValues = bsi.m_TrueValues.clone();
	}

	@Override
	public void setValue(int attr, boolean value) {
		if (value) {
			m_TrueValues.add(attr);
		} else {
			m_TrueValues.removeValue(attr);
		}
	}

	@Override
	public void setErrorValue(int attribute) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isErrorValue(int attribute) {
		return false;
	}

	@Override
	public boolean trueValue(int attr) {
		return m_TrueValues.containsValue(attr);
	}

	@Override
	public String stringValue(int attr) {
		if (m_MetaData.getLabelId() == attr) {
			// label
			return String.valueOf(m_Label);
		} else {
			return m_TrueValues.containsValue(attr) ? "true" : "false";
		}
	}

	@Override
	public int[] getAllTrueAttributes() {
		return m_TrueValues.getAllTrueValues(false);
	}

	@Override
	public int[] getAllFalseAttributes() {
		return m_TrueValues.getAllFalseValues(false);
	}

	@Override
	public boolean[] booleanValues() {
		return m_TrueValues.booleanValues(false);
	}

	@Override
	public void clear() {
		m_NoOfOccurrence = 1;
		m_Label = -1;
		m_TrueValues.clear();
	}

	@Override
	public void destroy() {
		m_TrueValues.destroy();
		m_TrueValues = null;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof SparseBooleanInstance)) {
			return false;
		}

		return m_TrueValues.equals(((SparseBooleanInstance) obj).m_TrueValues);
	}

	@Override
	public boolean equalsInAttribute(Object obj, int attributeIndex) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof SparseBooleanInstance)) {
			return false;
		}

		return m_TrueValues.getValueAt(attributeIndex) == ((SparseBooleanInstance) obj).m_TrueValues
				.getValueAt(attributeIndex);
	}

	@Override
	public String toSQLString() {

		StringBuilder sb = new StringBuilder();
		sb.append(m_ID).append(MetaData.SEPARATOR_DATA);

		int numAttributes = m_MetaData.numAllAttributes();
		for (int i = 0; i < numAttributes; i++) {
			if (!m_MetaData.isIgnored(i)) {
				sb.append(stringValue(i)).append(MetaData.SEPARATOR_DATA);
			}
		}
		if (sb.length() > 0) {
			sb.setLength(sb.length() - 1);
		}
		return sb.toString();
	}

	@Override
	public String toFileRecordString() {
		StringBuilder sb = new StringBuilder();
		sb.append(m_ID).append(MetaData.SEPARATOR_ID);

		int[] values = m_TrueValues.getAllTrueValues(true);

		for (int i = 0; i < values.length; i++) {
			if (!m_MetaData.isIgnored(i)) {
				sb.append(values[i]).append(MetaData.SEPARATOR_DATA);
			}
		}
		if (sb.length() > 0) {
			sb.setLength(sb.length() - 1);
		}
		return sb.toString();

	}

	@Override
	public void readFields(DataInput input) throws IOException {
		// skip byteSize outside
		m_ID = Varint.readUnsignedVarInt(input);
		m_TrueValues = SparseIntArraySet.read(m_MetaData, input);
		m_NoOfOccurrence = Varint.readUnsignedVarLong(input);
		m_Label = input.readDouble();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		Varint.writeUnsignedVarInt(getID(), out);
		m_TrueValues.write(out);
		Varint.writeUnsignedVarLong(m_NoOfOccurrence, out);
		out.writeDouble(m_Label);
	}

	public int getStoreBytes() {
		return (Varint.numBytesToWriteSignedVarInt(getID())
				+ Varint.numBytesToWriteUnsignedVarLong(m_NoOfOccurrence) + Double.SIZE)
				/ 8 + m_TrueValues.getStoreBytes();
	}

	@Override
	public void setLabel(double label) {
		m_Label = label;
	}

	@Override
	public double getLabel() {
		int lableId = m_MetaData.getLabelId();
		if (lableId < 0) {
			return -1;
		}
		return m_Label;
	}

	@Override
	public boolean containAttribute(int attribute) {
		return m_TrueValues.containsValue(attribute);
	}

	@Override
	public Iterator<? extends INumericEntry> iterateValues() {

		return new Iterator<IBooleanEntry>() {
			int ptr = 0;
			int size = size();

			@Override
			public boolean hasNext() {
				return ptr < size;
			}

			@Override
			public IBooleanEntry next() {
				final int index = ptr++;
				return new IBooleanEntry() {

					@Override
					public boolean setValue(boolean newValue) {
						if (!newValue) {
							m_TrueValues.removeValueAt(index);
							size--;
							return true;
						}
						return false;
					}

					@Override
					public int getAttribute() {
						return m_TrueValues.getValueAt(index);
					}

					@Override
					public boolean getValue() {
						return true;
					}

					@Override
					public double doubleValue() {
						return 1;
					}

					@Override
					public void times(double m) {
						// do nothing
					}

					@Override
					public void divide(double m) {
						// do nothing
					}
				};
			}

			@Override
			public void remove() {

			}
		};

	}

	@Override
	public void processNonEmptyValues(INonEmptyValueHandler handler) {
		int size = size();
		for (int i = 0; i < size; i++) {
			handler.handle(m_TrueValues.getValueAt(i), 1);
		}
	}

	@Override
	public double doubleValue(int attr) {
		if (m_TrueValues.containsValue(attr)) {
			return 1;
		} else {
			return 0;
		}

	}

	@Override
	public void setValue(int attribute, double value) {
		if (value <= 0) {
			// remove
			m_TrueValues.removeValue(attribute);
		} else {
			// add
			m_TrueValues.add(attribute);
		}
	}

	@Override
	public void assign(INumericEntry entry) throws CardinalityException {
		int attr = entry.getAttribute();
		if (entry instanceof IBooleanEntry) {
			if (((IBooleanEntry) entry).getValue()) {
				m_TrueValues.add(attr);
			} else {
				m_TrueValues.removeValue(attr);
			}
		} else {
			setValue(entry.getAttribute(), entry.doubleValue());
		}
	}

	@Override
	public void plus(INumericEntry entry) throws CardinalityException {
		int attr = entry.getAttribute();
		if (!m_TrueValues.containsValue(attr)) {
			if (entry instanceof IBooleanEntry
					&& ((IBooleanEntry) entry).getValue()) {
				m_TrueValues.add(attr);
			} else {
				setValue(attr, entry.doubleValue());
			}
		}
	}

	@Override
	public void minus(INumericEntry entry) throws CardinalityException {
		int attr = entry.getAttribute();
		if (m_TrueValues.containsValue(attr)) {
			if (entry instanceof IBooleanEntry
					&& ((IBooleanEntry) entry).getValue()) {
				m_TrueValues.removeValue(attr);
			} else {
				if (entry.doubleValue() > 0) {
					m_TrueValues.removeValue(attr);
				}
			}
		}
	}

	@Override
	public void times(INumericEntry entry) {
		int attr = entry.getAttribute();
		if (m_TrueValues.containsValue(attr)) {
			if (entry instanceof IBooleanEntry
					&& !((IBooleanEntry) entry).getValue()) {
				m_TrueValues.removeValue(attr);
			} else {
				if (entry.doubleValue() <= 0) {
					m_TrueValues.removeValue(attr);
				}
			}
		}
	}

	@Override
	public void divide(INumericEntry entry) {
		// non-change
	}

	@Override
	protected void logNormalize(double power, double normLength) {
		// non-change
	}

	@Override
	public void setOccurrence(long noOfOccurrence)
			throws IllegalArgumentException {
		if (noOfOccurrence <= 0) {
			throw new IllegalArgumentException(
					"The argument should be more than 0!");
		}
		m_NoOfOccurrence = noOfOccurrence;
	}

	@Override
	public long numOfOccurrence() {
		return m_NoOfOccurrence;
	}

	@Override
	public SparseBooleanInstance like() {
		return new SparseBooleanInstance(m_ID,
				m_TrueValues != null ? m_TrueValues.newInstance() : null,
				getLabel());
	}

	public SparseBooleanInstance clone() {
		return new SparseBooleanInstance(m_ID,
				m_TrueValues != null ? m_TrueValues.clone() : null, getLabel());
	}

	public static SparseBooleanInstance read(DataInput in, MetaData metaData,
			SparseBooleanInstance instance) throws IOException {
		if (instance == null) {
			instance = new SparseBooleanInstance(metaData);
		}
		instance.readFields(in);
		return instance;
	}

	public static SparseBooleanInstance parseText(MetaData metaData, int ID,
			String[] text, SparseBooleanInstance instance) {

		if (text != null) {
			if (instance == null) {
				instance = new SparseBooleanInstance(ID, metaData);
			}
			instance.m_ID = ID;
			for (String t : text) {
				try {
					instance.setValue(Integer.parseInt(t), true);
				} catch (NumberFormatException e) {

				}
			}
			return instance;
		}
		return null;
	}

	public static SparseBooleanInstance emptyInstance(MetaData metaData) {
		return new SparseBooleanInstance(metaData);
	}

}
