package common.data.instance.numeric.sparse;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Iterator;

import common.data.instance.math.CardinalityException;
import common.data.instance.numeric.AbstractNumericInstance;
import common.data.instance.numeric.IDoubleInstance;
import common.data.instance.numeric.INumericInstance;
import common.data.instance.utils.SparseDoubleMap;
import common.data.meta.BooleanAttribute;
import common.data.meta.CountAttribute;
import common.data.meta.IAttribute;
import common.data.meta.MetaData;
import common.data.meta.NominalAttribute;
import common.data.meta.NumericAttribute;
import common.utils.StringUtils;
import common.utils.collection.DoubleOperation;
import common.utils.entry.IDoubleEntry;
import common.utils.entry.INumericEntry;
import common.utils.math.Varint;

/**
 * Represents one data instance which is sparse, the empty element is
 * represented as 0
 * 
 * @author Xiaojun Chen
 * 
 */
public class SparseDoubleInstance extends AbstractNumericInstance implements
		ISparseNumericInstance, IDoubleInstance {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5073132166620547089L;
	protected SparseDoubleMap m_Values;

	public SparseDoubleInstance(int id, SparseDoubleMap values) {
		super(id, values.getMetaData());
		if (values.getEmptyValue() != 0) {
			throw new IllegalArgumentException("Empty value should be zero!");
		}
		this.m_Values = values;
	}

	public SparseDoubleInstance(int id, MetaData md) {
		super(id, md);
		createMap();
	}

	protected void createMap() {
		this.m_Values = SparseDoubleMap.create(getMetaData());
	}

	protected SparseDoubleInstance(MetaData metadata) {
		super(metadata);
	}

	/**
	 * Get the iterator of non-zero elements
	 * 
	 * @return the iterator of attributes
	 */
	public Iterator<IDoubleEntry> iterateValues() {
		return m_Values.enties(getMetaData().getLabelId());
	}

	@Override
	public void processNonEmptyValues(INonEmptyValueHandler handler) {
		int size = size();
		for (int i = 0; i < size; i++) {
			handler.handle(m_Values.getKeyAt(i), m_Values.getValueAt(i));
		}
	}

	@Override
	public void setLabel(double label) {
		int labelId = m_MetaData.getLabelId();
		if (labelId < 0 || labelId > m_MetaData.numAllAttributes()) {
			throw new IllegalArgumentException("No label attribute!");
		}
		m_Values.put(labelId, label);
	}

	@Override
	public double getLabel() {
		int lableId = m_MetaData.getLabelId();
		if (lableId < 0) {
			return -1;
		}
		double value = m_Values.get(lableId);
		if (!Double.isNaN(value)) {
			return (int) value;
		} else {
			return -1;
		}
	}

	@Override
	public void setValue(int attribute, double value) {
		if (attribute >= m_MetaData.numAllAttributes()) {
			throw new ArrayIndexOutOfBoundsException();
		}
		m_Values.put(attribute, value);
	}

	@Override
	public void setErrorValue(int attribute) {
		IAttribute attr = m_MetaData.getAttributeAt(attribute);
		switch (attr.getType()) {
		case NOMINAL:
		case ORDINAL:
			m_Values.put(attribute, NominalAttribute.ERROR_DOUBLE_VALUE);
			break;
		case COUNT:
			m_Values.put(attribute, CountAttribute.ERROR_DOUBLE_VALUE);
		case BOOLEAN:
			m_Values.put(attribute, BooleanAttribute.ERROR_DOUBLE_VALUE);
			break;
		case NUMERIC:
		default:
			m_Values.put(attribute, NumericAttribute.ERROR_DOUBLE_VALUE);
		}
	}

	@Override
	public boolean isErrorValue(int attribute) {
		IAttribute attr = m_MetaData.getAttributeAt(attribute);
		switch (attr.getType()) {
		case NOMINAL:
		case ORDINAL:
			return m_Values.get(attribute) == NominalAttribute.ERROR_DOUBLE_VALUE;
		case COUNT:
			return m_Values.get(attribute) == CountAttribute.ERROR_DOUBLE_VALUE;
		case BOOLEAN:
			return m_Values.get(attribute) == BooleanAttribute.ERROR_DOUBLE_VALUE;
		case NUMERIC:
		default:
			return Double.isNaN(m_Values.get(attribute));
		}
	}

	@Override
	public double doubleValue(int attribute) {
		if (!containAttribute(attribute))
			return m_Values.getEmptyValue();
		return m_Values.get(attribute);
	}

	@Override
	public String stringValue(int attr) {
		IAttribute attribute = m_MetaData.getAttributeAt(attr);
		int index = m_Values.findIndexForKey(0, attr);
		switch (attribute.getType()) {
		case NOMINAL:
		case ORDINAL:
			if (index >= 0 && index < m_Values.size()
					&& attr == m_Values.getKeyAt(index)) {
				return ((NominalAttribute) attribute).decode((int) m_Values
						.get(attr));
			} else {
				return String.valueOf(m_Values.getEmptyValue());
			}
		case BOOLEAN:
			if (!containAttribute(attr)) {
				return "false";
			} else {
				return m_Values.get(attr) == 1 ? "true" : "false";
			}
		case COUNT:
		case NUMERIC:
		default:
			if (index >= 0 && index < m_Values.size()
					&& attr == m_Values.getKeyAt(index)) {
				return String.valueOf(m_Values.getValueAt(index));
			} else {
				return String.valueOf(m_Values.getEmptyValue());
			}
		}
	}

	@Override
	public int size() {
		return m_Values.size();
	}

	@Override
	public double[] getUsedValues() {
		double[] usedValues = new double[m_MetaData.numUsedAttributes()];
		IAttribute[] attributes = m_MetaData.getAttributes();

		int ptr = 0;
		int labelID = m_MetaData.getLabelId();
		for (int i = 0; i < labelID; i++) {
			if (!attributes[i].isIgnored()) {
				usedValues[ptr++] = m_Values.get(i);
			}
		}
		for (int i = labelID >= 0 ? labelID + 1 : 0; i < attributes.length; i++) {
			if (!attributes[i].isIgnored()) {
				usedValues[ptr++] = m_Values.get(i);
			}
		}

		return usedValues;
	}

	@Override
	public double[] getAllValues() {
		double[] allValues = new double[m_MetaData.numAllAttributes()];

		int ptr = 0;
		for (int i = 0; i < allValues.length; i++) {
			allValues[ptr++] = m_Values.get(i);
		}

		return allValues;
	}

	@Override
	public boolean containAttribute(int attribute) {
		return m_Values.containsKey(attribute);
	}

	@Override
	public void assign(INumericEntry entry) throws CardinalityException {
		m_Values.put(entry.getAttribute(), entry.doubleValue());
	}

	@Override
	public void plus(INumericEntry entry) throws CardinalityException {
		m_Values.put(entry.getAttribute(), m_Values.get(entry.getAttribute())
				+ entry.doubleValue());
	}

	@Override
	public void minus(INumericEntry entry) throws CardinalityException {
		m_Values.put(entry.getAttribute(), m_Values.get(entry.getAttribute())
				- entry.doubleValue());
	}

	@Override
	public void times(INumericEntry entry) {
		m_Values.put(entry.getAttribute(), m_Values.get(entry.getAttribute())
				* entry.doubleValue());
	}

	@Override
	public void divide(INumericEntry entry) {
		m_Values.put(entry.getAttribute(), m_Values.get(entry.getAttribute())
				/ entry.doubleValue());
	}

	public double minkowskiDistance(INumericInstance instance, double p) {
		if (!(instance instanceof SparseDoubleInstance)) {
			return super.minkowskiDistance(instance, p);
		}
		MetaData md1 = getMetaData();
		MetaData md2 = instance.getMetaData();
		if (md1.numUsedAttributes() != md2.numUsedAttributes()) {
			throw new CardinalityException(md1.numUsedAttributes(),
					md2.numUsedAttributes());
		}

		SparseDoubleInstance si = (SparseDoubleInstance) instance;
		DOP dop = new DOP(p);
		m_Values.scan(si.m_Values, dop);

		return Math.pow(dop.result, 1.0 / p);
	}

	static class DOP implements DoubleOperation {

		double p;
		double result = 0;

		DOP(double p) {
			this.p = p;
		}

		@Override
		public void matchOperate(int key, double v1, double v2) {
			result += Math.pow(v1 - v2, p);
		}

		@Override
		public void unMatchOperate(int key, double v, double emptyValue) {
			result += Math.pow(v - emptyValue, p);
		}
	}

	@Override
	protected void logNormalize(double power, double normLength) {

		// we can special case certain powers
		if (Double.isInfinite(power) || power <= 1.0) {
			throw new IllegalArgumentException(
					"Power must be > 1 and < infinity");
		} else {
			double denominator = normLength * Math.log(power);

			Iterator<IDoubleEntry> itr = iterateValues();
			IDoubleEntry entry;
			while (itr.hasNext()) {
				entry = itr.next();
				entry.setValue(Math.log(1 + entry.doubleValue()) / denominator);
			}
		}
	}

	@Override
	public SparseDoubleInstance like() {
		return new SparseDoubleInstance(m_ID,
				m_Values != null ? m_Values.newInstance() : null);
	}

	public SparseDoubleInstance clone() {
		return new SparseDoubleInstance(m_ID,
				m_Values != null ? m_Values.clone() : null);
	}

	@Override
	public void clear() {
		m_Values.clear();
	}

	@Override
	public void destroy() {
		m_MetaData = null;
		if (m_Values != null) {
			m_Values.clear();
			m_Values = null;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof SparseDoubleInstance)) {
			return false;
		}

		return m_Values.equals(((SparseDoubleInstance) obj).m_Values);
	}

	@Override
	public boolean equalsInAttribute(Object obj, int attributeIndex) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof SparseDoubleInstance)) {
			return false;
		}

		return m_Values.getValueAt(attributeIndex) == ((SparseDoubleInstance) obj).m_Values
				.getValueAt(attributeIndex);
	}

	@Override
	public String toSQLString() {
		StringBuilder sb = new StringBuilder();
		sb.append(m_ID).append(MetaData.SEPARATOR_DATA);

		int numAttributes = m_MetaData.numAllAttributes();
		for (int i = 0; i < numAttributes; i++) {
			if (!m_MetaData.isIgnored(i)) {
				sb.append(doubleValue(i)).append(MetaData.SEPARATOR_DATA);
			}
		}
		if (sb.length() > 0) {
			sb.setLength(sb.length() - 1);
		}
		return sb.toString();
	}

	@Override
	public String toFileRecordString() {
		StringBuilder sb = new StringBuilder();
		sb.append(m_ID).append(MetaData.SEPARATOR_ID);

		int[] indices = m_Values.keys();
		for (int i = 0; i < indices.length; i++) {
			if (!m_MetaData.isIgnored(indices[i])) {
				sb.append(indices[i]).append(MetaData.SEPARATOR_DATA_INNER)
						.append(stringValue(indices[i]))
						.append(MetaData.SEPARATOR_DATA);
			}
		}
		if (sb.length() > 0) {
			sb.setLength(sb.length() - 1);
		}
		return sb.toString();
	}

	@Override
	public void readFields(DataInput input) throws IOException {
		m_ID = Varint.readUnsignedVarInt(input);
		m_Values = SparseDoubleMap.read(m_MetaData, input);
	}

	@Override
	public void write(DataOutput out) throws IOException {
		Varint.writeUnsignedVarInt(getID(), out);
		m_Values.write(out);
	}

	public int getStoreBytes() {
		return Integer.SIZE / 8 + m_Values.getStoreBytes();
	}

	public static SparseDoubleInstance read(DataInput input, MetaData metaData,
			SparseDoubleInstance instance) throws IOException {
		if (instance == null) {
			instance = new SparseDoubleInstance(metaData);
		}
		instance.readFields(input);
		return instance;
	}

	public static SparseDoubleInstance parseText(MetaData metaData, int ID,
			String[] text, SparseDoubleInstance instance) {

		if (text != null) {
			if (instance == null) {
				instance = new SparseDoubleInstance(ID, metaData);
			}
			instance.m_ID = ID;
			String[] array = new String[2];
			int len;
			for (String t : text) {
				len = StringUtils.splitTwoPart(t,
						MetaData.SEPARATOR_DATA_INNER, array);

				if (len == 1) {
					try {
						int index = Integer.parseInt(array[0]);
						if (index >= 0) {
							instance.setErrorValue(index);
						}
					} catch (NumberFormatException e) {

					}
				} else if (len == 2) {
					int index = -1;
					try {
						index = Integer.parseInt(array[0]);
					} catch (NumberFormatException e) {

					}

					if (index >= 0) {
						IAttribute attr = metaData.getAttributeAt(index);
						switch (attr.getType()) {
						case COUNT:
							try {
								instance.setValue(index,
										Integer.parseInt(array[1]));
							} catch (NumberFormatException e) {
								instance.setErrorValue(index);
							}
							break;
						case NOMINAL:
						case ORDINAL:
							if (array[1] == null || array[1].isEmpty()) {
								instance.setErrorValue(index);
							} else {
								instance.setValue(index,
										((NominalAttribute) attr).encode(
												array[1], true));
							}
							break;
						case BOOLEAN:
							if (array[1] == null || array[1].isEmpty()) {
								instance.setErrorValue(index);
							} else {
								try {
									instance.setValue(index, Boolean
											.parseBoolean(array[1]) ? 1 : 0);
								} catch (NumberFormatException e) {
									instance.setErrorValue(index);
								}
							}
							break;
						case NUMERIC:
						default:
							try {
								instance.setValue(index,
										Double.parseDouble(array[1]));
							} catch (NumberFormatException e) {
								instance.setErrorValue(index);
							}
							break;
						}
					}
				}

			}
			return instance;
		}
		return null;
	}

	public static SparseDoubleInstance emptyInstance(MetaData metaData) {
		SparseDoubleInstance instance = new SparseDoubleInstance(metaData);
		return instance;
	}

}
