/**
 * Created by Xiaojun Chen at 2012-7-2
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.numeric.sparse;

import common.data.instance.ISparseInstance;
import common.data.instance.numeric.INumericInstance;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public interface ISparseNumericInstance extends ISparseInstance,
		INumericInstance {

	public ISparseNumericInstance clone();

	public ISparseNumericInstance like();

}
