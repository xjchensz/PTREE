/**
 * Created by Xiaojun Chen at 2012-6-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.numeric.sparse;

import common.data.instance.ISparseInstance;
import common.data.instance.numeric.IBooleanInstance;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public interface IBooleanSparseInstance extends IBooleanInstance,
		ISparseInstance {

	/**
	 * Clone instance
	 * */
	public IBooleanSparseInstance clone();

	/**
	 * @return a new value with all elements as zero
	 * 
	 * */
	public IBooleanSparseInstance like();

}
