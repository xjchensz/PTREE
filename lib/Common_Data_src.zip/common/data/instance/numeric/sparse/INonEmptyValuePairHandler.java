/**
 * 
 */
package common.data.instance.numeric.sparse;

/**
 * @author xiaojun chen
 *
 */
public interface INonEmptyValuePairHandler {

	public void handle(int index, double v1, double v2);

}
