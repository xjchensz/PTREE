/**
 * Created by Xiaojun Chen at 2011-12-14
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.utils;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import common.data.meta.MetaData;
import common.utils.collection.ORDER;
import common.utils.collection.OrderedIntMap;
import common.utils.math.Varint;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class SparseIntMap extends OrderedIntMap {

	/**
	 * 
	 */
	private static final long serialVersionUID = -838404948277405585L;

	/**
	 * Returns a new instance of an SparseMap with initial capacity of zero.
	 * Equivalent to calling the default constructor, except without the need to
	 * specify the type parameters.
	 */
	public static SparseIntMap create(MetaData metaData) {
		return create(metaData, ORDER.ASC);
	}

	/**
	 * Returns a new instance of an SparseMap with initial capacity of zero.
	 * Equivalent to calling the default constructor.
	 */
	public static SparseIntMap create(MetaData metaData, ORDER order) {
		return create(metaData, 10, order);
	}

	/**
	 * Returns a new instance of an SparseMap of the given initial capacity. For
	 */
	public static SparseIntMap create(MetaData metaData, int initialCapacity) {
		return create(metaData, initialCapacity, ORDER.ASC);
	}

	/**
	 * Returns a new instance of an array map of the given initial capacity. For
	 */
	public static SparseIntMap create(MetaData metaData, int initialCapacity,
			ORDER order) {
		SparseIntMap result = new SparseIntMap(metaData, order);
		result.ensureCapacity(initialCapacity);
		return result;
	}

	protected MetaData m_MetaData;

	/**
	 * 
	 */
	protected SparseIntMap(MetaData metadata) {
		m_MetaData = metadata;
	}

	/**
	 * @param order
	 */
	protected SparseIntMap(MetaData metadata, ORDER order) {
		super(order);
		m_MetaData = metadata;
	}

	public MetaData getMetaData() {
		return m_MetaData;
	}

	public SparseIntMap newInstance() {
		return create(m_MetaData, size(), m_order);
	}

	@Override
	public SparseIntMap clone() {
		SparseIntMap newMap = create(m_MetaData, size(), m_order);
		copyContent(newMap);
		return newMap;
	}

	public void destroy() {
		super.destroy();
		this.m_MetaData = null;
	}

	public void readFields(DataInput input) throws IOException {
		m_order = ORDER.values()[input.readByte()];
		size = Varint.readUnsignedVarInt(input);
		keyset = new int[size];
		m_Values = new int[size];
		for (int i = 0; i < size; i++) {
			keyset[i] = Varint.readUnsignedVarInt(input);
			switch (m_MetaData.getAttributeTypeAt(keyset[i])) {
			case BOOLEAN:
				// read nothing
				break;
			case COUNT:
			case NOMINAL:
			case ORDINAL:
				m_Values[i] = Varint.readUnsignedVarInt(input);
				break;
			case NUMERIC:
			default:
				m_Values[i] = Varint.readSignedVarInt(input);
				break;
			}
		}
	}

	public void write(DataOutput out) throws IOException {
		out.writeByte(m_order.ordinal());
		Varint.writeUnsignedVarInt(size, out);
		for (int i = 0; i < size; i++) {
			Varint.writeUnsignedVarInt(keyset[i], out);
			switch (m_MetaData.getAttributeTypeAt(keyset[i])) {
			case BOOLEAN:
				// write nothing
				break;
			case COUNT:
			case NOMINAL:
			case ORDINAL:
				Varint.writeUnsignedVarInt(m_Values[i], out);
				break;
			case NUMERIC:
			default:
				Varint.writeSignedVarInt(m_Values[i], out);
				break;
			}
		}
	}

	public int getStoreBytes() {
		int bytes = 1 + Varint.numBytesToWriteUnsignedVarInt(size);
		for (int i = 0; i < size; i++) {
			bytes += Varint.numBytesToWriteUnsignedVarInt(keyset[i]);
			switch (m_MetaData.getAttributeTypeAt(keyset[i])) {
			case BOOLEAN:
				// write nothing
				break;
			// Categorical and Count data write as int
			case COUNT:
			case NOMINAL:
			case ORDINAL:
				bytes += Varint.numBytesToWriteUnsignedVarInt(m_Values[i]);
				break;
			case NUMERIC:
			default:
				bytes += Varint.numBytesToWriteSignedVarInt(m_Values[i]);
				break;

			}
		}
		return bytes;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof SparseIntMap)) {
			return false;
		}

		SparseIntMap sm = (SparseIntMap) obj;
		if (!sm.m_MetaData.equals(m_MetaData)) {
			return false;
		}

		return super.equals(obj);
	}

	public static SparseIntMap read(MetaData metaData, DataInput input)
			throws IOException {
		SparseIntMap map = SparseIntMap.create(metaData);
		map.readFields(input);
		return map;
	}
}
