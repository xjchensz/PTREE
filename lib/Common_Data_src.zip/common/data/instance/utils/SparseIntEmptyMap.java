/**
 * Created by Xiaojun Chen at 2011-12-14
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.utils;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import common.data.meta.MetaData;
import common.utils.collection.ORDER;
import common.utils.collection.OrderedIntArraySet;
import common.utils.math.Varint;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class SparseIntEmptyMap extends SparseIntMap {

	/**
	 * 
	 */
	private static final long serialVersionUID = -838404948277405585L;

	public static final int DEFAULT_EMPTY_VALUE = Integer.MAX_VALUE;

	protected int emptyValue = DEFAULT_EMPTY_VALUE;

	/**
	 * Returns a new instance of an SparseMap with initial capacity of zero.
	 * Equivalent to calling the default constructor, except without the need to
	 * specify the type parameters.
	 */
	public static SparseIntEmptyMap create(MetaData metaData) {
		return create(metaData, ORDER.ASC);
	}

	/**
	 * Returns a new instance of an SparseMap with initial capacity of zero.
	 * Equivalent to calling the default constructor.
	 */
	public static SparseIntEmptyMap create(MetaData metaData, ORDER order) {
		return create(metaData, 10, order, DEFAULT_EMPTY_VALUE);
	}

	/**
	 * Returns a new instance of an SparseMap of the given initial capacity. For
	 */
	public static SparseIntEmptyMap create(MetaData metaData,
			int initialCapacity) {
		return create(metaData, initialCapacity, ORDER.ASC, DEFAULT_EMPTY_VALUE);
	}

	/**
	 * Returns a new instance of an SparseMap of the given initial capacity. For
	 */
	public static SparseIntEmptyMap create(MetaData metaData,
			int initialCapacity, ORDER order) {
		return create(metaData, initialCapacity, order, DEFAULT_EMPTY_VALUE);
	}

	/**
	 * Returns a new instance of an array map of the given initial capacity. For
	 */
	public static SparseIntEmptyMap create(MetaData metaData,
			int initialCapacity, ORDER order, int emptyValue) {
		SparseIntEmptyMap result = new SparseIntEmptyMap(metaData, order);
		result.ensureCapacity(initialCapacity);
		result.emptyValue = emptyValue;
		return result;
	}

	/**
	 * 
	 */
	protected SparseIntEmptyMap(MetaData metadata, int emptyValue) {
		super(metadata);
		this.emptyValue = emptyValue;
	}

	public int getEmptyValue() {
		return emptyValue;
	}

	/**
	 * @param order
	 */
	protected SparseIntEmptyMap(MetaData metadata, ORDER order) {
		super(metadata, order);
	}

	public SparseIntEmptyMap newInstance() {
		return create(m_MetaData, size(), m_order);
	}

	@Override
	public SparseIntEmptyMap clone() {
		SparseIntEmptyMap newMap = create(m_MetaData, size(), m_order);
		copyContent(newMap);
		return newMap;
	}

	public void readFields(DataInput input) throws IOException {
		emptyValue = Varint.readSignedVarInt(input);
		super.readFields(input);
	}

	public void write(DataOutput out) throws IOException {
		Varint.writeSignedVarInt(emptyValue, out);
		super.write(out);
	}

	public int getStoreBytes() {
		return +Varint.numBytesToWriteSignedVarInt(emptyValue)
				+ super.getStoreBytes();
	}

	public int put(int key, int value) {
		if (value == emptyValue) {
			int index = findLastIndexForKey(0, key);
			if (index < size && keyset[index] == key) {
				// remove value
				return remove(key);
			} else {
				// ignore
				return emptyValue;
			}
		} else {
			return super.put(key, value);
		}
	}

	public int get(int key) {
		int index = findIndexForKey(0, key);
		if (index < size) {
			if (keyset[index] == key) {
				return m_Values[index];
			}
		}
		return emptyValue;
	}

	public int[] getkeyWithValue(int value) {
		if (value == emptyValue) {
			return null;
		}

		return super.getkeyWithValue(value);
	}

	public int remove(int key) {
		int index = findLastIndexForKey(0, key);
		if (index < size && keyset[index] == key) {
			int oldValue = m_Values[index];
			// copy
			System.arraycopy(keyset, index + 1, keyset, index, size - index - 1);
			System.arraycopy(m_Values, index + 1, m_Values, index, size - index
					- 1);
			size--;
			return oldValue;
		}
		return emptyValue;
	}

	public void removeAll(int key, OrderedIntArraySet set) {

		switch (m_status) {

		case DISTINCT:
			int value = remove(key);
			if (value != emptyValue) {
				set.add(value);
			}
			break;
		default:
			super.removeAll(key, set);
		}

	}

	public int removeFirst() {
		if (size == 0) {
			return emptyValue;
		} else {
			int oldValue = m_Values[0];
			// copy
			System.arraycopy(keyset, 1, keyset, 0, size - 1);
			System.arraycopy(m_Values, 1, m_Values, 0, size - 1);
			size--;
			return oldValue;
		}
	}

	public int removeLast() {
		if (size == 0) {
			return emptyValue;
		} else {
			size--;
			return m_Values[size];
		}
	}

	public boolean containsValue(int value) {
		if (value == emptyValue) {
			return false;
		}
		for (int i = 0; i < size; i++) {
			if (m_Values[i] == value) {
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof SparseIntEmptyMap)) {
			return false;
		}

		SparseIntEmptyMap sm = (SparseIntEmptyMap) obj;
		return emptyValue == sm.emptyValue && super.equals(obj);
	}

	public static SparseIntEmptyMap read(MetaData metaData, DataInput input)
			throws IOException {
		SparseIntEmptyMap map = SparseIntEmptyMap.create(metaData);
		map.readFields(input);
		return map;
	}
}
