/**
 * Created by Xiaojun Chen at 2011-12-14
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.utils;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import common.data.meta.MetaData;
import common.utils.collection.ORDER;
import common.utils.collection.OrderedDoubleMap;
import common.utils.math.Varint;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class SparseDoubleMap extends OrderedDoubleMap {

	/**
	 * Returns a new instance of an SparseMap with initial capacity of zero.
	 * Equivalent to calling the default constructor, except without the need to
	 * specify the type parameters.
	 */
	public static SparseDoubleMap create(MetaData metaData) {
		return create(metaData, ORDER.ASC);
	}

	/**
	 * Returns a new instance of an SparseMap with initial capacity of zero.
	 * Equivalent to calling the default constructor.
	 */
	public static SparseDoubleMap create(MetaData metaData, ORDER order) {
		return create(metaData, 10, order, 0);
	}

	/**
	 * Returns a new instance of an SparseMap of the given initial capacity. For
	 */
	public static SparseDoubleMap create(MetaData metaData, int initialCapacity) {
		return create(metaData, initialCapacity, ORDER.ASC, 0);
	}

	/**
	 * Returns a new instance of an SparseMap of the given initial capacity. For
	 */
	public static SparseDoubleMap create(MetaData metaData,
			int initialCapacity, ORDER order) {
		return create(metaData, initialCapacity, order, 0);
	}

	/**
	 * Returns a new instance of an array map of the given initial capacity. For
	 */
	public static SparseDoubleMap create(MetaData metaData,
			int initialCapacity, ORDER order, double emptyValue) {
		SparseDoubleMap result = new SparseDoubleMap(metaData, order);
		result.ensureCapacity(initialCapacity);
		result.emptyValue = emptyValue;
		return result;
	}

	protected MetaData m_MetaData;

	/**
	 * 
	 */
	protected SparseDoubleMap(MetaData metadata) {
		m_MetaData = metadata;
	}

	/**
	 * @param order
	 */
	protected SparseDoubleMap(MetaData metadata, ORDER order) {
		super(order);
		m_MetaData = metadata;
	}

	public MetaData getMetaData() {
		return m_MetaData;
	}

	public SparseDoubleMap newInstance() {
		return create(m_MetaData, size(), m_order);
	}

	@Override
	public SparseDoubleMap clone() {
		SparseDoubleMap newMap = create(m_MetaData, size(), m_order);
		copyContent(newMap);
		return newMap;
	}

	public void destroy() {
		super.destroy();
		this.m_MetaData = null;
	}

	public void readFields(DataInput input) throws IOException {
		m_order = ORDER.values()[input.readByte()];
		emptyValue = input.readDouble();
		size = Varint.readUnsignedVarInt(input);
		keyset = new int[size];
		values = new double[size];
		for (int i = 0; i < size; i++) {
			keyset[i] = Varint.readUnsignedVarInt(input);
			switch (m_MetaData.getAttributeTypeAt(keyset[i])) {
			case NOMINAL:
			case ORDINAL:
			case COUNT:
				values[i] = Varint.readUnsignedVarInt(input);
				break;
			case BOOLEAN:
				// read nothing
				values[i] = 1;
				break;
			case NUMERIC:
			default:
				values[i] = input.readDouble();
				break;
			}
		}
	}

	public void write(DataOutput out) throws IOException {
		out.writeByte(m_order.ordinal());
		out.writeDouble(emptyValue);
		Varint.writeUnsignedVarInt(size, out);
		for (int i = 0; i < size; i++) {
			Varint.writeUnsignedVarInt(keyset[i], out);
			switch (m_MetaData.getAttributeTypeAt(keyset[i])) {
			case NOMINAL:
			case ORDINAL:
			case COUNT:
				Varint.writeUnsignedVarInt((int) values[i], out);
				break;
			case BOOLEAN:
				// write nothing
				break;
			case NUMERIC:
			default:
				out.writeDouble(values[i]);
				break;
			}
		}
	}

	public int getStoreBytes() {
		int bytes = (Byte.SIZE + Double.SIZE) / 8
				+ Varint.numBytesToWriteUnsignedVarInt(size);
		for (int i = 0; i < size; i++) {
			bytes += Varint.numBytesToWriteUnsignedVarInt(keyset[i]);
			switch (m_MetaData.getAttributeTypeAt(keyset[i])) {
			case NOMINAL:
			case ORDINAL:
			case COUNT:
				bytes += Varint.numBytesToWriteUnsignedVarInt((int) values[i]);
				break;
			case BOOLEAN:
				// write nothing
				break;
			case NUMERIC:
			default:
				bytes += Double.SIZE / 8;
				break;
			}
		}
		return bytes;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof SparseDoubleMap)) {
			return false;
		}

		SparseDoubleMap sm = (SparseDoubleMap) obj;
		if (!sm.m_MetaData.equals(m_MetaData)) {
			return false;
		}

		return super.equals(obj);
	}

	public static SparseDoubleMap read(MetaData metaData, DataInput input)
			throws IOException {
		SparseDoubleMap map = new SparseDoubleMap(metaData);
		map.readFields(input);
		return map;
	}

}
