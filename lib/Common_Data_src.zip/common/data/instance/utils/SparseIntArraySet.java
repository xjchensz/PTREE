/**
 * Created by Xiaojun Chen at 2012-7-2
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.utils;

import java.io.DataInput;
import java.io.IOException;

import common.data.meta.MetaData;
import common.utils.collection.ORDER;
import common.utils.collection.OrderedIntArraySet;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class SparseIntArraySet extends OrderedIntArraySet {

	/**
	 * Returns a new instance of an SparseMap with initial capacity of zero.
	 * Equivalent to calling the default constructor, except without the need to
	 * specify the type parameters.
	 */
	public static SparseIntArraySet create(MetaData metaData) {
		return create(metaData, ORDER.ASC);
	}

	/**
	 * Returns a new instance of an SparseMap with initial capacity of zero.
	 * Equivalent to calling the default constructor.
	 */
	public static SparseIntArraySet create(MetaData metaData, ORDER order) {
		return create(metaData, 10, order);
	}

	/**
	 * Returns a new instance of an SparseMap of the given initial capacity. For
	 */
	public static SparseIntArraySet create(MetaData metaData, int initialCapacity) {
		return create(metaData, initialCapacity, ORDER.ASC);
	}

	/**
	 * Returns a new instance of an array map of the given initial capacity. For
	 */
	public static SparseIntArraySet create(MetaData metaData, int initialCapacity, ORDER order) {
		SparseIntArraySet result = new SparseIntArraySet(metaData, order);
		result.ensureCapacity(initialCapacity);
		return result;
	}

	protected MetaData m_MetaData;

	/**
	 * 
	 */
	protected SparseIntArraySet(MetaData metadata) {
		m_MetaData = metadata;
	}

	/**
	 * @param order
	 */
	protected SparseIntArraySet(MetaData metadata, ORDER order) {
		super(order);
		m_MetaData = metadata;
	}

	public MetaData getMetaData() {
		return m_MetaData;
	}

	public SparseIntArraySet newInstance() {
		return create(m_MetaData, size(), m_order);
	}

	public boolean trueValue(int attr) {
		if (attr < 0 || attr >= m_MetaData.numAllAttributes()) {
			throw new ArrayIndexOutOfBoundsException();
		}
		return containsValue(attr);
	}

	/**
	 * from (inclusive), to (exclusive)
	 */
	public int[] inverseValues(int fromValue, int toValue, boolean ignoreMetaData) {
		if (ignoreMetaData || m_MetaData.numIgnored() == 0) {
			return super.inverseContains(fromValue, toValue);
		} else {
			OrderedIntArraySet list = super.clone();
			int[] ignored = m_MetaData.getIgnored();
			for (int i = 0; i < ignored.length; i++) {
				list.removeValue(ignored[i]);
			}
			int[] values = list.inverseContains(fromValue, toValue);
			list.destroy();
			return values;
		}
	}

	public int[] getAllTrueValues(boolean ignoreMetaData) {
		if (ignoreMetaData || m_MetaData.numIgnored() == 0) {
			return values();
		} else {
			OrderedIntArraySet list = super.clone();
			int[] ignored = m_MetaData.getIgnored();
			for (int i = 0; i < ignored.length; i++) {
				list.removeValue(ignored[i]);
			}
			int[] values = list.values();
			list.destroy();
			return values;
		}
	}

	public int[] getAllFalseValues(boolean ignoreMetaData) {
		if (ignoreMetaData || m_MetaData.numIgnored() == 0) {
			return super.inverseContains(0, m_MetaData.numAllAttributes());
		} else {
			OrderedIntArraySet list = inverseClone(0, m_MetaData.numAllAttributes());

			int[] ignored = m_MetaData.getIgnored();
			for (int i = 0; i < ignored.length; i++) {
				list.removeValue(ignored[i]);
			}
			int[] values = list.values();

			list.destroy();
			return values;
		}
	}

	public boolean[] booleanValues(int fromValue, int toValue, boolean ignoreMetaData) {
		if (ignoreMetaData || m_MetaData.numIgnored() == 0) {
			return super.booleanContains(fromValue, toValue);
		} else {
			boolean[] bvs = super.booleanContains(fromValue, toValue);
			int[] ignored = m_MetaData.getIgnored();

			if (fromValue < toValue) {
				for (int i = 0; i < ignored.length; i++) {
					bvs[ignored[i] - fromValue] = false;
				}
			} else {
				for (int i = 0; i < ignored.length; i++) {
					bvs[ignored[i] - toValue] = false;
				}
			}
			return bvs;
		}
	}

	public boolean[] booleanValues(boolean ignoreMetaData) {
		return booleanValues(0, m_MetaData.numAllAttributes(), ignoreMetaData);
	}

	@Override
	public SparseIntArraySet clone() {
		SparseIntArraySet newList = create(m_MetaData, size(), m_order);
		copyContent(newList);
		return newList;
	}

	public void destroy() {
		super.destroy();
		this.m_MetaData = null;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if ((obj == null) || !(obj instanceof SparseIntArraySet)) {
			return false;
		}

		SparseIntArraySet sm = (SparseIntArraySet) obj;
		if (!sm.m_MetaData.equals(m_MetaData)) {
			return false;
		}

		return super.equals(sm);
	}

	public static SparseIntArraySet read(MetaData metaData, DataInput input) throws IOException {
		SparseIntArraySet list = new SparseIntArraySet(metaData);
		list.readFields(input);
		return list;
	}

}
