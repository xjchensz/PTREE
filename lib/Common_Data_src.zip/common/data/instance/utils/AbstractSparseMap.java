/**
 * Created by Xiaojun Chen at 2012-6-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.utils;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class AbstractSparseMap {

	/**
	 * 
	 */
	public AbstractSparseMap() {
	}

}
