package common.data.instance;

import java.io.Serializable;

import common.IWritable;
import common.data.instance.math.CardinalityException;
import common.data.instance.math.EmptyValueException;
import common.data.instance.math.UnexpectedInstanceTypeException;
import common.data.meta.MetaData;

/**
 * Interface for non-sparse instance and sparse instance
 * 
 * @author Xiaojun Chen
 * 
 */
public interface IInstance extends Cloneable, IWritable, Serializable {

	/**
	 * @return metaData
	 * */
	public MetaData getMetaData();

	/**
	 * @return id, should be non-negative integer
	 * */
	public int getID();

	/**
	 * Get the number of non-empty attributes in the instance
	 * 
	 * @return the number of non-empty attributes
	 */
	public int size();

	/**
	 * Assign the other instance values to the receiver
	 * 
	 * @param other
	 *            a instance
	 * @throws CardinalityException
	 *             if the cardinalities differ
	 */
	public void assign(IInstance other) throws EmptyValueException,
			UnexpectedInstanceTypeException, CardinalityException;

	/**
	 * Clone instance
	 * */
	public IInstance clone();

	/**
	 * @return a new value with all elements as zero
	 * 
	 * */
	public IInstance like();

	/**
	 * set all elements to zero
	 */
	public void clear();

	/**
	 * destroy the instance to release memory
	 * */
	public void destroy();

	/**
	 * return string with sql format
	 * */
	public String toSQLString();

	/**
	 * return string with file format
	 * */
	public String toFileRecordString();

	/**
	 * @return the no. of bytes to store the instance
	 * */
	public int getStoreBytes();

	/**
	 * attributeIndex: index of the attribute
	 * */
	public boolean equalsInAttribute(Object obj, int attributeIndex);
}
