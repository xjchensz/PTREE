package common.data.instance.math;

/**
 * @author Xiaojun Chen
 * 
 * @version 0.1
 * 
 *          Exception thrown when there is a cardinality mismatch in matrix or
 *          vector operations. For example, vectors of differing cardinality
 *          cannot be added.
 */
public class CardinalityException extends IllegalArgumentException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8292815654147791871L;

	public CardinalityException(int expected, int cardinality) {
		super("Required cardinality " + expected + " but got " + cardinality);
	}

}
