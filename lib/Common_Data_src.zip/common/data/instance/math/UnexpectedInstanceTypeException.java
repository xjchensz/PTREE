/**
 * Created by Xiaojun Chen at 2012-6-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.math;

import common.data.instance.IInstance;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class UnexpectedInstanceTypeException extends IllegalArgumentException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5829695040994689143L;

	public UnexpectedInstanceTypeException(Class<? extends IInstance> expected,
			Class<? extends IInstance> actual) {
		super("Required instance " + expected.getName() + " but got "
				+ actual.getName());
	}

}
