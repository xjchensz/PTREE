/**
 * Created by Xiaojun Chen at 2012-7-13
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance.math;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class EmptyValueException extends IllegalArgumentException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6501574619205232004L;

	/**
	 * 
	 */
	public EmptyValueException() {
	}

	/**
	 * @param s
	 */
	public EmptyValueException(String s) {
		super(s);
	}

	/**
	 * @param cause
	 */
	public EmptyValueException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public EmptyValueException(String message, Throwable cause) {
		super(message, cause);
	}

}
