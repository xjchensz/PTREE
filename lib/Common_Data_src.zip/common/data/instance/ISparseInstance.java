/**
 * Created by Xiaojun Chen at 2011-10-30
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.instance;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public interface ISparseInstance extends IInstance {

	/**
	 * @return a new value with all elements as zero
	 * 
	 * */
	public ISparseInstance like();

	public ISparseInstance clone();
}
