/**
 * Created by Xiaojun Chen at 2011-11-22
 */
package common.data.distance;

import common.data.instance.numeric.INumericInstance;

/**
 * This interface is used for objects which can determine a distance metric
 * between two points
 * 
 * @version 0.1
 */
public interface InstanceDistanceMeasure extends IDistance<INumericInstance> {

	/**
	 * Returns the distance metric applied to the arguments
	 * 
	 * @param v1
	 *            a numeric instance defining a multidimensional point in some
	 *            feature space
	 * @param v2
	 *            a numeric instance defining a multidimensional point in some
	 *            feature space
	 * @return a scalar doubles of the distance
	 */
	double distance(INumericInstance v1, INumericInstance v2);

	public InstanceDistanceMeasure clone();

}
