/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package common.data.distance;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import common.data.instance.math.CardinalityException;
import common.data.instance.numeric.INumericInstance;
import common.data.instance.numeric.sparse.INonEmptyValuePairHandler;
import common.utils.ChangeAbleDouble;

/**
 * Implement Minkowski distance, a real-valued generalization of the integral
 * L(n) distances: Manhattan = L1, Euclidean = L2. For high numbers of
 * dimensions, very high exponents give more useful distances.
 * 
 * Note: Math.pow is clever about integer-valued doubles.
 **/
public class MinkowskiDistanceMeasure extends AbstractDistance {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String PARAMETER_EXPONENT = "distance.minkowski.exponent";
	private static final double EXPONENT = 3.0;

	private double exponent = EXPONENT;

	public MinkowskiDistanceMeasure() {
	}

	public MinkowskiDistanceMeasure(double exponent) {
		this.exponent = exponent;
	}

	public double getExponent() {
		return exponent;
	}

	public void setExponent(double exponent) {
		this.exponent = exponent;
	}

	@Override
	public double distance(INumericInstance v1, INumericInstance v2) {
		return distance(v1, v2, exponent);
	}

	@Override
	public double _distance(INumericInstance v1, INumericInstance v2) {
		return 0;
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeDouble(exponent);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		exponent = in.readDouble();
	}

	public static double distance(final INumericInstance v1, final INumericInstance v2, final double p) {
		if (v2 == null || v1 == null) {
			return Double.POSITIVE_INFINITY;
		}

		if (v1.getMetaData().numAllAttributes() != v2.getMetaData().numAllAttributes()) {
			throw new CardinalityException(v1.getMetaData().numUsedAttributes(), v2.getMetaData().numUsedAttributes());
		}
		final ChangeAbleDouble cd = new ChangeAbleDouble();
		v1.processNonEmptyValues(v2, new INonEmptyValuePairHandler() {

			@Override
			public void handle(int index, double v1, double v2) {
				cd.add(Math.pow(v1 - v2, p));
			}
		});
		return Math.pow(cd.getValue(), 1.0 / p);
	}

	public static double distance(final INumericInstance v1, final INumericInstance v2, final INumericInstance weights,
			final double p) {
		if (v2 == null || v1 == null) {
			return 1;
		}

		if (v1.getMetaData().numAllAttributes() != v2.getMetaData().numAllAttributes()) {
			throw new CardinalityException(v1.getMetaData().numUsedAttributes(), v2.getMetaData().numUsedAttributes());
		}

		if (v1.getMetaData().numAllAttributes() != weights.getMetaData().numAllAttributes()) {
			throw new CardinalityException(v1.getMetaData().numUsedAttributes(),
					weights.getMetaData().numUsedAttributes());
		}
		final ChangeAbleDouble cd = new ChangeAbleDouble();

		v1.processNonEmptyValues(v2, new INonEmptyValuePairHandler() {

			@Override
			public void handle(int index, double v1, double v2) {
				cd.add(weights.doubleValue(index) * Math.pow(v1 - v2, p));
			}
		});

		return Math.pow(cd.getValue(), 1.0 / p);
	}

	public MinkowskiDistanceMeasure clone() {
		return new MinkowskiDistanceMeasure(exponent);
	}
}
