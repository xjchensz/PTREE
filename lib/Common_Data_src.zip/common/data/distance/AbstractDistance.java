/**
 * 
 */
package common.data.distance;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import common.data.instance.math.CardinalityException;
import common.data.instance.numeric.INumericInstance;

/**
 * @author xiaojun chen
 *
 */
public abstract class AbstractDistance implements InstanceDistanceMeasure {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3382263754796275481L;

	protected AbstractDistance() {
	}

	public double distance(INumericInstance v1, INumericInstance v2) {

		if (v2 == null || v1 == null) {
			return maxDistance();
		}

		if (v1.getMetaData().numAllAttributes() != v2.getMetaData().numAllAttributes()) {
			throw new CardinalityException(v1.getMetaData().numUsedAttributes(), v2.getMetaData().numUsedAttributes());
		}
		return _distance(v1, v2);
	}

	protected double maxDistance() {
		return Double.POSITIVE_INFINITY;
	}

	protected abstract double _distance(INumericInstance v1, INumericInstance v2);

	@Override
	public void write(DataOutput out) throws IOException {

	}

	@Override
	public void readFields(DataInput in) throws IOException {

	}

	public abstract AbstractDistance clone();
}
