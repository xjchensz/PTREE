/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package common.data.distance;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import common.data.instance.numeric.INumericInstance;
import common.data.instance.numeric.sparse.INonEmptyValuePairHandler;
import common.data.meta.MetaData;
import common.utils.ChangeAbleDouble;

/**
 * created by cl.fan 2011-12-26 This class implements a "PrototypesDistance "
 * which merge the numeric distance and category distance
 * 
 */
public class PrototypesDistanceMeasure extends AbstractDistance {

	/**
	 * 
	 */
	private static final long serialVersionUID = -662355569267538025L;
	private double m_r = 0.5;// to denote the weight parameter in Prototypes
								// between numeric and category

	protected PrototypesDistanceMeasure() {
	}

	public void setWeights(double weight) {
		m_r = weight;
	}

	@Override
	protected double _distance(INumericInstance v1, INumericInstance v2) {

		final MetaData metadata = v1.getMetaData();
		final ChangeAbleDouble cd = new ChangeAbleDouble();
		v1.processNonEmptyValues(v2, new INonEmptyValuePairHandler() {

			@Override
			public void handle(int index, double v1, double v2) {
				switch (metadata.getAttributeTypeAt(index)) {
				case NOMINAL:
				case ORDINAL:
				case COUNT:
					if (v1 == v2 && v1 != 0)
						cd.add(m_r);
					break;
				default:
					cd.add(Math.pow(v1 - v2, 2));
					break;
				}
			}
		});

		return cd.getValue();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeDouble(m_r);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		m_r = in.readDouble();
	}

	public PrototypesDistanceMeasure clone() {
		PrototypesDistanceMeasure pm = new PrototypesDistanceMeasure();
		pm.setWeights(m_r);
		return pm;
	}
}
