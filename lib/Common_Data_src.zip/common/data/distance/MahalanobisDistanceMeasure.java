/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package common.data.distance;

import common.data.instance.numeric.INumericInstance;

/*
 * @author by cl.fan
 *
 * */

//See http://en.wikipedia.org/wiki/Mahalanobis_distance for details
/*

 */
public class MahalanobisDistanceMeasure extends AbstractDistance implements InstanceDistanceMeasure {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private double[][] m_Covariance;

	public MahalanobisDistanceMeasure(double[][] covariance) {
		m_Covariance = covariance;
	}

	@Override
	public double _distance(INumericInstance v1, INumericInstance v2) {
		INumericInstance minus = v1.clone();
		minus.minus(v2);

		int size = v1.getMetaData().numAllAttributes();
		double result = 0;

		for (int i = 0, j; i < size; i++)
			for (j = 0; j < size; j++) {
				result += minus.doubleValue(i) * m_Covariance[i][j] * minus.doubleValue(j);
			}
		return result;
	}

	public MahalanobisDistanceMeasure clone() {
		return new MahalanobisDistanceMeasure(m_Covariance);
	}

}
