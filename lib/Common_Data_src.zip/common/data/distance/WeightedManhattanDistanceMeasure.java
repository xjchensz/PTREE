/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package common.data.distance;

import common.data.instance.numeric.INumericInstance;
import common.data.instance.numeric.sparse.INonEmptyValuePairHandler;
import common.utils.ChangeAbleDouble;

/**
 * This class implements a "Manhattan distance" metric by summing the absolute
 * values of the difference between each coordinate, optionally with weights.
 */
public class WeightedManhattanDistanceMeasure extends WeightedDistanceMeasure {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3515713648673611993L;

	@Override
	protected double _distance(INumericInstance v1, INumericInstance v2) {

		final ChangeAbleDouble cd = new ChangeAbleDouble();
		v1.processNonEmptyValues(v2, new INonEmptyValuePairHandler() {

			@Override
			public void handle(int index, double v1, double v2) {
				cd.add(Math.abs(v1 - v2) * m_Weights[index]);
			}
		});
		return cd.getValue();
	}

	public WeightedManhattanDistanceMeasure clone() {
		WeightedManhattanDistanceMeasure wdm = new WeightedManhattanDistanceMeasure();
		wdm.setWeights(m_Weights);
		return wdm;
	}
}
