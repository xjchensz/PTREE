/**
 * Created by Xiaojun Chen at 2011-11-22
 * Shenzhen High Performance Data Mining Lab 
 */

package common.data.distance;

import common.data.instance.numeric.INumericInstance;
import common.data.instance.numeric.sparse.INonEmptyValueHandler;
import common.utils.ChangeAbleDouble;

/**
 * This class implements a "Chebyshev distance" metric by finding the maximum
 * difference between each coordinate. Also 'chessboard distance' due to the
 * moves a king can make.
 */
public class ChebyshevDistanceMeasure extends AbstractDistance {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7787245584525114634L;
	public static ChebyshevDistanceMeasure m_Distance;

	public static ChebyshevDistanceMeasure getInstance() {
		if (m_Distance == null) {
			m_Distance = new ChebyshevDistanceMeasure();
		}
		return m_Distance;
	}

	@Override
	protected double _distance(INumericInstance v1, INumericInstance v2) {
		final ChangeAbleDouble cd = new ChangeAbleDouble(-Double.MAX_VALUE);

		INumericInstance nv1 = v1.clone();
		nv1.minus(v2);
		nv1.processNonEmptyValues(new INonEmptyValueHandler() {

			@Override
			public void handle(int index, double value) {
				cd.max(value);
			}
		});
		return cd.getValue();
	}

	public ChebyshevDistanceMeasure clone() {
		return getInstance();
	}
}
