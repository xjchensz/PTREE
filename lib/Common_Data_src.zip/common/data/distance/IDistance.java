/**
 * Created by Xiaojun Chen at 2011-11-22
 */
package common.data.distance;

import common.IWritable;

/**
 * @author xiaojun chen
 *
 */
public interface IDistance<T> extends IWritable {

	public double distance(T v1, T v2);

	public IDistance<T> clone();
}
