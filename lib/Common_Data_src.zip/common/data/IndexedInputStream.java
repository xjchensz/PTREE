/**
 * Created by Xiaojun Chen at 2012-3-27
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data;

import java.io.IOException;
import java.io.InputStream;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public interface IndexedInputStream {

	public InputStream subInputStream(int rowStart, int rowEnd)
			throws IOException, Exception;

	public void close();
}
