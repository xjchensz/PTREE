/**
 * Created by Xiaojun Chen at 2012-3-28
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data;

import java.io.IOException;

import common.data.instance.IInstance;
import common.data.meta.MetaData;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class SubDataIterator<T extends IInstance> implements IDataIterator<T> {

	private IDataIterator<? extends T> dataIterator;
	private int rowStart;
	private int rowEnd;
	private boolean closeAble;

	/**
	 * @throws Exception
	 * @throws IOException
	 * @throws ArrayIndexOutOfBoundsException
	 * 
	 */
	public SubDataIterator(IDataIterator<? extends T> dataIterator,
			int rowStart, int rowEnd, boolean closeAble)
			throws ArrayIndexOutOfBoundsException, IOException, Exception {
		this.dataIterator = dataIterator;
		this.rowStart = rowStart;
		this.rowEnd = rowEnd;
		skipToRowStart();

		this.closeAble = closeAble;
	}

	private void skipToRowStart() throws ArrayIndexOutOfBoundsException,
			IOException, Exception {
		if (dataIterator instanceof IIndexedDataIterator) {
			((IIndexedDataIterator<? extends T>) dataIterator).skip(rowStart);
			current = rowStart;
		} else {
			int i = rowStart;
			while (i-- > 0 && dataIterator.hasNext()) {
				dataIterator.next();
			}
			current = rowStart;
		}
	}

	private int current;

	@Override
	public boolean hasNext() {
		return current < rowEnd;
	}

	@Override
	public T next() {
		if (current < rowEnd) {
			current++;
			return dataIterator.next();
		} else {
			return null;
		}

	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void reset() throws Exception {
		if (dataIterator instanceof IIndexedDataIterator) {
			skipToRowStart();
		} else {
			throw new UnsupportedOperationException();
		}
	}

	@Override
	public MetaData getMetaData() {
		return dataIterator.getMetaData();
	}

	@Override
	public void close() throws Exception {
		if (closeAble) {
			dataIterator.close();
		}
	}

	@Override
	public boolean isClosed() {
		return dataIterator == null ? true : dataIterator.isClosed();
	}

}
