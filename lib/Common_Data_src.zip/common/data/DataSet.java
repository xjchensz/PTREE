/**
 * Created by Xiaojun Chen at 2012-6-19
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data;

import java.util.Iterator;

import common.data.instance.IInstance;
import common.data.meta.MetaData;
import common.utils.IReuseableIterator;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class DataSet<T extends IInstance> implements IDataIterator<T> {

	private IDataIterator<T> current;
	private Iterator<IDataIterator<T>> itr;

	/**
	 * 
	 */
	public DataSet(Iterator<IDataIterator<T>> itr) {
		this.itr = itr;
	}

	@Override
	public void close() throws Exception {
		if (itr != null) {
			while (itr.hasNext()) {
				itr.next().close();
			}
			itr = null;
		}
	}

	@Override
	public boolean isClosed() {
		return itr == null;
	}

	@Override
	public boolean hasNext() {
		fetch();
		return current != null && current.hasNext();
	}

	@Override
	public T next() {
		fetch();
		if (current != null) {
			return current.next();
		}
		return null;
	}

	private void fetch() {
		if (current == null && itr != null) {
			current = itr.next();
		}
	}

	@Override
	public void remove() {
		fetch();
		if (current != null) {
			current.remove();
		}
	}

	@Override
	public void reset() throws Exception {
		if (itr instanceof IReuseableIterator) {
			((IReuseableIterator) itr).reset();
		} else {
			throw new UnsupportedOperationException();
		}
	}

	@Override
	public MetaData getMetaData() {
		fetch();
		if (current != null) {
			return current.getMetaData();
		} else {
			return null;
		}
	}

}
