/**
 * Created by Xiaojun Chen at 2012-3-25
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data;

import java.io.IOException;

import common.data.instance.IInstance;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public interface IIndexedDataIterator<T extends IInstance> extends
		IDataIterator<T> {

	/**
	 * returns the total number of read instances
	 * */
	public int numRead();

	/**
	 * returns the number of the total instances
	 * */
	public int numInstances();

	/**
	 * skip to the given index of instance, start from 0
	 * 
	 * @param newPosition
	 *            the given index of the next instance
	 * @throws ArrayIndexOutOfBoundsException
	 * @throws IOException
	 * @throws Exception
	 * */
	public void skipTo(int newPosition) throws ArrayIndexOutOfBoundsException,
			IOException, Exception;

	/**
	 * skip the given number of instances
	 * 
	 * @param newPosition
	 *            the given number of the next instance to skip
	 * @throws IOException
	 * @throws Exception
	 * */
	public void skip(int numToSkip) throws ArrayIndexOutOfBoundsException,
			IOException, Exception;

	public T get(int index) throws ArrayIndexOutOfBoundsException, IOException,
			Exception;
}
