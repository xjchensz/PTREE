package common.data;

import java.util.Iterator;

import common.data.instance.IInstance;
import common.data.meta.MetaData;

public class MemoryDataIterator implements IDataIterator {
	private Data m_Data;
	private Iterator<IInstance> instances;

	private final MetaData metaData;

	public MemoryDataIterator(Data data) {
		m_Data = data;
		this.metaData = data.getMetaData();
		this.instances = data.getInstances().iterator();
	}

	public MetaData getMetaData() {
		return metaData;
	}

	@Override
	public boolean hasNext() {
		return instances.hasNext();
	}

	@Override
	public IInstance next() {
		return instances.next();
	}

	@Override
	public void remove() {
		instances.remove();
	}

	@Override
	public int hashCode() {
		return instances.hashCode() + metaData.hashCode();
	}

	@Override
	public void close() {
		instances = null;
	}

	@Override
	public boolean isClosed() {
		return instances != null;
	}

	@Override
	public void reset() {
		instances = m_Data.getInstances().iterator();
	}

}
