package common.data.meta;

import common.data.IDataIterator;
import common.data.instance.ISparseInstance;

public class SparseDegreeComputer extends NominalAttribute {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6395614202529420664L;

	public static double sparseDegree(
			IDataIterator<? extends ISparseInstance> dataItr) {
		int numInstances = 0;
		int numAttributes = dataItr.getMetaData().numAllAttributes();
		long numData = 0;
		while (dataItr.hasNext()) {
			numData += dataItr.next().size();
			numInstances++;
		}
		return (double) numData / (numInstances * numAttributes);
	}
}
