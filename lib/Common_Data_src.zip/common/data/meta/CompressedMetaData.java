/**
 * 
 */
package common.data.meta;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.dom4j.Element;

import common.EqualsUtils;
import common.MDAException;
import common.utils.StringUtils;
import common.utils.math.Varint;

/**
 * @author Xiaojun Chen
 * 
 */
public class CompressedMetaData extends MetaData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1279532241453845541L;

	public static final String TYPES = "types";
	public static final String DIRECTIONS = "directions";
	public static final String LABELS = "labels";

	private int m_NumAttributes;
	private AttributeType[] m_Types;
	private Direction[] m_Directions;
	private String[] m_Labels;

	/**
	 * 
	 */
	protected CompressedMetaData() {
	}

	/**
	 * @param id
	 * @param name
	 * @param attributes
	 */
	public CompressedMetaData(String id, String name, int numAttributes,
			AttributeType[] type, Direction[] directions) {
		super(id, name, null);
		m_NumAttributes = numAttributes;
		m_Types = type;
		m_Directions = directions;
	}

	/**
	 * @param id
	 * @param name
	 * @param attributes
	 * @param targetAttribute
	 * @param numInstances
	 * @param numElements
	 */
	public CompressedMetaData(String id, String name, int numAttributes,
			AttributeType[] types, Direction[] directions, int targetAttribute,
			int numInstances) {
		super(id, name, null, targetAttribute, numInstances);
		m_NumAttributes = numAttributes;
		m_Types = types;
		m_Directions = directions;
	}

	/**
	 * @param id
	 * @param name
	 * @param attributes
	 * @param targetAttribute
	 * @param numInstances
	 * @param numElements
	 * @param dataType
	 */
	public CompressedMetaData(String id, String name, int numAttributes,
			AttributeType[] types, Direction[] directions, int targetAttribute,
			int numInstances, DataType dataType) {
		super(id, name, null, targetAttribute, numInstances, dataType);
		m_NumAttributes = numAttributes;
		m_Types = types;
		m_Directions = directions;
	}

	/**
	 * @param parser
	 * @throws JsonParseException
	 * @throws NumberFormatException
	 * @throws IOException
	 * @throws MDAException
	 */
	public CompressedMetaData(JsonParser parser) throws JsonParseException,
			NumberFormatException, IOException, MDAException {
		super(parser);
	}

	/**
	 * @param metaData
	 */
	public CompressedMetaData(MetaData metaData) {
		super(metaData);
	}

	protected void copyAttributes(MetaData metaData) {
		if (metaData instanceof CompressedMetaData) {
			CompressedMetaData cmd = (CompressedMetaData) metaData;
			m_NumAttributes = cmd.m_NumAttributes;
			m_Types = new AttributeType[m_NumAttributes];
			m_Directions = new Direction[m_NumAttributes];
			System.arraycopy(cmd.m_Types, 0, m_Types, 0, m_NumAttributes);
			System.arraycopy(cmd.m_Directions, 0, m_Directions, 0,
					m_NumAttributes);
			m_Labels = cmd.m_Labels == null ? null
					: new String[cmd.m_Labels.length];
			if (m_Labels != null) {
				System.arraycopy(cmd.m_Labels, 0, m_Labels, 0, m_Labels.length);
			}
		} else {
			if (metaData.attributes == null) {
				m_NumAttributes = 0;
			} else {
				m_NumAttributes = metaData.attributes.length;
				m_Types = new AttributeType[m_NumAttributes];
				m_Directions = new Direction[m_NumAttributes];
				for (int i = 0; i < m_NumAttributes; i++) {
					m_Types[i] = metaData.attributes[i].getType();
					m_Directions[i] = metaData.attributes[i].getDirection();
				}
				m_Labels = metaData.getLabels();
			}
		}
	}

	/**
	 * @param root
	 * @throws Exception
	 */
	public CompressedMetaData(Element root) throws Exception {
		super(root);
	}

	protected void parseObjectMore(String fieldName, JsonParser parser)
			throws JsonParseException, IOException {
		if (fieldName.equals(MetaData.DATATYPE)) {
			m_DataType = DataType.valueOf(parser.nextTextValue());
		} else if (fieldName.equals(MetaData.NINSTANCES)) {
			m_NumInstances = Integer.parseInt(parser.nextTextValue());
		} else if (fieldName.equals(MetaData.NATTRIBUTES)) {
			m_NumAttributes = Integer.parseInt(parser.nextTextValue());
			m_Types = new AttributeType[m_NumAttributes];
			m_Directions = new Direction[m_NumAttributes];
		} else if (fieldName.equals(MetaData.TARGET)) {
			labelId = Integer.parseInt(parser.nextTextValue());
		} else if (TYPES.equals(fieldName)) {
			int[] types = StringUtils.decodeIntArray(parser.nextTextValue(),
					m_NumAttributes);
			for (int i = 0; i < types.length; i++) {
				m_Types[i] = AttributeType.values()[types[i]];
			}
		} else if (DIRECTIONS.equals(fieldName)) {
			int[] directions = StringUtils.decodeIntArray(
					parser.nextTextValue(), m_NumAttributes);
			for (int i = 0; i < directions.length; i++) {
				m_Directions[i] = Direction.values()[directions[i]];
			}
		} else if (LABELS.equals(fieldName)) {
			m_Labels = StringUtils.parseStringArray(parser.nextTextValue());
		}
	}

	@Override
	protected void parseMore(JsonParser parser) throws JsonParseException,
			IOException, MDAException {
		// do nothing
	}

	/**
	 * Parse the XML file
	 * 
	 * @param root
	 * @throws IOException
	 */
	protected void innerParse(Element root) throws IOException {
		super.innerParse(root);
		m_NumAttributes = Integer.parseInt(root.attributeValue(NATTRIBUTES));
		/** Parse types */
		Element element = root.element(TYPES);
		if (element != null) {
			int[] types = StringUtils.decodeIntArray(element.getText(),
					m_NumAttributes);
			m_Types = new AttributeType[types.length];
			for (int i = 0; i < m_Types.length; i++) {
				m_Types[i] = AttributeType.values()[types[i]];
			}
			types = null;
		}
		// parse directions
		element = root.element(DIRECTIONS);
		if (element != null) {
			int[] directions = StringUtils.decodeIntArray(element.getText(),
					m_NumAttributes);
			m_Directions = new Direction[directions.length];
			for (int i = 0; i < m_Types.length; i++) {
				m_Directions[i] = Direction.values()[directions[i]];
			}
			directions = null;
		}
		// parse labels
		element = root.element(LABELS);
		if (element != null) {
			m_Labels = StringUtils.parseStringArray(element.getText());
		}
	}

	/**
	 * update the parameters, called after modified attributes
	 */
	public void update() {
		m_NumAttributes = m_Types != null ? m_Types.length : 0;
		if (m_Directions != null) {
			/** Count ignored attributes */
			int ignoredId = 0;
			for (int i = 0; i < m_Directions.length; i++) {
				if (m_Directions[i] == Direction.none) {
					ignoredId++;
				}
			}
			ignored = new int[ignoredId];
			ignoredId = 0;
			for (int i = 0; i < m_Directions.length; i++) {
				if (m_Directions[i] == Direction.none) {
					ignored[ignoredId++] = i;
				}
			}
		} else {
			ignored = new int[0];
		}
	}

	/**
	 * the number of attributes without label and ignored
	 */
	public int numUsedAttributes() {
		if (labelId >= 0) {
			return numAllAttributes() - numIgnored() - 1;
		} else {
			return numAllAttributes() - numIgnored();
		}

	}

	/**
	 * the number of numeric attributes
	 */
	public int numNumericArrribute() {
		int sum = 0;
		for (int i = 0; i < m_Types.length; i++) {
			if (m_Types[i] == AttributeType.NUMERIC) {
				sum++;
			}
		}
		return sum;
	}

	/**
	 * the number of numeric attributes
	 */
	public int numCategoryAttribute() {
		int sum = 0;
		for (int i = 0; i < m_Types.length; i++) {
			if (m_Types[i] == AttributeType.NOMINAL) {
				sum++;
			}
		}
		return sum;
	}

	/**
	 * the number of attributes including label and ignored
	 */
	public int numAllAttributes() {
		return m_NumAttributes;
	}

	public IAttribute[] getAttributes() {
		return attributes;
	}

	/**
	 * Get the attribute via name
	 */
	public IAttribute getAttribute(String name) {
		return null;
	}

	protected static IAttribute getAttribute(AttributeType type, String id,
			String name, Direction direction) {
		switch (type) {
		case BOOLEAN:
			return new BooleanAttribute(id, name, direction);
		case COUNT:
			return new CountAttribute(id, name, direction);
		case NOMINAL:
			return new NominalAttribute(id, name, direction);
		case ORDINAL:
			return new OrdinalAttribute(id, name, direction);
		case NUMERIC:
		default:
			return new NumericAttribute(id, name, direction);
		}
	}

	/**
	 * Get the attribute via index
	 * 
	 * @param index
	 * @return
	 */
	public IAttribute getAttributeAt(int index) {
		if (attributes == null) {
			return null;
		}
		if (attributes.length <= index || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		return getAttribute(
				m_Types[index],
				index + "",
				+index + "",
				labelId == index ? Direction.output : (ignored != null
						&& Arrays.binarySearch(ignored, 0, ignored.length,
								index) >= 0 ? Direction.none : Direction.input));
	}

	public void setAttributeAt(int index, IAttribute attr) {
		if (m_Types == null) {
			return;
		}
		if (m_Types.length <= index || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		m_Types[index] = attr.getType();
		m_Directions[index] = attr.getDirection();
	}

	public void setAttributeAt(int index, AttributeType type,
			Direction direction) {
		if (m_Types == null) {
			return;
		}
		if (m_Types.length <= index || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		m_Types[index] = type;
		m_Directions[index] = direction;
	}

	public AttributeType getAttributeTypeAt(int index) {
		if (m_NumAttributes <= index || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		return m_Types[index];
	}

	public Direction getDirectionAt(int index) {
		if (m_NumAttributes <= index || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		return m_Directions[index];
	}

	/**
	 * Whether the attribute is numerical
	 * 
	 * @param attr
	 * @return
	 */
	public boolean isNumerical(int attr) {
		return m_Types[attr] == AttributeType.NUMERIC;
	}

	public boolean isCategorical(int attr) {
		return m_Types[attr] == AttributeType.NOMINAL
				|| m_Types[attr] == AttributeType.ORDINAL;
	}

	public void setLabels(String[] labels) {
		this.m_Labels = labels;
	}

	/**
	 * Get the number of labels
	 */
	public int numLabels() {
		if (labelId < 0 || m_Labels == null)
			return -1;
		return m_Labels.length;
	}

	/**
	 * Get the name of label via label code
	 */
	public String getLabel(int code) {
		if (labelId < 0 || m_Labels == null)
			return null;
		return m_Labels[code];
	}

	/**
	 * Get the code of label via label name
	 */
	public int getLabelCode(String label) {
		if (labelId < 0 || m_Labels == null)
			return -1;
		return Arrays.binarySearch(m_Labels, 0, m_Labels.length, label);
	}

	/**
	 * Get the labels
	 */
	public String[] getLabels() {
		if (labelId < 0 || m_Labels == null)
			return null;
		return Arrays.copyOf(m_Labels, m_Labels.length);
	}

	@Override
	public boolean equals(Object obj) {
		if (!equalsIgnoreInstances(obj)) {
			return false;
		}
		return m_NumInstances == ((CompressedMetaData) obj).m_NumInstances;
	}

	protected boolean equalsAttributes(MetaData metaData) {
		if (metaData instanceof CompressedMetaData) {

			CompressedMetaData cmd = (CompressedMetaData) metaData;

			return m_NumAttributes == cmd.m_NumAttributes
					&& EqualsUtils.equals(m_Types, cmd.m_Types)
					&& EqualsUtils.equals(m_Directions, cmd.m_Directions)
					&& EqualsUtils.equals(m_Labels, cmd.m_Labels);

		}
		return false;
	}

	/**
	 * 
	 * @return <code>true</code> if the given metadata contains the same set of
	 *         attributes with this attribute, otherwise <code>false</code>
	 * */
	public boolean match(MetaData metaData) {
		if (!(metaData instanceof CompressedMetaData)) {
			return false;
		}

		CompressedMetaData cmd = (CompressedMetaData) metaData;
		return m_NumAttributes == cmd.m_NumAttributes
				&& EqualsUtils.equals(m_Types, cmd.m_Types)
				&& EqualsUtils.equals(m_Directions, cmd.m_Directions)
				&& EqualsUtils.equals(m_Labels, cmd.m_Labels);
	}

	public CompressedMetaData clone() {
		return new CompressedMetaData(this);
	}

	public void write(DataOutput out) throws IOException {
		super.write(out);
		Varint.writeUnsignedVarInt(m_NumAttributes, out);
		// types
		int[] types = new int[m_Types.length];
		for (int i = 0; i < types.length; i++) {
			types[i] = m_Types[i].ordinal();
		}
		out.writeUTF(StringUtils.compressIntArray(types,
				AttributeType.values().length));
		// directions
		int[] directions = new int[m_Directions.length];
		for (int i = 0; i < directions.length; i++) {
			directions[i] = m_Directions[i].ordinal();
		}
		out.writeUTF(StringUtils.compressIntArray(directions,
				Direction.values().length));
		// labels
		if (m_Labels != null) {
			Varint.writeUnsignedVarInt(m_Labels.length, out);
			for (int i = 0; i < m_Labels.length; i++) {
				out.writeUTF(m_Labels[i]);
			}
		} else {
			Varint.writeUnsignedVarInt(0, out);
		}
	}

	protected void readMore(DataInput in) throws IOException {
		super.readMore(in);
		m_NumAttributes = Varint.readUnsignedVarInt(in);
		m_Types = new AttributeType[m_NumAttributes];
		m_Directions = new Direction[m_NumAttributes];
		// types
		int[] types = StringUtils.decodeIntArray(in.readUTF(), m_NumAttributes);
		for (int i = 0; i < m_NumAttributes; i++) {
			m_Types[i] = AttributeType.values()[types[i]];
		}
		types = null;
		// directions
		int[] directions = StringUtils.decodeIntArray(in.readUTF(),
				m_NumAttributes);
		for (int i = 0; i < m_NumAttributes; i++) {
			m_Directions[i] = Direction.values()[directions[i]];
		}
		int numLabels = Varint.readUnsignedVarInt(in);
		m_Labels = new String[numLabels];
		for (int i = 0; i < numLabels; i++) {
			m_Labels[i] = in.readUTF();
		}
	}

	@Override
	protected void innerToXML(Element root) {
		super.innerToXML(root);
		root.addAttribute(NATTRIBUTES, String.valueOf(numAllAttributes()));
		if (m_Types != null) {
			Element typeElement = root.addElement(TYPES);
			int[] types = new int[m_Types.length];
			for (int i = 0; i < types.length; i++) {
				types[i] = m_Types[i].ordinal();
			}
			typeElement.setText(StringUtils.compressIntArray(types,
					AttributeType.values().length));
		}

		if (m_Directions != null) {
			Element typeElement = root.addElement(DIRECTIONS);
			int[] directions = new int[m_Directions.length];
			for (int i = 0; i < directions.length; i++) {
				directions[i] = m_Directions[i].ordinal();
			}
			typeElement.setText(StringUtils.compressIntArray(directions,
					Direction.values().length));

		}
		if (m_Labels != null) {
			Element typeElement = root.addElement(LABELS);
			typeElement.setText(StringUtils.combine(m_Labels));
		}
	}

	@Override
	protected void innerWriteJSONObject(JsonGenerator generator)
			throws JsonGenerationException, IOException {
		super.innerWriteJSONObject(generator);
		// types
		int[] types = new int[m_Types.length];
		for (int i = 0; i < types.length; i++) {
			types[i] = m_Types[i].ordinal();
		}
		generator.writeStringField(TYPES, StringUtils.compressIntArray(types,
				AttributeType.values().length));
		// directions
		int[] directions = new int[m_Directions.length];
		for (int i = 0; i < directions.length; i++) {
			directions[i] = m_Directions[i].ordinal();
		}
		generator.writeStringField(DIRECTIONS, StringUtils.compressIntArray(
				directions, AttributeType.values().length));
		// labels
		generator.writeStringField(LABELS, StringUtils.combine(m_Labels));
	}

	@Override
	protected void innerWriteJSONMore(JsonGenerator generator)
			throws JsonGenerationException, IOException {
		// do nothing
	}

	public void close() {
		m_Types = null;
		m_Directions = null;
		m_Labels = null;
		super.close();
	}

	@Override
	public boolean isClosed() {
		return m_Types == null;
	}

	/**
	 * Destroy the metadata to release its memory
	 * */
	public void destroy() {
		m_Types = null;
		super.destroy();
	}
}
