package common.data.meta;

import java.io.BufferedInputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Vector;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonToken;
import org.dom4j.Attribute;
import org.dom4j.Element;
import org.slf4j.Logger;

import common.AbstractIDNameXMLJSONAble;
import common.EqualsUtils;
import common.IIDNameAble;
import common.IWritable;
import common.IXMLAble;
import common.MDAException;
import common.data.instance.IInstance;
import common.data.instance.numeric.DenseBooleanInstance;
import common.data.instance.numeric.DenseDoubleInstance;
import common.data.instance.numeric.DenseIntInstance;
import common.data.instance.numeric.sparse.SparseBooleanInstance;
import common.data.instance.numeric.sparse.SparseDoubleInstance;
import common.data.instance.numeric.sparse.SparseIntInstance;
import common.data.io.SerializedDataConstants;
import common.json.IJSONObject;
import common.json.JSONUtils;
import common.utils.ArrayUtils;
import common.utils.collection.ArrayMap;
import common.utils.collection.UnmodifiableArrayMap;
import common.utils.math.Varint;
import common.value.IValue;
import common.value.IValueListener;
import common.value.ValueStatus;

public class MetaData extends AbstractIDNameXMLJSONAble implements IXMLAble,
		IIDNameAble, IWritable, IJSONObject, IValue {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2261211468070339689L;

	public static final String ATTR_TYPE = "TP";

	public final static ArrayMap<AttributeType, Class<? extends IAttribute>> attributeMap;
	public final static AttributeType[] m_Types;
	public final static String[] m_TypeNames;

	static {
		ArrayMap<AttributeType, Class<? extends IAttribute>> map = new ArrayMap<AttributeType, Class<? extends IAttribute>>(
				4);
		map.put(AttributeType.NUMERIC, NumericAttribute.class);
		map.put(AttributeType.NOMINAL, NominalAttribute.class);
		map.put(AttributeType.ORDINAL, OrdinalAttribute.class);
		map.put(AttributeType.COUNT, CountAttribute.class);
		map.put(AttributeType.BOOLEAN, BooleanAttribute.class);
		attributeMap = new UnmodifiableArrayMap<AttributeType, Class<? extends IAttribute>>(
				map);
		m_Types = attributeMap.keySet().toArray(
				new AttributeType[attributeMap.size()]);
		m_TypeNames = new String[m_Types.length];
		for (int i = 0; i < m_Types.length; i++) {
			m_TypeNames[i] = m_Types[i].name();
		}
	}

	public AttributeType getAttributeType(Class<? extends IAttribute> classz) {
		return attributeMap.getKeyForValue(classz);
	}

	public Class<? extends IAttribute> getAttributeClass(AttributeType type) {
		return attributeMap.get(type);
	}

	public Class<? extends IAttribute> getAttributeClass(String type) {
		return attributeMap.get(AttributeType.valueOf(type));
	}

	public static AttributeType[] getAttributeTypes() {
		return m_Types;
	}

	public static String[] getAttributeTypeNames() {
		return m_TypeNames;
	}

	public static final String ELEMENT_METADATA = "MetaData";
	public static final String ATTRIBUTE = "ATTRIBUTE";
	public static final String TARGET = "TARGET";
	public static final String NINSTANCES = "NINSTANCES";
	public static final String DATATYPE = "DATATYPE";
	public static final String NATTRIBUTES = "NATTRIBUTES";
	public static final String PROPERTIES = "PROPERTIES";

	public static final char SEPARATOR_ID = '#';
	public static final char SEPARATOR_DATA = ',';
	public static final char SEPARATOR_DATA_INNER = ':';

	/** All attributes including label and ignored */
	protected IAttribute[] attributes;
	protected int[] ignored;
	protected int labelId;
	protected int m_NumInstances;
	protected DataType m_DataType;

	private ArrayMap<String, String> properties;

	protected MetaData() {
		super();
	}

	public MetaData(String id, String name, IAttribute[] attributes) {
		this(id, name, attributes, -1, -1);
	}

	public MetaData(String id, String name, IAttribute[] attributes,
			int targetAttribute, int numInstances) {
		this(id, name, attributes, targetAttribute, numInstances, DataType
				.defaultValue());

	}

	public MetaData(String id, String name, IAttribute[] attributes,
			int targetAttribute, int numInstances, DataType dataType) {
		super(id, name);
		this.attributes = attributes;
		this.m_NumInstances = numInstances;
		this.labelId = targetAttribute;
		this.m_DataType = dataType;

		/** init parameters */
		update();
	}

	public MetaData toCompressedMetaData() {
		return new CompressedMetaData(this);
	}

	public MetaData(JsonParser parser) throws JsonParseException,
			NumberFormatException, IOException, MDAException {
		super(parser);
		/** init parameters */
		update();
	}

	protected void parseObjectMore(String fieldName, JsonParser parser)
			throws JsonParseException, IOException {
		if (fieldName.equals(MetaData.DATATYPE)) {
			m_DataType = DataType.valueOf(parser.nextTextValue());
		} else if (fieldName.equals(MetaData.NINSTANCES)) {
			m_NumInstances = Integer.parseInt(parser.nextTextValue());
		} else if (fieldName.equals(MetaData.NATTRIBUTES)) {
			attributes = new IAttribute[Integer
					.parseInt(parser.nextTextValue())];
		} else if (fieldName.equals(MetaData.TARGET)) {
			labelId = Integer.parseInt(parser.nextTextValue());
		}
	}

	@Override
	protected void parseMore(JsonParser parser) throws JsonParseException,
			IOException, MDAException {
		JsonToken token;
		while ((token = parser.nextToken()) != null) {
			switch (token) {
			case START_OBJECT:
				// parse properties
				properties = new ArrayMap<String, String>();
				while ((token = parser.nextToken()) != JsonToken.END_OBJECT) {
					properties.put(parser.getCurrentName(),
							parser.nextTextValue());
				}
				break;
			case START_ARRAY:
				// parse attributes
				for (int i = 0; i < attributes.length; i++) {
					attributes[i] = parse(parser);
				}
				break;
			default:
				// do nothing
				break;
			}
		}
	}

	public MetaData(MetaData metaData) {
		super(metaData);
		m_DataType = metaData.m_DataType;
		m_NumInstances = metaData.m_NumInstances;
		labelId = metaData.labelId;
		copyAttributes(metaData);
		if (metaData.properties != null) {
			properties = metaData.properties.clone();
		}
		/** init parameters */
		update();
	}

	protected void copyAttributes(MetaData metaData) {
		if (metaData.attributes != null) {
			attributes = new IAttribute[metaData.attributes.length];
			for (int i = 0; i < attributes.length; i++) {
				attributes[i] = metaData.attributes[i].clone();
			}
		} else {
			attributes = null;
		}
	}

	protected IAttribute parse(JsonParser parser) throws IOException,
			MDAException {
		if (parser.nextToken() == JsonToken.START_OBJECT) {
			Class<? extends IAttribute> classz = null;
			do {
				if (ATTR_TYPE.equals(parser.getCurrentName())) {
					classz = getAttributeClass(parser.nextTextValue());
				}
			} while (parser.nextToken() != JsonToken.END_OBJECT);
			if (classz != null) {
				return JSONUtils.parse(parser, classz);
			}
		}
		return null;
	}

	public MetaData(Element root) throws Exception {
		super(root);
		/** init parameters */
		update();
	}

	/**
	 * Parse the XML file
	 * 
	 * @param root
	 * @throws IOException
	 */
	protected void innerParse(Element root) throws IOException {
		labelId = Integer.parseInt(root.attributeValue(TARGET));
		m_NumInstances = Integer.parseInt(root.attributeValue(NINSTANCES));

		/** Parse the datatype */
		m_DataType = DataType.valueOf(root.attributeValue(DATATYPE));

		/** Parse the attributes */
		Element element = root.element(ATTRIBUTE);
		if (element != null) {
			List<Element> elements = element.elements();
			attributes = new IAttribute[elements.size()];
			int i = 0;
			Iterator<Element> itr = elements.iterator();
			while (itr.hasNext()) {
				attributes[i++] = parseAttribute(itr.next());
			}
		}

		/** Parse the properties */
		element = root.element(PROPERTIES);
		if (element != null) {
			List<Attribute> attrs = element.attributes();
			if (attrs.size() > 0) {
				properties = new ArrayMap<String, String>(attrs.size());
				Iterator<Attribute> itr = attrs.iterator();
				Attribute attr;
				while (itr.hasNext()) {
					attr = itr.next();
					properties.put(attr.getName(), attr.getValue());
				}
				attrs.clear();
			} else {
				properties = null;
			}
		} else {
			properties = null;
		}
	}

	protected IAttribute parseAttribute(Element element) throws IOException {
		try {
			Class<? extends IAttribute> classz = getAttributeClass(element
					.attributeValue(ATTR_TYPE));
			Constructor<? extends IAttribute> constructor = classz
					.getConstructor(Element.class);
			return constructor.newInstance(element);
		} catch (InstantiationException e) {
			throw new IOException(e);
		} catch (IllegalAccessException e) {
			throw new IOException(e);
		} catch (IllegalArgumentException e) {
			throw new IOException(e);
		} catch (InvocationTargetException e) {
			throw new IOException(e);
		} catch (SecurityException e) {
			throw new IOException(e);
		} catch (NoSuchMethodException e) {
			throw new IOException(e);
		}
	}

	/**
	 * update the parameters, called after modified attributes
	 */
	public void update() {

		/** Count ignored attributes */
		int ignoredId = 0;
		for (int i = 0; i < attributes.length; i++) {
			if (attributes[i].isIgnored()) {
				ignoredId++;
			}
		}
		ignored = new int[ignoredId];
		ignoredId = 0;
		for (int i = 0; i < attributes.length; i++) {
			if (attributes[i].isIgnored()) {
				ignored[ignoredId++] = i;
			}
		}
		if (labelId >= 0 && labelId < attributes.length) {
			attributes[labelId].setDirection(Direction.output);
		}
	}

	/**
	 * the number of attributes without label and ignored
	 */
	public int numUsedAttributes() {
		if (labelId >= 0) {
			return numAllAttributes() - numIgnored() - 1;
		} else {
			return numAllAttributes() - numIgnored();
		}

	}

	/**
	 * the number of numeric attributes
	 */
	public int numNumericArrribute() {
		int sum = 0;
		for (int i = 0; i < attributes.length; i++) {
			if (attributes[i] instanceof NumericAttribute) {
				sum++;
			}
		}
		return sum;
	}

	/**
	 * the number of numeric attributes
	 */
	public int numCategoryAttribute() {
		int sum = 0;
		for (int i = 0; i < attributes.length; i++) {
			if (attributes[i] instanceof NominalAttribute) {
				sum++;
			}
		}
		return sum;
	}

	/**
	 * the number of attributes including label and ignored
	 */
	public int numAllAttributes() {
		if (attributes == null) {
			return 0;
		}
		return attributes.length;
	}

	public IAttribute[] getAttributes() {
		return attributes;
	}

	/**
	 * Get the attribute via name
	 */
	public IAttribute getAttribute(String name) {
		for (IAttribute att : attributes) {
			if (att.getName().equals(name)) {
				return att;
			}
		}
		return null;
	}

	/**
	 * Get the attribute via index
	 * 
	 * @param index
	 * @return
	 */
	public IAttribute getAttributeAt(int index) {
		if (attributes == null) {
			return null;
		}
		if (attributes.length <= index || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		return attributes[index];
	}

	public void setAttributeAt(int index, IAttribute attr) {
		if (attributes == null) {
			return;
		}
		if (attributes.length <= index || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		attributes[index] = attr;
	}

	public AttributeType getAttributeTypeAt(int index) {
		if (attributes == null) {
			return null;
		}
		if (attributes.length <= index || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		return attributes[index].getType();
	}

	public Direction getDirectionAt(int index) {
		if (attributes == null) {
			return null;
		}
		if (attributes.length <= index || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		return attributes[index].getDirection();
	}

	/**
	 * 
	 * @return the number of ignored attributes
	 */
	public int numIgnored() {
		return ignored.length;
	}

	public int[] getIgnored() {
		return ignored;
	}

	public boolean isIgnored(int index) {
		if (attributes == null) {
			return true;
		}
		if (attributes.length <= index || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		return attributes[index].getDirection() == Direction.none;
	}

	public void setNumInstances(int numInstances) {
		m_NumInstances = numInstances;
	}

	/**
	 * Get the number of instances
	 */
	public int numInstances() {
		return m_NumInstances;
	}

	public boolean isLabelNumerical() {
		if (labelId < 0)
			return false;
		return isNumerical(labelId);
	}

	/**
	 * Whether the attribute is numerical
	 * 
	 * @param attr
	 * @return
	 */
	public boolean isNumerical(int attr) {
		return attributes[attr] instanceof NumericAttribute;
	}

	public boolean isCategorical(int attr) {
		return attributes[attr] instanceof NominalAttribute;
	}

	public void setDataType(DataType type) {
		this.m_DataType = type;
	}

	public DataType dataType() {
		return m_DataType;
	}

	public boolean isSparse() {
		switch (m_DataType) {
		case SPARSE_DOUBLE:
		case SPARSE_INT:
		case SPARSE_BOOLEAN:
			return true;
		case DENSE_DOUBLE:
		case DENSE_INT:
		case DENSE_BOOLEAN:
		default:
			return false;
		}
	}

	/**
	 * Get the number of labels
	 */
	public int numLabels() {
		if (labelId < 0)
			return -1;
		return ((NominalAttribute) attributes[labelId]).numValues();
	}

	public boolean hasLabels() {
		return labelId >= 0 && labelId < attributes.length;
	}

	/**
	 * Get the index of label
	 */
	public int getLabelId() {
		return labelId;
	}

	/**
	 * Get the name of label via label code
	 */
	public String getLabel(int code) {
		if (labelId < 0)
			return null;
		return ((NominalAttribute) attributes[labelId]).decode(code);
	}

	/**
	 * Get the code of label via label name
	 */
	public int getLabelCode(String label) {
		if (labelId < 0)
			return -1;
		return ((NominalAttribute) attributes[labelId]).encode(label, false);
	}

	/**
	 * Get the labels
	 */
	public String[] getLabels() {
		if (labelId < 0)
			return null;
		String[] labels = ((NominalAttribute) attributes[labelId])
				.getCategoryValues();
		return Arrays.copyOf(labels, labels.length);
	}

	/**
	 * Converts a token to its corresponding int code for a given attribute
	 * 
	 * @param attr
	 *            attribute's index
	 */
	public int valueOf(int attr, String token) {
		if (!isCategorical(attr)) {
			throw new IllegalArgumentException(
					"Only for CATEGORICAL attributes");
		}
		String[] values = getLabels();
		if (values == null) {
			throw new IllegalStateException("Values not found");
		}

		return ArrayUtils.indexOf(values, token);
	}

	public void setProperty(String key, String value) {
		if (key != null && value != null) {
			if (properties == null) {
				properties = new ArrayMap<String, String>(2);
			}
			properties.put(key, value);
		}
	}

	public String getProperty(String key) {
		if (properties != null) {
			return properties.get(key);
		}
		return null;
	}

	public void clearProperties() {
		if (properties != null) {
			properties.clear();
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		}
		if (!equalsIgnoreInstances(obj)) {
			return false;
		}
		return m_NumInstances == ((MetaData) obj).m_NumInstances;
	}

	public boolean equalsIgnoreInstances(Object obj) {
		if (obj == this) {
			return true;
		}

		if (obj instanceof MetaData) {
			if (!super.equals(obj)) {
				return false;
			}
			MetaData metaData = (MetaData) obj;
			if (m_DataType != metaData.m_DataType) {
				return false;
			}
			if (labelId != metaData.labelId) {
				return false;
			}

			if (numAllAttributes() != metaData.numAllAttributes()) {
				return false;
			} else if (numAllAttributes() == 0
					&& metaData.numAllAttributes() == 0) {
				return true;
			}

			// properties
			if (!EqualsUtils.equals(metaData.properties, properties)) {
				return false;
			}

			return equalsAttributes(metaData);
		}
		return false;
	}

	protected boolean equalsAttributes(MetaData metaData) {
		if (attributes != null) {
			ArrayList<IAttribute> attrs1 = new ArrayList<IAttribute>();
			for (IAttribute att : attributes) {
				attrs1.add(att);
			}

			ArrayList<IAttribute> attrs2 = new ArrayList<IAttribute>();
			for (IAttribute att : metaData.attributes) {
				attrs2.add(att);
			}

			Iterator<IAttribute> itr1 = attrs1.iterator();
			boolean match = false;
			while (itr1.hasNext()) {
				IAttribute att = itr1.next();
				attrs1.iterator();
				match = false;
				Iterator<IAttribute> itr2 = attrs2.iterator();
				while (itr2.hasNext()) {
					if (att.equals(itr2.next())) {
						match = true;
						itr2.remove();
						break;
					}
				}
				if (!match) {
					return false;
				}
			}

			return true;
		} else {
			return metaData.attributes == null ? true : false;
		}
	}

	/**
	 * 
	 * @return <code>true</code> if the given metadata contains the same set of
	 *         attributes with this attribute, otherwise <code>false</code>
	 * */
	public boolean match(MetaData metaData) {

		if (numAllAttributes() != metaData.numAllAttributes()) {
			return false;
		} else if (numAllAttributes() == 0 && metaData.numAllAttributes() == 0) {
			return true;
		}

		ArrayList<IAttribute> attrs1 = new ArrayList<IAttribute>();
		for (IAttribute att : attributes) {
			attrs1.add(att);
		}

		ArrayList<IAttribute> attrs2 = new ArrayList<IAttribute>();
		for (IAttribute att : metaData.attributes) {
			attrs2.add(att);
		}

		Iterator<IAttribute> itr1 = attrs1.iterator();
		boolean match = false;
		while (itr1.hasNext()) {
			IAttribute att = itr1.next();
			attrs1.iterator();
			match = false;
			Iterator<IAttribute> itr2 = attrs2.iterator();
			while (itr2.hasNext()) {
				if (att.match(itr2.next())) {
					match = true;
					itr2.remove();
					break;
				}
			}
			if (!match) {
				return false;
			}
		}

		return true;
	}

	public MetaData clone() {
		return new MetaData(this);
	}

	public void write(DataOutput out) throws IOException {
		out.writeUTF(this.getClass().getName());
		super.write(out);
		out.writeByte(m_DataType.ordinal());
		Varint.writeUnsignedVarInt(attributes != null ? attributes.length : 0,
				out);
		if (attributes != null) {
			String attName;
			for (IAttribute attr : attributes) {
				attName = getAttributeType(attr.getClass()).name();
				out.writeByte(attName.length());
				out.writeChars(attName);
				attr.write(out);
			}
		}
		Varint.writeUnsignedVarInt(properties != null ? properties.size() : 0,
				out);
		if (properties != null) {
			Iterator<Entry<String, String>> itr = properties.entrySet()
					.iterator();
			Entry<String, String> entry;
			while (itr.hasNext()) {
				entry = itr.next();
				out.writeUTF(entry.getKey());
				out.writeUTF(entry.getValue());
			}
		}
		Varint.writeSignedVarInt(labelId, out);
		Varint.writeUnsignedVarInt(m_NumInstances, out);
	}

	protected void readMore(DataInput in) throws IOException {
		m_DataType = DataType.values()[in.readByte()];
		readAttributes(in);
		int nbProperties = Varint.readUnsignedVarInt(in);
		if (nbProperties == 0) {
			properties = null;
		} else {
			properties = new ArrayMap<String, String>(nbProperties);
			for (int i = 0; i < nbProperties; i++) {
				properties.put(in.readUTF(), in.readUTF());
			}
		}
		labelId = Varint.readSignedVarInt(in);
		m_NumInstances = Varint.readUnsignedVarInt(in);
	}

	protected void readAttributes(DataInput in) throws IOException {
		int nbAttributes = Varint.readUnsignedVarInt(in);
		if (nbAttributes == 0) {
			attributes = null;
		} else {
			attributes = new IAttribute[nbAttributes];
			for (int attr = 0; attr < nbAttributes; attr++) {
				attributes[attr] = readAttribute(in);
			}
		}
	}

	protected IAttribute readAttribute(DataInput in) throws IOException {
		char[] name = new char[in.readByte()];
		for (int i = 0; i < name.length; i++) {
			name[i] = in.readChar();
		}

		IAttribute attr;
		try {
			attr = getAttributeClass(new String(name)).newInstance();
		} catch (InstantiationException e) {
			throw new IOException(e);
		} catch (IllegalAccessException e) {
			throw new IOException(e);
		}
		attr.readFields(in);
		return attr;
	}

	public static MetaData readMetaData(DataInput in) throws IOException {
		String className = in.readUTF();
		MetaData metaData;
		try {
			metaData = (MetaData) Class.forName(className).newInstance();
		} catch (InstantiationException | IllegalAccessException
				| ClassNotFoundException e) {
			throw new IOException(e);
		}
		metaData.readFields(in);
		metaData.update();
		return metaData;
	}

	public static MetaData readMetaData(File file) throws IOException {
		if (file.isDirectory()) {
			file = SerializedDataConstants.metaDataFile(file);
		}
		DataInputStream bis = new DataInputStream(new BufferedInputStream(
				new FileInputStream(file)));
		try {
			return readMetaData(bis);
		} finally {
			bis.close();
		}
	}

	public IInstance readInstance(DataInput in, IInstance ins)
			throws IOException {

		switch (m_DataType) {
		case SPARSE_DOUBLE:
			ins = SparseDoubleInstance.read(in, this,
					(SparseDoubleInstance) ins);
			break;
		case SPARSE_INT:
			ins = SparseIntInstance.read(in, this, (SparseIntInstance) ins);
			break;
		case SPARSE_BOOLEAN:
			ins = SparseBooleanInstance.read(in, this,
					(SparseBooleanInstance) ins);
			break;
		case DENSE_DOUBLE:
			ins = DenseDoubleInstance.read(in, this, (DenseDoubleInstance) ins);
			break;
		case DENSE_INT:
			ins = DenseIntInstance.read(in, this, (DenseIntInstance) ins);
			break;
		case DENSE_BOOLEAN:
			ins = DenseBooleanInstance.read(in, this,
					(DenseBooleanInstance) ins);
			break;
		default:
			ins = null;
		}
		return ins;
	}

	public IInstance parseText(int id, String[] text, IInstance ins) {
		if (text == null) {
			return null;
		}
		switch (m_DataType) {
		case SPARSE_DOUBLE:
			ins = SparseDoubleInstance.parseText(this, id, text,
					(SparseDoubleInstance) ins);
			break;
		case SPARSE_INT:
			ins = SparseIntInstance.parseText(this, id, text,
					(SparseIntInstance) ins);
			break;
		case SPARSE_BOOLEAN:
			ins = SparseBooleanInstance.parseText(this, id, text,
					(SparseBooleanInstance) ins);
			break;
		case DENSE_DOUBLE:
			ins = DenseDoubleInstance.parseText(this, id, text,
					(DenseDoubleInstance) ins);
			break;
		case DENSE_INT:
			ins = DenseIntInstance.parseText(this, id, text,
					(DenseIntInstance) ins);
			break;
		case DENSE_BOOLEAN:
			ins = DenseBooleanInstance.parseText(this, id, text,
					(DenseBooleanInstance) ins);
			break;
		default:
			ins = null;
		}

		return ins;
	}

	public IInstance emptyInstance() {
		IInstance ins;

		switch (m_DataType) {
		case SPARSE_DOUBLE:
			ins = SparseDoubleInstance.emptyInstance(this);
			break;
		case SPARSE_INT:
			ins = SparseIntInstance.emptyInstance(this);
			break;
		case SPARSE_BOOLEAN:
			ins = SparseBooleanInstance.emptyInstance(this);
			break;
		case DENSE_DOUBLE:
			ins = DenseDoubleInstance.emptyInstance(this);
			break;
		case DENSE_INT:
			ins = DenseIntInstance.emptyInstance(this);
			break;
		case DENSE_BOOLEAN:
			ins = DenseBooleanInstance.emptyInstance(this);
			break;
		default:
			ins = null;
		}

		return ins;
	}

	public Class<? extends IInstance> getInstanceClass() {

		switch (m_DataType) {
		case SPARSE_DOUBLE:
			return SparseDoubleInstance.class;
		case SPARSE_INT:
			return SparseIntInstance.class;
		case SPARSE_BOOLEAN:
			return SparseBooleanInstance.class;
		case DENSE_DOUBLE:
			return DenseDoubleInstance.class;
		case DENSE_INT:
			return DenseIntInstance.class;
		case DENSE_BOOLEAN:
			return DenseBooleanInstance.class;
		default:
			return null;
		}
	}

	@Override
	protected void innerToXML(Element root) {
		root.addAttribute(MetaData.TARGET, String.valueOf(labelId));
		root.addAttribute(MetaData.NINSTANCES, String.valueOf(m_NumInstances));
		root.addAttribute(MetaData.DATATYPE, m_DataType.name());

		if (attributes != null && attributes.length > 0) {
			Element attrElement = root.addElement(ATTRIBUTE);
			Element element;
			for (IAttribute att : attributes) {
				element = attrElement.addElement(att.getXMLElementName());
				element.addAttribute(ATTR_TYPE,
						getAttributeType(att.getClass()).name());
				att.toXML(element);
			}
		}
		if (properties != null && properties.size() > 0) {
			Element propElement = root.addElement(PROPERTIES);
			Iterator<Entry<String, String>> itr = properties.entrySet()
					.iterator();
			Entry<String, String> entry;
			while (itr.hasNext()) {
				entry = itr.next();
				propElement.addAttribute(entry.getKey(), entry.getValue());
			}
		}
	}

	@Override
	public String getXMLElementName() {
		return ELEMENT_METADATA;
	}

	@Override
	protected void innerWriteJSONObject(JsonGenerator generator)
			throws JsonGenerationException, IOException {
		generator.writeStringField(DATATYPE, m_DataType.name());
		generator.writeStringField(NINSTANCES, String.valueOf(m_NumInstances));
		generator.writeStringField(NATTRIBUTES,
				String.valueOf(numAllAttributes()));
		generator.writeStringField(TARGET, String.valueOf(labelId));
	}

	@Override
	protected void innerWriteJSONMore(JsonGenerator generator)
			throws JsonGenerationException, IOException {
		if (properties != null && properties.size() > 0) {
			generator.writeStartObject();
			Iterator<Entry<String, String>> itr = properties.entrySet()
					.iterator();
			Entry<String, String> entry;
			while (itr.hasNext()) {
				entry = itr.next();
				generator.writeStringField(entry.getKey(), entry.getValue());
			}
			generator.writeEndObject();
		}

		generator.writeStartArray();
		for (IAttribute attr : attributes) {
			generator.writeStartObject();
			generator.writeStringField(ATTR_TYPE,
					getAttributeType(attr.getClass()).name());
			generator.writeEndObject();
			attr.toJSONString(generator);
		}
		generator.writeEndArray();
	}

	public static String VALUE_STATE = "STATE";

	private Vector<IValueListener> listeners;

	private ValueStatus m_Status = ValueStatus.READY;

	public boolean registerListener(IValueListener listener) {
		if (listener == null) {
			return false;
		}
		if (listeners == null) {
			listeners = new Vector<IValueListener>(2);
		}
		if (listeners.contains(listener)) {
			return false;
		}
		return listeners.add(listener);
	}

	public boolean removeValueListener(IValueListener listener) {
		if (listeners == null) {
			return false;
		}
		return listeners.remove(listener);
	}

	protected void changeStatus(ValueStatus newStatus) {
		ValueStatus oldStatus = m_Status;
		if (oldStatus != newStatus) {
			m_Status = newStatus;
			if (listeners != null) {
				for (IValueListener listener : listeners) {
					listener.statusChanged(oldStatus, newStatus, null);
				}
			}
		}
	}

	public final void active() throws Exception {
		_active();
		changeStatus(ValueStatus.ACTIVE);
	}

	protected void _active() throws Exception {
	}

	public final void finish() throws Exception {
		changeStatus(ValueStatus.FILLED);
	}

	public void reset() throws Exception {
		changeStatus(ValueStatus.READY);
	}

	public ValueStatus getStatus() {
		return m_Status;
	}

	public void close() {
		if (attributes != null) {
			for (int i = 0; i < attributes.length; i++) {
				attributes[i].destroy();
				attributes[i] = null;
			}
			attributes = null;
		}
		if (properties != null) {
			properties.clear();
			properties = null;
		}
		ignored = null;
		changeStatus(ValueStatus.CLOSED);
	}

	@Override
	public boolean isClosed() {
		return attributes == null;
	}

	/**
	 * Destroy the metadata to release its memory
	 * */
	public void destroy() {
		if (attributes != null) {
			for (int i = 0; i < attributes.length; i++) {
				attributes[i].destroy();
				attributes[i] = null;
			}
			attributes = null;
		}
		if (properties != null) {
			properties.clear();
			properties = null;
		}
		ignored = null;
		changeStatus(ValueStatus.CLOSED);
	}

	@Override
	public boolean isDestroied() {
		return attributes == null;
	}

	private Logger m_Logger;

	public boolean setLogger(Logger logger) {
		if (this.m_Logger == null && logger != null) {
			this.m_Logger = logger;
			return true;
		}
		return false;
	}

	public Logger getLogger() {
		return m_Logger;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aibox.common.util.ILoggable#info(java.lang.Object)
	 */
	@Override
	public void info(String message) {
		if (m_Logger != null) {
			m_Logger.info(message);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aibox.common.util.ILoggable#info(java.lang.Object,
	 * java.lang.Throwable)
	 */
	@Override
	public void info(String message, Throwable t) {
		if (m_Logger != null) {
			m_Logger.info(message);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aibox.common.util.ILoggable#debug(java.lang.Object)
	 */
	@Override
	public void debug(String message) {
		if (m_Logger != null) {
			m_Logger.debug(message);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aibox.common.util.ILoggable#debug(java.lang.Object,
	 * java.lang.Throwable)
	 */
	@Override
	public void debug(String message, Throwable t) {
		if (m_Logger != null) {
			m_Logger.debug(message, t);
		}
	}

	@Override
	public void warn(String message) {
		if (m_Logger != null) {
			m_Logger.warn(message);
		}
	}

	@Override
	public void warn(String message, Throwable t) {
		if (m_Logger != null) {
			m_Logger.warn(message, t);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aibox.common.util.ILoggable#error(java.lang.Object)
	 */
	@Override
	public void error(String message) {
		if (m_Logger != null) {
			m_Logger.error(message);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aibox.common.util.ILoggable#error(java.lang.Object,
	 * java.lang.Throwable)
	 */
	@Override
	public void error(String message, Throwable t) {
		if (m_Logger != null) {
			m_Logger.error(message, t);
		}
	}

	public static MetaData tryGuessMetaData(String id, String name,
			String[] heads, String[] firstColumns) {
		IAttribute[] attrs = null;
		if (heads != null) {
			attrs = new IAttribute[heads.length];
		} else if (firstColumns != null) {
			attrs = new IAttribute[firstColumns.length];
		} else {
			return null;
		}

		String columnValue, head;
		IAttribute attr = null;
		boolean sparse = false;
		for (int i = 0; i < attrs.length; i++) {
			columnValue = firstColumns[i];
			head = heads != null ? heads[i] : null;
			// empty column
			if (columnValue == null) {
				if (head != null) {
					attr = new NumericAttribute("Attr" + (i + 1), head);
				} else {
					attr = new NumericAttribute("Attr" + (i + 1), "Attr"
							+ (i + 1));
				}
				// sparse data
			} else if (columnValue.contains("" + SEPARATOR_DATA_INNER)) {
				int index = columnValue.indexOf(SEPARATOR_DATA_INNER);
				if (index >= 0 && index < columnValue.length() - 1) {
					// sparse
					columnValue = columnValue.substring(index + 1);
					attr = guessAttribute(i, head, columnValue);
					sparse = true;
				} else {
					// non-sparse
					if (index == columnValue.length() - 1) {
						columnValue = columnValue.substring(0, index);
					}
					attr = guessAttribute(i, head, columnValue);
				}
			} else {
				attr = guessAttribute(i, head, columnValue);
			}
			attrs[i] = attr;
		}
		// decide dataType
		DataType dataType = DataType.DENSE_DOUBLE;
		if (sparse) {
			dataType = DataType.SPARSE_DOUBLE;
			boolean allBoolean = true, allInt = true;
			for (int i = 0; i < attrs.length; i++) {
				switch (attrs[i].getType()) {
				case BOOLEAN:
					break;
				case COUNT:
					allBoolean = false;
					break;
				case NUMERIC:
					allBoolean = false;
					allInt = false;
					break;
				case NOMINAL:
					allBoolean = false;
					break;
				case ORDINAL:
					allBoolean = false;
					break;
				}
			}

			if (allBoolean) {
				dataType = DataType.SPARSE_BOOLEAN;
			} else if (allInt) {
				dataType = DataType.SPARSE_INT;
			}
		} else {
			dataType = DataType.DENSE_DOUBLE;
			boolean allBoolean = true, allInt = true;
			for (int i = 0; i < attrs.length; i++) {
				switch (attrs[i].getType()) {
				case BOOLEAN:
					break;
				case COUNT:
					allBoolean = false;
					break;
				case NUMERIC:
					allBoolean = false;
					allInt = false;
					break;
				case NOMINAL:
					allBoolean = false;
					break;
				case ORDINAL:
					allBoolean = false;
					break;
				}
			}

			if (allBoolean) {
				dataType = DataType.DENSE_BOOLEAN;
			} else if (allInt) {
				dataType = DataType.DENSE_INT;
			}
		}

		return new MetaData(id, name, attrs, -1, 0, dataType);
	}

	// value not empty
	public static IAttribute guessAttribute(int column, String head,
			String columnValue) {
		IAttribute attr = null;
		try {
			// try parse int
			int value = Integer.parseInt(columnValue);
			if (value >= 0) {
				if (head != null) {
					attr = new CountAttribute("Attr" + (column + 1), head);
				} else {
					attr = new CountAttribute("Attr" + (column + 1), "Attr"
							+ (column + 1));
				}
			} else {
				if (head != null) {
					attr = new NominalAttribute("Attr" + (column + 1), head,
							new String[] { columnValue });
				} else {
					attr = new NominalAttribute("Attr" + (column + 1), "Attr"
							+ (column + 1), new String[] { columnValue });
				}
			}
		} catch (NumberFormatException e1) {
			// try parse double
			try {
				double value = Double.parseDouble(columnValue);
				if (value == (int) value) {
					// still int
					if (value >= 0) {
						if (head != null) {
							attr = new CountAttribute("Attr" + (column + 1),
									head);
						} else {
							attr = new CountAttribute("Attr" + (column + 1),
									"Attr" + (column + 1));
						}
					} else {
						if (head != null) {
							attr = new NominalAttribute("Attr" + (column + 1),
									head, new String[] { columnValue });
						} else {
							attr = new NominalAttribute("Attr" + (column + 1),
									"Attr" + (column + 1),
									new String[] { columnValue });
						}
					}
				} else {
					// double
					if (head != null) {
						attr = new NumericAttribute("Attr" + (column + 1), head);
					} else {
						attr = new NumericAttribute("Attr" + (column + 1),
								"Attr" + (column + 1));
					}
				}
			} catch (NumberFormatException e2) {
				if (columnValue.equalsIgnoreCase("true")
						|| columnValue.equalsIgnoreCase("false")) {
					// boolean
					if (head != null) {
						attr = new BooleanAttribute("Attr" + (column + 1), head);
					} else {
						attr = new BooleanAttribute("Attr" + (column + 1),
								"Attr" + (column + 1));
					}
				} else {
					// nominal
					if (head != null) {
						attr = new NominalAttribute("Attr" + (column + 1),
								head, new String[] { columnValue });
					} else {
						attr = new NominalAttribute("Attr" + (column + 1),
								"Attr" + (column + 1),
								new String[] { columnValue });
					}
				}
			}
		}
		return attr;
	}
}
