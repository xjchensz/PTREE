/**
 * 
 */
package common.data.meta;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.dom4j.Element;

import common.MDAException;

/**
 * @author root
 * 
 */
public class NumericAttribute extends AbstractAttribute {

	public static final String ELEMENT_NumericAttribute = "NumericAttribute";

	public static final double ERROR_DOUBLE_VALUE = Double.NaN;

	public static final String LOWERBOUND = "LB";
	public static final String UPPERBOUND = "UB";
	/**
	 * 
	 */
	private static final long serialVersionUID = -6699527133345149448L;

	private double lowerBound;
	private double upperBound;

	/**
	 * 
	 */
	protected NumericAttribute() {
	}

	/**
	 * @param attr
	 */
	public NumericAttribute(NumericAttribute attr) {
		super(attr);
		lowerBound = attr.lowerBound;
		upperBound = attr.upperBound;
	}

	/**
	 * @param id
	 * @param name
	 */
	public NumericAttribute(String id, String name) {
		super(id, name);
	}

	/**
	 * @param id
	 * @param name
	 * @param role
	 */
	public NumericAttribute(String id, String name, Direction direction) {
		super(id, name, direction);
	}

	/**
	 * @param element
	 * @throws Exception
	 */
	public NumericAttribute(Element element) throws Exception {
		super(element);
		lowerBound = Double.valueOf(element.attributeValue(LOWERBOUND));
		upperBound = Double.valueOf(element.attributeValue(UPPERBOUND));
	}

	public NumericAttribute(JsonParser parser) throws JsonParseException,
			IOException, MDAException {
		super(parser);
	}

	public double getLowerBound() {
		return lowerBound;
	}

	public void setLowerBound(double lowerBound) {
		this.lowerBound = lowerBound;
	}

	public double getUpperBound() {
		return upperBound;
	}

	public void setUpperBound(double upperBound) {
		this.upperBound = upperBound;
	}

	@Override
	protected void innerToXML(Element root) {
		super.innerToXML(root);
		root.addAttribute(LOWERBOUND, String.valueOf(lowerBound));
		root.addAttribute(UPPERBOUND, String.valueOf(upperBound));
	}

	protected void innerWriteJSONObject(JsonGenerator generator)
			throws JsonGenerationException, IOException {
		super.innerWriteJSONObject(generator);
		generator.writeStringField(LOWERBOUND, String.valueOf(lowerBound));
		generator.writeStringField(UPPERBOUND, String.valueOf(upperBound));
	}

	protected void parseObjectMore(String fieldName, JsonParser parser)
			throws JsonParseException, IOException {
		super.parseObjectMore(fieldName, parser);
		if (LOWERBOUND.equals(fieldName)) {
			lowerBound = Double.parseDouble(parser.nextTextValue());
		} else if (UPPERBOUND.equals(fieldName)) {
			upperBound = Double.parseDouble(parser.nextTextValue());
		}
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		super.readFields(in);
		lowerBound = in.readDouble();
		upperBound = in.readDouble();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		super.write(out);
		out.writeDouble(lowerBound);
		out.writeDouble(upperBound);
	}

	@Override
	public AttributeType getType() {
		return AttributeType.NUMERIC;
	}

	public boolean equals(Object obj) {
		if (!super.equals(obj)) {
			return false;
		}

		NumericAttribute attr = (NumericAttribute) obj;
		return lowerBound == attr.lowerBound && upperBound == attr.upperBound;
	}

	@Override
	public IAttribute transformTo(AttributeType newType) {
		IAttribute newAttribute;
		switch (newType) {
		case BOOLEAN:
		case COUNT:
		case ORDINAL:
		case NOMINAL:
			newAttribute = new NominalAttribute(getID(), getName(),
					getDirection());
			newAttribute.setDescription(getDescription());
			break;
		case NUMERIC:
		default:
			newAttribute = this;
			break;
		}
		return newAttribute;
	}

	private AttributeType[] transformTypes;

	@Override
	public AttributeType[] getTransformTypes() {
		if (transformTypes == null) {
			transformTypes = new AttributeType[] {};
		}
		return transformTypes;
	}

}
