/**
 * 
 */
package common.data.meta;

import java.io.IOException;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.dom4j.Element;

import common.MDAException;

/**
 * @author root
 * 
 */
public class OrdinalAttribute extends NominalAttribute {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6342855173446925180L;

	/**
	 * 
	 */
	protected OrdinalAttribute() {
	}

	/**
	 * @param attr
	 */
	public OrdinalAttribute(OrdinalAttribute attr) {
		super(attr);
	}

	/**
	 * @param id
	 * @param name
	 */
	public OrdinalAttribute(String id, String name) {
		super(id, name);
	}

	/**
	 * @param id
	 * @param name
	 * @param role
	 */
	public OrdinalAttribute(String id, String name, Direction direction) {
		super(id, name, direction);
	}

	/**
	 * @param id
	 * @param name
	 * @param values
	 */
	public OrdinalAttribute(String id, String name, String[] values) {
		super(id, name, values);
	}

	public OrdinalAttribute(String id, String name, Direction direction,
			String[] values) {
		super(id, name, direction, values);
	}

	public OrdinalAttribute(Element element) throws Exception {
		super(element);
	}

	public OrdinalAttribute(JsonParser parser) throws JsonParseException,
			IOException, MDAException {
		super(parser);
	}

	@Override
	public AttributeType getType() {
		return AttributeType.ORDINAL;
	}

	public boolean equals(Object obj) {
		return (obj instanceof OrdinalAttribute) && super.equals(obj);
	}

}
