/**
 * 
 */
package common.data.meta;

import common.IIDNameAble;
import common.IWritable;
import common.IXMLAble;
import common.json.IJSONObject;

/**
 * @author root
 * 
 */
public interface IAttribute extends IIDNameAble, IXMLAble, IWritable,
		IJSONObject {

	/**
	 * sets the direction
	 * */
	public void setDirection(Direction direction);

	/**
	 * @return the direction
	 * */
	public Direction getDirection();

	/**
	 * @return the type of the attribute
	 * */
	public AttributeType getType();

	/**
	 * @return the types the attribute can be transformed into
	 * */
	public AttributeType[] getTransformTypes();

	/**
	 * transform the attribute to a new type
	 * */
	public IAttribute transformTo(AttributeType newType);

	/**
	 * 
	 * @return <code>true</code> if the direction of the attribute is
	 *         <code>Direction.NONE<code>,
	 *         otherwise <code>false</code>
	 */
	public boolean isIgnored();

	public IAttribute clone();

	/**
	 * @return <code>true</code> if the given attribute has the same name with
	 *         this attribute, otherwise <code>false</code>
	 * */
	public boolean match(IAttribute attr);

	/**
	 * Destroy the attribute
	 */
	public void destroy();

}
