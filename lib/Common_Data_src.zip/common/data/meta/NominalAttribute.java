/**
 * 
 */
package common.data.meta;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.dom4j.Element;

import common.MDAException;
import common.utils.StringUtils;
import common.utils.math.Varint;

/**
 * @author root
 * 
 */
public class NominalAttribute extends AbstractAttribute {

	public static final double ERROR_DOUBLE_VALUE = -1;
	public static final int ERROR_INT_VALUE = -1;

	public static final String VALUES = "VALUES";

	/**
	 * 
	 */
	private static final long serialVersionUID = -4045232222916888535L;

	private String[] values;

	/**
	 * 
	 */
	protected NominalAttribute() {
	}

	/**
	 * @param attr
	 */
	public NominalAttribute(NominalAttribute attr) {
		super(attr);
		if (attr.values != null) {
			values = new String[attr.values.length];
			System.arraycopy(attr.values, 0, values, 0, values.length);
		}

	}

	/**
	 * @param id
	 * @param name
	 */
	public NominalAttribute(String id, String name) {
		super(id, name);
	}

	/**
	 * @param id
	 * @param name
	 * @param role
	 */
	public NominalAttribute(String id, String name, Direction direction) {
		super(id, name, direction);
	}

	/**
	 * @param id
	 * @param name
	 * @param values
	 */
	public NominalAttribute(String id, String name, String[] values) {
		super(id, name);
		this.values = values;
	}

	/**
	 * @param id
	 * @param name
	 * @param role
	 * @param values
	 */
	public NominalAttribute(String id, String name, Direction direction,
			String[] values) {
		super(id, name, direction);
		this.values = values;
	}

	public NominalAttribute(Element root) throws Exception {
		super(root);
	}

	protected void innerParse(Element root) throws IOException {
		super.innerParse(root);
		String vl = root.attributeValue(VALUES);
		if (vl != null) {
			this.values = StringUtils.split2Array(vl, ',');
		} else {
			this.values = new String[0];
		}
	}

	public NominalAttribute(JsonParser parser) throws JsonParseException,
			IOException, MDAException {
		super(parser);
	}

	public void setCategoryValues(String[] values) {
		this.values = values;
	}

	public String[] getCategoryValues() {
		return values;
	}

	protected int addNewValue(String value) {
		String[] nvalues = new String[values != null ? values.length + 1 : 1];
		if (values != null) {
			System.arraycopy(values, 0, nvalues, 0, values.length);
		}
		nvalues[nvalues.length - 1] = value;
		values = nvalues;
		return values.length - 1;
	}

	private HashMap<String, Integer> map;

	public int encode(String value, boolean addIfNotExists) {
		if (map == null) {
			if (values == null || values.length == 0) {
				if (addIfNotExists) {
					return addNewValue(value);
				} else {
					return -1;
				}
			} else if (values.length < 4) {
				int index = -1;
				for (int i = 0; i < values.length; i++) {
					if (values[i].equals(value)) {
						index = i;
						break;
					}
				}
				if (index < 0 && addIfNotExists) {
					index = addNewValue(value);
				}
				return index;
			} else {
				map = new HashMap<String, Integer>();
				if (values != null) {
					for (int i = 0; i < values.length; i++) {
						map.put(values[i], i);
					}
				}
			}
		}
		Integer index = map.get(value);
		if (index == null && addIfNotExists) {
			// resize values
			index = addNewValue(value);
			map.put(value, index);
		}
		return index != null ? index : -1;
	}

	public String decode(int indexValue) {
		if (indexValue >= 0 && values != null && indexValue < values.length) {
			return values[indexValue];
		}
		return null;
	}

	public int numValues() {
		return values == null ? 0 : values.length;
	}

	@Override
	protected void innerToXML(Element root) {
		super.innerToXML(root);
		if (values != null && values.length > 0) {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < values.length; i++) {
				sb.append(values[i]).append(',');
			}
			sb.setLength(sb.length() - 1);
			root.addAttribute(VALUES, sb.toString());
		}
	}

	protected void innerWriteJSONObject(JsonGenerator generator)
			throws JsonGenerationException, IOException {
		super.innerWriteJSONObject(generator);
		if (values != null && values.length > 0) {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < values.length; i++) {
				sb.append(values[i]).append(',');
			}
			sb.setLength(sb.length() - 1);
			generator.writeStringField(VALUES, sb.toString());
		}
	}

	protected void parseObjectMore(String fieldName, JsonParser parser)
			throws JsonParseException, IOException {
		super.parseObjectMore(fieldName, parser);
		if (VALUES.equals(fieldName)) {
			values = StringUtils.split2Array(parser.nextTextValue(), ',');
		}
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		super.readFields(in);
		int length = Varint.readUnsignedVarInt(in);
		values = new String[length];
		for (int i = 0; i < length; i++) {
			values[i] = in.readUTF();
		}
	}

	@Override
	public void write(DataOutput out) throws IOException {
		super.write(out);
		Varint.writeUnsignedVarInt(values.length, out);
		for (int i = 0; i < values.length; i++) {
			out.writeUTF(values[i]);
		}
	}

	@Override
	public AttributeType getType() {
		return AttributeType.NOMINAL;
	}

	public boolean equals(Object obj) {
		if (!super.equals(obj)) {
			return false;
		}

		NominalAttribute attr = (NominalAttribute) obj;
		return Arrays.equals(values, attr.values);
	}

	@Override
	public IAttribute transformTo(AttributeType newType) {
		IAttribute newAttribute;
		switch (newType) {
		case ORDINAL:
			newAttribute = new OrdinalAttribute(getID(), getName(), values);
			break;
		case NUMERIC:
			newAttribute = new NumericAttribute(getID(), getName());
			((NumericAttribute) newAttribute).setLowerBound(0);
			((NumericAttribute) newAttribute).setUpperBound(values.length);
			break;
		case BOOLEAN:
		case COUNT:
		case NOMINAL:
		default:
			newAttribute = this;
			break;
		}
		return newAttribute;
	}

	private AttributeType[] transformTypes;

	@Override
	public AttributeType[] getTransformTypes() {
		if (transformTypes == null) {
			transformTypes = new AttributeType[] { AttributeType.ORDINAL,
					AttributeType.NUMERIC };
		}
		return transformTypes;
	}

	@Override
	public void destroy() {
		super.destroy();
		if (map != null) {
			map.clear();
			map = null;

		}
		values = null;
	}
}
