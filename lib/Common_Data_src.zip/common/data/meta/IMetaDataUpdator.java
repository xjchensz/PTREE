/**
 * 
 */
package common.data.meta;

import java.io.IOException;

/**
 * @author xjc
 * 
 */
public interface IMetaDataUpdator {

	public void update(MetaData metaData) throws IOException;
}
