/**
 * 
 */
package common.data.meta;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.dom4j.Element;

import common.MDAException;

/**
 * @author root
 * 
 */
public class CountAttribute extends AbstractAttribute {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3160967166646527640L;

	public static final double ERROR_DOUBLE_VALUE = -1;
	public static final int ERROR_INT_VALUE = -1;

	public static final String UPPERBOUND = "UB";
	private int upperBound = Integer.MAX_VALUE;

	/**
	 * 
	 */
	protected CountAttribute() {
	}

	/**
	 * @param attr
	 */
	public CountAttribute(CountAttribute attr) {
		super(attr);
	}

	/**
	 * @param id
	 * @param name
	 */
	public CountAttribute(String id, String name) {
		super(id, name);
	}

	/**
	 * @param id
	 * @param name
	 * @param role
	 */
	public CountAttribute(String id, String name, Direction direction) {
		super(id, name, direction);
	}

	/**
	 * @param element
	 * @throws Exception
	 */
	public CountAttribute(Element element) throws Exception {
		super(element);
		upperBound = Integer.valueOf(element.attributeValue(UPPERBOUND));
	}

	public CountAttribute(JsonParser parser) throws JsonParseException,
			IOException, MDAException {
		super(parser);
	}

	public int getUpperBound() {
		return upperBound;
	}

	public void setUpperBound(int upperBound) {
		if (upperBound < 0 || upperBound == Double.NEGATIVE_INFINITY) {
			throw new IllegalArgumentException();
		}
		this.upperBound = upperBound;
	}

	@Override
	protected void innerToXML(Element root) {
		super.innerToXML(root);
		root.addAttribute(UPPERBOUND, String.valueOf(upperBound));
	}

	protected void innerWriteJSONObject(JsonGenerator generator)
			throws JsonGenerationException, IOException {
		super.innerWriteJSONObject(generator);
		generator.writeStringField(UPPERBOUND, String.valueOf(upperBound));
	}

	protected void parseObjectMore(String fieldName, JsonParser parser)
			throws JsonParseException, IOException {
		super.parseObjectMore(fieldName, parser);
		if (UPPERBOUND.equals(fieldName)) {
			upperBound = Integer.valueOf(parser.nextTextValue());
		}
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		super.readFields(in);
		upperBound = in.readInt();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		super.write(out);
		out.writeInt(upperBound);
	}

	@Override
	public AttributeType getType() {
		return AttributeType.COUNT;
	}

	public boolean equals(Object obj) {
		if (!super.equals(obj)) {
			return false;
		}

		CountAttribute attr = (CountAttribute) obj;
		return upperBound == attr.upperBound;
	}

	@Override
	public IAttribute transformTo(AttributeType newType) {
		IAttribute newAttribute;
		switch (newType) {
		case NOMINAL:
			newAttribute = new NominalAttribute(getID(), getName());
			break;
		case ORDINAL:
			newAttribute = new OrdinalAttribute(getID(), getName());
			break;
		case NUMERIC:
			newAttribute = new NumericAttribute(getID(), getName());
			((NumericAttribute) newAttribute).setLowerBound(0);
			((NumericAttribute) newAttribute).setUpperBound(upperBound);
			break;
		case BOOLEAN:
		case COUNT:
		default:
			newAttribute = this;
			break;
		}
		return newAttribute;
	}

	private AttributeType[] transformTypes;

	@Override
	public AttributeType[] getTransformTypes() {
		if (transformTypes == null) {
			transformTypes = new AttributeType[] { AttributeType.NUMERIC,
					AttributeType.NOMINAL, AttributeType.ORDINAL };
		}
		return transformTypes;
	}

}
