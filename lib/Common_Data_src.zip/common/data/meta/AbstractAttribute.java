/**
 * 
 */
package common.data.meta;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.reflect.Constructor;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.dom4j.Element;

import common.AbstractIDNameXMLJSONAble;
import common.MDAException;

/**
 * @author root
 * 
 */
public abstract class AbstractAttribute extends AbstractIDNameXMLJSONAble
		implements IAttribute {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5300010129500324148L;
	public static final String ELEMENT_Attribute = "Attribute";

	public static final String DIRECTION = "dir";
	protected Direction m_Direction;

	protected AbstractAttribute() {
	}

	public AbstractAttribute(IAttribute attr) {
		super(attr);
		this.m_Direction = attr.getDirection();
	}

	public AbstractAttribute(String id, String name) {
		this(id, name, Direction.getDefault());
	}

	public AbstractAttribute(String id, String name, Direction direction) {
		super(id, name);
		this.m_Direction = direction;
	}

	public AbstractAttribute(Element element) throws Exception {
		super(element);
	}

	protected void innerParse(Element root) throws IOException {
		String roleName = root.attributeValue(DIRECTION);
		if (roleName != null) {
			this.m_Direction = Direction.valueOf(roleName);
		} else {
			this.m_Direction = Direction.getDefault();
		}
	}

	protected AbstractAttribute(JsonParser parser) throws JsonParseException,
			IOException, MDAException {
		super(parser);
	}

	protected void parseObjectMore(String fieldName, JsonParser parser)
			throws JsonParseException, IOException {
		if (DIRECTION.equals(fieldName)) {
			this.m_Direction = Direction.valueOf(parser.nextTextValue());
		}
	}

	protected void parseMore(JsonParser parser) throws JsonParseException,
			IOException, MDAException {
		// do nothing
	}

	public String getXMLElementName() {
		return ELEMENT_Attribute;
	}

	@Override
	protected void innerToXML(Element root) {
		root.addAttribute(DIRECTION, String.valueOf(m_Direction.name()));
	}

	protected void innerWriteJSONObject(JsonGenerator generator)
			throws JsonGenerationException, IOException {
		generator.writeStringField(DIRECTION, getDirection().name());
	}

	protected void innerWriteJSONMore(JsonGenerator generator)
			throws JsonGenerationException, IOException {
		// do nothing
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		super.readFields(in);
		m_Direction = Direction.values()[in.readByte()];
	}

	@Override
	public void write(DataOutput out) throws IOException {
		super.write(out);
		out.writeByte(getDirection().ordinal());
	}

	@Override
	public boolean isIgnored() {
		return Direction.none == getDirection();
	}

	@Override
	public void setDirection(Direction direction) {
		this.m_Direction = direction;
	}

	@Override
	public Direction getDirection() {
		return m_Direction;
	}

	public IAttribute clone() {
		try {
			Constructor<? extends AbstractAttribute> constructor = getClass()
					.getConstructor(getClass());
			return constructor.newInstance(this);
		} catch (Exception e) {
		}
		return null;
	}

	public boolean equals(Object obj) {
		if (!obj.getClass().isAssignableFrom(getClass())
				&& !getClass().isAssignableFrom(obj.getClass())) {
			return false;
		}
		AbstractAttribute attr = (AbstractAttribute) obj;
		if (!super.equals(obj)) {
			return false;
		}
		return m_Direction == attr.m_Direction;
	}

	public boolean match(IAttribute att) {
		return att.getClass() == this.getClass();
	}

	@Override
	public void destroy() {
		// do nothing
	}

}
