/**
 * Created by Xiaojun Chen at 2012-6-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.meta;

import java.io.IOException;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.dom4j.Element;

import common.MDAException;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class BooleanAttribute extends AbstractAttribute {

	/**
	 * 
	 */
	private static final long serialVersionUID = -640069485056632207L;

	public static final double ERROR_DOUBLE_VALUE = -1;
	public static final int ERROR_INT_VALUE = -1;

	/**
	 * 
	 */
	protected BooleanAttribute() {
	}

	/**
	 * @param attr
	 */
	public BooleanAttribute(BooleanAttribute attr) {
		super(attr);
	}

	/**
	 * @param id
	 * @param name
	 */
	public BooleanAttribute(String id, String name) {
		super(id, name);
	}

	/**
	 * @param id
	 * @param name
	 * @param role
	 */
	public BooleanAttribute(String id, String name, Direction direction) {
		super(id, name, direction);
	}

	/**
	 * @param element
	 * @throws Exception
	 */
	public BooleanAttribute(Element element) throws Exception {
		super(element);
	}

	public BooleanAttribute(JsonParser parser) throws JsonParseException,
			IOException, MDAException {
		super(parser);
	}

	@Override
	public AttributeType getType() {
		return AttributeType.BOOLEAN;
	}

	@Override
	public IAttribute transformTo(AttributeType newType) {
		IAttribute newAttribute;
		switch (newType) {
		case COUNT:
			newAttribute = new CountAttribute(getID(), getName());
			break;
		case NOMINAL:
			newAttribute = new NominalAttribute(getID(), getName(),
					new String[] { "false", "true" });
			break;
		case ORDINAL:
			newAttribute = new OrdinalAttribute(getID(), getName(),
					new String[] { "false", "true" });
			break;
		case NUMERIC:
			newAttribute = new NumericAttribute(getID(), getName());
			((NumericAttribute) newAttribute).setLowerBound(0);
			((NumericAttribute) newAttribute).setUpperBound(1);
			break;
		case BOOLEAN:
		default:
			newAttribute = this;
			break;
		}
		return newAttribute;
	}

	private AttributeType[] transformTypes;

	@Override
	public AttributeType[] getTransformTypes() {
		if (transformTypes == null) {
			transformTypes = new AttributeType[] { AttributeType.NUMERIC,
					AttributeType.COUNT, AttributeType.NOMINAL,
					AttributeType.ORDINAL };
		}
		return transformTypes;
	}
}
