/**
 * Created by Xiaojun Chen at 2012-7-2
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.meta;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public enum DataType {
	DENSE_DOUBLE, DENSE_INT, DENSE_BOOLEAN, SPARSE_DOUBLE, SPARSE_INT, SPARSE_BOOLEAN;

	public static DataType defaultValue() {
		return DENSE_DOUBLE;
	}

	public static String[] getNames() {
		return getNames(values());
	}

	public static String[] getNames(DataType[] types) {
		String[] names = new String[types.length];

		for (int i = 0; i < names.length; i++) {
			names[i] = types[i].name();
		}

		return names;
	}
}
