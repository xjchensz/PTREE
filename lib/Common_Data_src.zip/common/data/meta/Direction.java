/**
 * 
 */
package common.data.meta;

/**
 * @author xjchen
 * 
 */
public enum Direction {

	input, output, none;

	public static String[] getNames() {
		Direction[] directions = values();
		if (directions != null) {
			String[] dirs = new String[directions.length];
			for (int i = 0; i < dirs.length; i++) {
				dirs[i] = directions[i].name();
			}
			return dirs;
		}
		return null;
	}

	public static Direction getDefault() {
		return input;
	}

}
