/**
 * Created by Xiaojun Chen at 2012-7-18
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data.meta;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public enum AttributeType {
	BOOLEAN, COUNT, NUMERIC, NOMINAL, ORDINAL;

	public static AttributeType defaultValue() {
		return AttributeType.NUMERIC;
	}

	public static String[] getNames() {
		return getNames(values());
	}

	public static String[] getNames(AttributeType[] types) {
		if (types == null || types.length == 0) {
			return new String[0];
		}
		String[] names = new String[types.length];
		for (int i = 0; i < names.length; i++) {
			names[i] = types[i].name();
		}
		return names;
	}
}
