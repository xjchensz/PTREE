/**
 * Created by Xiaojun Chen at 2012-3-29
 * Shenzhen High Performance Data Mining Lab 
 */
package common.data;

import java.io.InputStream;
import java.io.Serializable;

import common.data.meta.MetaData;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public interface IIndexedDataParser extends Serializable {

	public MetaData getMetaData();

	public InputStream getDataStream();

	public InputStream getDataIndexStream();

}
