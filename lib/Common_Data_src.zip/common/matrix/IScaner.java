/**
 * @author Xiaojun Chen
 * @email xjchen@szu.edu.cn
 * 2016��2��10��
 */
package common.matrix;

/**
 * @author Xiaojun
 *
 */
public interface IScaner {
	public void scan(int index, double value);
}
