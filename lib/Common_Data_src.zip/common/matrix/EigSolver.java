/**
 * @Author Xiaojun Chen
 * @Email xjchen@szu.edu.cn
 * 2016/2/10
 */
package common.matrix;

import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.OpenMapRealMatrix;
import org.jblas.NativeBlas;
import org.ujmp.core.Matrix;
import org.ujmp.jblas.JBlasDenseDoubleMatrix2D;
import org.ujmp.jblas.calculation.Eig;

import common.utils.MathUtils;

/**
 * @author Xiaojun Chen
 *
 */
public class EigSolver {

	public static void eig(SparseDoubleMatrix sdm, double[] eigval, double[][] eigvec) throws Exception {
		eig(sdm, eigval, eigvec, true);
	}

	// default return min minimal eigvalues and corresponding vectors
	public static void eig(SparseDoubleMatrix sdm, double[] eigval, double[][] eigvec, boolean isMin) throws Exception {
		final int rows = sdm.getRowCount();
		if (rows != sdm.getColumnCount()) {
			throw new Exception("eig matrix size error: must be square matrix");
		}

		final double[] data = new double[rows * rows];

		for (int i = 0; i < rows; i++) {
			final int row = i;
			sdm.scanColumnsInRow(i, new IScaner() {

				@Override
				public void scan(int index, double value) {
					data[row + index * rows] = value;
				}
			});
		}

		double[] evreal = new double[rows];
		double[] evimg = new double[rows];
		double[] evcreal = new double[data.length];
		double[] evcimg = new double[data.length];

		JeigenJna.Jeigen.jeigen_eig(rows, data, evreal, evimg, evcreal, evcimg);

		int maxNum = eigval.length > eigvec[0].length ? eigval.length : eigvec[0].length;

		int[] cnn;
		if (isMin) {
			cnn = MathUtils.min(evreal, maxNum);
		} else {
			cnn = MathUtils.max(evreal, maxNum);
		}
		for (int i = 0; i < eigval.length; i++) {
			eigval[i] = evreal[cnn[i]];
		}
		for (int i = 0, j; i < rows; i++) {
			for (j = 0; j < eigvec[i].length; j++) {
				eigvec[i][j] = evcreal[i + cnn[j] * rows];
			}
		}
	}

	public static void eig2(SparseDoubleMatrix sdm, double[] eigval, double[][] eigvec) {
		int rows = sdm.getRowCount();
		if (rows != sdm.getColumnCount()) {
			throw new RuntimeException("eig matrix size error: must be square matrix");
		}

		final OpenMapRealMatrix dm = new OpenMapRealMatrix(rows, rows);

		for (int i = 0; i < rows; i++) {
			final int row = i;
			sdm.scanColumnsInRow(i, new IScaner() {

				@Override
				public void scan(int index, double value) {
					dm.setEntry(row, index, value);
				}
			});
		}

		EigenDecomposition ed = new EigenDecomposition(dm);
		double[] d = new double[rows];
		for (int i = 0; i < rows; i++) {
			d[i] = ed.getD().getEntry(i, i);
		}

		int maxNum = eigval.length > eigvec[0].length ? eigval.length : eigvec[0].length;
		int[] cnn = MathUtils.min(d, maxNum);
		for (int i = 0; i < eigval.length; i++) {
			eigval[i] = d[cnn[i]];
		}
		for (int i = 0, j; i < rows; i++) {
			for (j = 0; j < eigvec[i].length; j++) {
				eigvec[i][j] = ed.getV().getEntry(i, cnn[j]);
			}
		}
		// RealMatrix re = dm.multiply(ed.getV());
		// re = re.subtract(ed.getV().multiply(ed.getD()));
		// System.out.println(ed.getV());
		// System.out.println(ed.getD());
		// System.out.println(re);
	}

	public static void eig3(SparseDoubleMatrix sdm, double[] eigval, double[][] eigvec) {
		int rows = sdm.getRowCount();
		if (rows != sdm.getColumnCount()) {
			throw new RuntimeException("eig matrix size error: must be square matrix");
		}

		final JBlasDenseDoubleMatrix2D dm = new JBlasDenseDoubleMatrix2D(rows, rows);

		for (int i = 0; i < rows; i++) {
			final int row = i;
			sdm.scanColumnsInRow(i, new IScaner() {

				@Override
				public void scan(int index, double value) {
					dm.setAsDouble(value, row, index);
				}
			});
		}
		Matrix[] result = Eig.INSTANCE.calc(dm);
		double[] d = new double[rows];
		for (int i = 0; i < rows; i++) {
			d[i] = result[1].getAsDouble(i, i);
		}

		int maxNum = eigval.length > eigvec[0].length ? eigval.length : eigvec[0].length;
		int[] cnn = MathUtils.min(d, maxNum);
		for (int i = 0; i < eigval.length; i++) {
			eigval[i] = d[cnn[i]];
		}
		for (int i = 0, j; i < rows; i++) {
			for (j = 0; j < eigvec[i].length; j++) {
				eigvec[i][j] = result[0].getAsDouble(i, cnn[j]);
			}
		}

		// Matrix re = dm.times(result[0]).minus(result[1].times(result[0]));
		// System.out.println(result[0]);
		// System.out.println(result[1]);
		// System.out.println(re);
	}

	public static void eig4(SparseDoubleMatrix sdm, double[] eigval, double[][] eigvec) {
		final int rows = sdm.getRowCount();
		if (rows != sdm.getColumnCount()) {
			throw new RuntimeException("eig matrix size error: must be square matrix");
		}

		final double[] data = new double[rows * rows];

		for (int i = 0; i < rows; i++) {
			final int row = i;
			sdm.scanColumnsInRow(i, new IScaner() {

				@Override
				public void scan(int index, double value) {
					data[row + index * rows] = value;
				}
			});
		}

		double[] ev = new double[rows];
		double[] evc = new double[data.length];

		syevr(rows, data, ev, evc);

		for (int i = 0; i < eigval.length; i++) {
			eigval[i] = ev[i];
		}
		for (int i = 0, j; i < rows; i++) {
			for (j = 0; j < eigvec[i].length; j++) {
				eigvec[i][j] = evc[i + j * rows];
			}
		}
		System.out.println(sdm.maxtrixFormat());

		// Matrix re = dm.times(result[0]).minus(result[1].times(result[0]));
		// System.out.println(result[0]);
		// System.out.println(result[1]);
		// System.out.println(re);
	}

	private static boolean syevr(int rows, double[] data, double[] eigenvalues, double[] eigenvector) {
		int info = NativeBlas.dsyevr('V', 'A', 'U', rows, data, 0, rows, 0.0, 0.0, 0, 0, 0.0, new int[1], 0,
				eigenvalues, 0, eigenvector, 0, rows, new int[2 * rows], 0);

		if (info < -1)
			return false;

		return true;
	}

}
