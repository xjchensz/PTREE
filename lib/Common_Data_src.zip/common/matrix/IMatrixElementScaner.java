/**
 * @author Xiaojun Chen
 * @email xjchen@szu.edu.cn
 * 2016��3��17��
 */
package common.matrix;

/**
 * @author Xiaojun Chen
 *
 */
public interface IMatrixElementScaner {

	public void scan(int row, int column, double value);

}
