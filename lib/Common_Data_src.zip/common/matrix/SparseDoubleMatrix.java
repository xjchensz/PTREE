package common.matrix;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import common.IWritable;
import common.utils.collection.ORDER;
import common.utils.collection.OrderedComplexDoubleCalculableMap;
import common.utils.collection.OrderedIntArraySet;
import common.utils.collection.STATUS;
import common.utils.math.Varint;

public class SparseDoubleMatrix implements IWritable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -9141936735781320302L;

	private OrderedComplexDoubleCalculableMap map;

	private int rows;
	private int columns;

	private SparseDoubleMatrix() {
	}

	public SparseDoubleMatrix(int r, int c) {
		// creates an empty r by c matrix
		rows = r;
		columns = c;
		map = new OrderedComplexDoubleCalculableMap(2, ORDER.ASC, STATUS.DISTINCT);
	}

	public SparseDoubleMatrix(SparseDoubleMatrix m) {
		// creates a new replicate of m
		rows = m.rows;
		columns = m.columns;
		map = m.map.clone();
	}

	public void setEmptyValue(double emptyValue) {
		map.setEmptyValue(emptyValue);
	}

	public int getRowCount() {
		return rows;
	}

	public int getColumnCount() {
		return columns;
	}

	public void setValue(int row, int column, double value) {
		map.put(value, row, column);
	}

	public void copy(SparseDoubleMatrix P) {
		map.clear();
		P.map.copyContentTo(map);
		rows = P.rows;
		columns = P.columns;
	}

	public void addValue(int row, int column, double value) {
		int[] key = new int[] { row, column };
		int index = map.findIndexForKey(0, key);
		if (map.compareKey(index, key) == 0) {
			map.setValueAt(index, value);
		} else {
			map.put(value, key);
		}
	}

	public double getValue(int row, int column) {
		return map.get(row, column);
	}

	/**
	 * @return the row and column index for the minimum value
	 */
	public int[] min() {
		int size = map.size();
		double minValue = Double.MAX_VALUE;
		int minIndex = 0;
		for (int i = 0; i < size; i++) {
			if (map.getValueAt(i) < minValue) {
				minIndex = i;
				minValue = map.getValueAt(i);
			}
		}
		return map.getKeyAt(minIndex);
	}

	/**
	 * @return the row and column index for the minimum value
	 */
	public int[] max() {
		int size = map.size();
		double maxValue = -Double.MAX_VALUE;
		int maxIndex = 0;
		for (int i = 0; i < size; i++) {
			if (map.getValueAt(i) > maxValue) {
				maxIndex = i;
				maxValue = map.getValueAt(i);
			}
		}
		return map.getKeyAt(maxIndex);
	}

	public void removeAllColumns(int column) {
		for (int i = rows - 1; i >= 0; i--) {
			map.remove(i, column);
		}
	}

	public void removeAllRows(int row) {
		for (int j = columns - 1; j >= 0; j--) {
			map.remove(row, j);
		}
	}

	public double remove(int row, int column) {
		return map.remove(row, column);
	}

	/**
	 * contsructor: creates an r by c special matrix
	 */
	public SparseDoubleMatrix(int r, int c, char code) {
		this(r, c);
		int i;
		if ((code == 'i') || (code == 'I')) {
			// make an identity matrix
			for (i = 0; i < r; i++) {
				if (i < c) {
					map.put(1, i, i);
				}
			}
		}
	}

	/**
	 * transpose the matrix
	 * 
	 */
	public SparseDoubleMatrix transpose() {
		SparseDoubleMatrix m = new SparseDoubleMatrix(rows, columns);
		int size = map.size();
		int[] index;
		for (int i = 0; i < size; i++) {
			index = map.getKeyAt(i);
			m.map.put(map.getValueAt(i), index[1], index[0]);
		}
		return m;
	}

	/**
	 * Only retains the diagonal of this matrix (as a vector), or if given a
	 * vector, returns a diagonal matrix
	 */
	public void diag() {
		if (columns == 1) {
			columns = rows;
			int size = map.size();
			int[] index;
			for (int i = size - 1; i >= 0; i--) {
				index = map.getKeyAt(i);
				map.put(map.remove(i), index[0], index[0]);
			}

		} else {
			int size = map.size();
			int[] index;
			for (int i = size - 1; i >= 0; i--) {
				index = map.getKeyAt(i);
				if (index[0] != index[1]) {
					map.remove(index);
				}
			}
		}
	}

	public void plus(SparseDoubleMatrix sdm) {
		int size = sdm.map.size();
		int[] indices;
		for (int i = 0; i < size; i++) {
			indices = sdm.map.getKeyAt(i);
			map.add(sdm.map.getValueAt(i), indices[0], indices[1]);
		}
	}

	public void multiply(double v) {
		int size = map.size();
		for (int i = 0; i < size; i++) {
			map.setValueAt(i, v * map.getValueAt(i));
		}
	}

	public double multiply(int row, int[] knn, double[] value) {
		double result = 0;
		for (int i = 0; i < value.length; i++) {
			result += map.get(row, knn[i]) * value[i];
		}

		return result;
	}

	/**
	 * Compute the Laplacian matrix Lp as follows:<br>
	 * 
	 * 1. P0=-(P+P')/2;<br>
	 * 2. D0=diag(sum(P0));<br>
	 * 3. LP=-D0+P0
	 */
	public void LP() {
		// COMPUTE P0=-(P+P')/2;

		int size = map.size();
		double value;
		int[] key;
		boolean[] flag = new boolean[size];
		int index, tmp;
		for (int i = 0; i < size; i++) {
			if (flag[i]) {
				continue;
			}
			key = map.getKeyAt(i);
			if (key[0] != key[1]) {
				tmp = key[0];
				key[0] = key[1];
				key[1] = tmp;
				index = map.findIndexForKey(0, key);
				if (map.compareKey(index, key) == 0) {
					value = -0.5 * (map.getValueAt(i) + map.getValueAt(index));
					map.setValueAt(i, value);
					map.setValueAt(index, value);
					flag[index] = true;
				} else {
					value = -0.5 * map.getValueAt(i);
					map.setValueAt(i, value);
				}
			} else {
				map.multiplyValueAt(i, -1);
			}
		}

		// 2. D0=diag(sum(P0));
		double[] sr = sumRow();

		// 3. LP=P0-D0
		for (int i = 0; i < rows; i++) {
			map.add(-sr[i], new int[] { i, i });
		}
	}

	public double[] sumRow() {
		double[] sum = new double[rows];
		int size = map.size();
		for (int i = 0; i < size; i++) {
			sum[map.getKeyAt(i)[0]] += map.getValueAt(i);
		}
		return sum;
	}

	public double[] sumColumn() {
		double[] sum = new double[columns];
		int size = map.size();
		for (int i = 0; i < size; i++) {
			sum[map.getKeyAt(i)[1]] += map.getValueAt(i);
		}
		return sum;
	}

	public int[] getColumnForRowValues(int row) {
		return map.getKeyUnder(row);
	}

	public void scanColumnsInRow(int row, IScaner scaner) {
		int[] indices = map.findAllIndicesForKey(row);
		for (int i = 0; i < indices.length; i++) {
			scaner.scan(map.getKeyAt(indices[i])[1], map.getValueAt(indices[i]));
		}
	}

	public int size() {
		return map.size();
	}

	public double getEmptyValue() {
		return map.getEmptyValue();
	}

	public int[] getRowForColumnValues(int column) {
		OrderedIntArraySet os = new OrderedIntArraySet();

		int tp;
		int size = map.size();
		for (int i = 0; i < rows; i++) {
			tp = map.findIndexForKey(0, i, column);
			if (tp < size && map.compareKey(tp, i, column) == 0) {
				os.add(i);
			}
		}
		int[] result = os.values();
		os.destroy();
		return result;
	}

	public void scanRowsInColumn(int column, IScaner scaner) {

		int tp;
		int size = map.size();
		for (int i = 0; i < rows; i++) {
			tp = map.findIndexForKey(0, i, column);
			if (tp < size && map.compareKey(tp, i, column) == 0) {
				scaner.scan(map.getKeyAt(tp)[0], map.getValueAt(tp));
			}
		}
	}

	public void scanElements(IMatrixElementScaner scaner) {
		int size = map.size();
		int[] key;
		for (int i = 0; i < size; i++) {
			key = map.getKeyAt(i);
			scaner.scan(key[0], key[1], map.getValueAt(i));
		}
	}

	public int[] getCrossedElements(int row) {

		OrderedIntArraySet os = new OrderedIntArraySet();
		os.addAll(map.getKeyUnder(row));
		int tp;
		int size = map.size();
		for (int i = 0; i < rows; i++) {
			tp = map.findIndexForKey(0, i, row);
			if (tp < size && map.compareKey(tp, i, row) == 0) {
				os.add(i);
			}
		}
		int[] result = os.values();
		os.destroy();
		return result;
	}

	public String maxtrixFormat() {
		StringBuilder sb = new StringBuilder();
		sb.append('[');
		for (int i = 0, j; i < rows; i++) {
			for (j = 0; j < columns; j++) {
				sb.append(getValue(i, j)).append(',');
			}
			sb.setLength(sb.length() - 1);
			sb.append(';');
		}
		sb.setLength(sb.length() - 1);
		sb.append(']');
		return sb.toString();
	}

	public SparseDoubleMatrix clone() {
		return new SparseDoubleMatrix(this);
	}

	public void clear() {
		map.clear();
	}

	public void close() {
		map.clear();
	}

	public void destroy() {
		map.destroy();
		map = null;
	}

	@Override
	public void write(DataOutput out) throws IOException {
		Varint.writeUnsignedVarInt(rows, out);
		Varint.writeUnsignedVarInt(columns, out);
		map.write(out);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		rows = Varint.readUnsignedVarInt(in);
		columns = Varint.readUnsignedVarInt(in);
		map = OrderedComplexDoubleCalculableMap.read(in);
	}

	public boolean equals(Object obj) {
		if (!(obj instanceof SparseDoubleMatrix)) {
			return false;
		}

		SparseDoubleMatrix sm = (SparseDoubleMatrix) obj;
		return rows == sm.rows && columns == sm.columns && map.equals(sm.map);
	}

	public static SparseDoubleMatrix read(DataInput in) throws IOException {
		SparseDoubleMatrix sm = new SparseDoubleMatrix();
		sm.readFields(in);
		return sm;
	}

}
