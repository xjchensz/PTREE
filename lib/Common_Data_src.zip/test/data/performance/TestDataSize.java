/**
 * 
 */
package test.data.performance;

import java.io.File;
import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;
import test.dataTestCase.AbstractDataTestCase;

import common.data.Data;
import common.data.instance.IInstance;
import common.data.io.SerializedDataWriter;

/**
 * @author xjc
 * 
 */
public class TestDataSize extends AbstractDataTestCase {

	public TestDataSize(IDataGenerator<? extends IInstance> dataGenerator,
			int index) {
		super(dataGenerator, index);
	}

	@Test
	public void testSize() throws Exception {
		testSize(new int[][] { { 100, 100 }, { 100, 1000 }, { 1000, 1000 },
				{ 10000, 10000 }, { 100000, 10000 } });
	}

	public void testSize(int[][] size) throws Exception {
		String title = null;
		File dir = new File("size/" + getIndex() + "/");
		switch (getIndex()) {
		case 0:
			title = "Double Instance";
			break;
		case 1:
			//
			title = "Int Instance";
			break;
		case 2:
			title = "Boolean Instance";
			break;
		case 3:
			//
			title = "Sparse Double Instance";
			break;
		case 4:
			//
			title = "Sparse Int Instance";
			break;
		case 5:
			//
			title = "Sparse Boolean Instance";
			break;
		}

		System.out.println(title);
		for (int i = 0; i < size.length; i++) {
			System.out.println(getResult(dir, size[i][0], size[i][1]));
		}
		clearDirectory(dir);
		System.out.println(title);
	}

	public String getResult(File dir, int numRows, int numColumns)
			throws Exception {
		long size = computeSize(dir, numColumns, numColumns);
		StringBuilder sb = new StringBuilder();

		sb.append(numRows).append(',').append(numColumns).append(',')
				.append(size / (1024 * 1024)).append('M');

		return sb.toString();
	}

	public long computeSize(File dir, int numRows, int numColumns)
			throws Exception {

		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", numRows, numColumns, new Random(10), true);

		clearDirectory(dir);

		SerializedDataWriter isdw = new SerializedDataWriter(data.toIterator());
		long size = 0;
		try {
			isdw.writeToDirectory(dir);
			size = computeSize(dir);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			isdw.close(true);
			clearDirectory(dir);
		}
		return size;
	}

	public static long computeSize(File dir) {
		File[] files = dir.listFiles();
		long size = 0;
		for (File file : files) {
			size += file.length();
		}
		return size;
	}
}
