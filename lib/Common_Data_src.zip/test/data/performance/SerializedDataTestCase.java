/**
 * Created by Xiaojun Chen at 2011-11-7
 * Shenzhen High Performance Data Mining Lab 
 */
package test.data.performance;

import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;

import common.data.Data;
import common.data.IDataIterator;
import common.data.instance.numeric.INumericInstance;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class SerializedDataTestCase extends AbstractNumericDataTestCase {

	public SerializedDataTestCase(
			IDataGenerator<? extends INumericInstance> dataGenerator) {
		super(dataGenerator);
	}

	@Test
	public void testEuclideanDistance() throws Exception {
		int dim = 10000;
		Data<? extends INumericInstance> d1 = getDataGenerator().createData(
				"data", "", 1000, dim, new Random(10), true);
		Data<? extends INumericInstance> d2 = getDataGenerator().createData(
				"data", "", 1000, dim, new Random(10), true);

		IDataIterator<? extends INumericInstance> dtr1 = d1.toIterator();
		IDataIterator<? extends INumericInstance> dtr2 = d2.toIterator();
		long start = System.currentTimeMillis();
		while (dtr1.hasNext()) {
			dtr1.next().euclideanDistance(dtr2.next());
		}
		System.out.println((System.currentTimeMillis() - start) * 1000 / dim
				+ " s/k.");
	}
}
