/**
 * 
 */
package test.data.performance;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;
import test.dataTestCase.AbstractDataTestCase;

import common.XMLUtils;
import common.data.instance.IInstance;
import common.data.meta.MetaData;
import common.json.JSONUtils;
import common.utils.SimpleByteArrayInputStream;
import common.utils.SimpleByteArrayOutputStream;

/**
 * @author xjchen
 * 
 */
public class TestMetaDataMemory extends AbstractDataTestCase {

	public TestMetaDataMemory(
			IDataGenerator<? extends IInstance> dataGenerator, int index) {
		super(dataGenerator, index);
	}

	@Test
	public void testMetaData() throws Exception {
		int[] nums = new int[] { 1000, 10000, 100000, 1000000 };
		for (int i = 0; i < nums.length; i++) {
			System.out.println("--------------------");
			System.out.println("The number of attributes: " + nums[i]);
			computeMemoryCost(nums[i]);
			System.out.println("--------------------");
		}
	}

	private void computeMemoryCost(int numAttributes) throws Exception {
		MetaData md1 = getDataGenerator().generateMetaData("data", "", 100,
				numAttributes, new Random(), true);
		String xml = md1.toXML();
		MetaData md2 = (MetaData) XMLUtils.load(xml);
		assertTrue(md1.equals(md2));
		// binary
		SimpleByteArrayOutputStream bo1 = new SimpleByteArrayOutputStream();
		DataOutputStream dos1 = new DataOutputStream(bo1);
		md1.write(dos1);
		SimpleByteArrayInputStream bis1 = new SimpleByteArrayInputStream(bo1);
		int length = bis1.available();
		System.out.println(length * 1000 / (1024 * numAttributes)
				+ "k/k attribute!");
		MetaData md3 = MetaData.readMetaData(new DataInputStream(bis1));
		assertTrue(md1.equals(md3));

		// json
		String jsonString = JSONUtils.toJSONOString(md1);
		System.out.println(jsonString.length() * 2 / length
				+ " times of binary object.");
		MetaData md4 = JSONUtils.parse(jsonString, MetaData.class);
		assertTrue(md1.equals(md4));
	}

}
