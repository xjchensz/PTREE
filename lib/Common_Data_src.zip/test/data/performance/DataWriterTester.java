/**
 * 
 */
package test.data.performance;

import java.io.File;
import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;
import test.dataTestCase.AbstractDataTestCase;

import common.data.Data;
import common.data.instance.IInstance;
import common.data.io.SerializedDataWriter;
import common.data.io.ZipSerializedDataWriter;
import common.data.io.indexed.IndexedSerializedDataInputStream;
import common.data.io.indexed.IndexedSerializedDataWriter;
import common.data.io.indexed.IndexedZipSerializedDataStreamWriter;
import common.data.io.indexed.IndexedZipSerializedDataWriter;

/**
 * @author xjchen
 * 
 */
public class DataWriterTester extends AbstractDataTestCase {

	/**
	 * @param dataGenerator
	 * @param index
	 */
	public DataWriterTester(IDataGenerator<? extends IInstance> dataGenerator,
			int index) {
		super(dataGenerator, index);
		// TODO Auto-generated constructor stub
	}

	@Test
	public void test() throws Exception {
		File dir = new File("serialized/" + getIndex() + "/");
		File file = new File("serialized/" + getIndex() + "/data.zip");
		if (!dir.exists()) {
			dir.mkdirs();
		}
		clearDirectory(dir);
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000000, 20, new Random(10), true);
		System.out.println("----------"
				+ getDataGenerator().getClass().getName() + "--------");
		long start = System.currentTimeMillis();
		// write serialized data
		SerializedDataWriter sdw = new SerializedDataWriter(data.toIterator());
		sdw.writeToDirectory(dir);
		sdw.close(true);
		clearDirectory(dir);
		System.out.println("serialized data: "
				+ (System.currentTimeMillis() - start) / 1000 + "s!");
		// write indexed serialized data
		start = System.currentTimeMillis();
		IndexedSerializedDataWriter isdw = new IndexedSerializedDataWriter(
				data.toIterator());
		isdw.writeToDirectory(dir);
		isdw.close(true);
		clearDirectory(dir);
		System.out.println("indexed serialized data: "
				+ (System.currentTimeMillis() - start) / 1000 + "s!");
		// write zip data
		start = System.currentTimeMillis();
		ZipSerializedDataWriter zsw = new ZipSerializedDataWriter(
				data.toIterator());
		zsw.writeToFile(file);
		zsw.close(true);
		System.out.println("zip serialized data: "
				+ (System.currentTimeMillis() - start) / 1000 + "s!");
		// write zip serialized data
		start = System.currentTimeMillis();
		IndexedZipSerializedDataWriter izsw = new IndexedZipSerializedDataWriter(
				data.toIterator());
		izsw.writeToFile(file);
		izsw.close(true);
		System.out.println("indexed zip serialized data (directly): "
				+ (System.currentTimeMillis() - start) / 1000 + "s!");
		file.delete();
		// write zip serialized data indirectly
		start = System.currentTimeMillis();
		IndexedSerializedDataWriter isdw1 = new IndexedSerializedDataWriter(
				data.toIterator());
		isdw1.writeToDirectory(dir);
		isdw1.close(true);

		IndexedZipSerializedDataStreamWriter nizsw = new IndexedZipSerializedDataStreamWriter(
				new IndexedSerializedDataInputStream(dir));
		nizsw.writeTo(file);
		nizsw.close(true);
		System.out.println("indexed zip serialized data (indirectly): "
				+ (System.currentTimeMillis() - start) / 1000 + "s!");

		clearDirectory(dir);
		clearDirectory(dir);
		data.clear();
	}
}
