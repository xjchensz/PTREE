/**
 * 
 */
package test.data.performance;

import java.io.DataOutputStream;
import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;
import test.dataTestCase.AbstractDataTestCase;

import common.data.instance.IInstance;
import common.data.meta.CompressedMetaData;
import common.data.meta.MetaData;
import common.json.JSONUtils;
import common.utils.SimpleByteArrayInputStream;
import common.utils.SimpleByteArrayOutputStream;

/**
 * @author xjchen
 * 
 */
public class TestCompressionMetaDataPerformance extends AbstractDataTestCase {

	public TestCompressionMetaDataPerformance(
			IDataGenerator<? extends IInstance> dataGenerator, int index) {
		super(dataGenerator, index);
	}

	@Test
	public void testMetaData() throws Exception {
		int[] nums = new int[] { 1000, 10000, 100000 };
		for (int i = 0; i < nums.length; i++) {
			System.out.println("--------------------");
			System.out.println("The number of attributes: " + nums[i]);
			computeMemoryCost(nums[i]);
			System.out.println("--------------------");
		}
	}

	private void computeMemoryCost(int numAttributes) throws Exception {
		MetaData md1 = getDataGenerator().generateMetaData("data", "", 100,
				numAttributes, new Random(), true);
		CompressedMetaData cmd1 = (CompressedMetaData) md1
				.toCompressedMetaData();

		System.out.print("XML: ");
		String xml1 = md1.toXML();
		String xml2 = cmd1.toXML();
		System.out.println(1000000 * xml2.length() / xml1.length() + "%0000");

		// binary
		System.out.print("Binary: ");
		// md
		SimpleByteArrayOutputStream bo1 = new SimpleByteArrayOutputStream();
		DataOutputStream dos1 = new DataOutputStream(bo1);
		md1.write(dos1);
		SimpleByteArrayInputStream bis1 = new SimpleByteArrayInputStream(bo1);
		// cmd
		SimpleByteArrayOutputStream bo2 = new SimpleByteArrayOutputStream();
		DataOutputStream dos2 = new DataOutputStream(bo2);
		cmd1.write(dos2);
		SimpleByteArrayInputStream bis2 = new SimpleByteArrayInputStream(bo2);
		System.out.println(1000000 * bis2.available() / bis1.available()
				+ "%0000");
		bis1.close();
		bis2.close();

		// json
		System.out.print("Json: ");
		String jsonString1 = JSONUtils.toJSONOString(md1);
		String jsonString2 = JSONUtils.toJSONOString(cmd1);
		System.out.println(1000000 * jsonString2.length()
				/ jsonString1.length() + "%0000");

	}

}
