package test.data.matrix;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;

import common.matrix.SparseDoubleMatrix;
import common.utils.SimpleByteArrayInputStream;
import common.utils.SimpleByteArrayOutputStream;
import junit.framework.TestCase;

public class TestSparseDoubleMatrix extends TestCase {

	public static void test1() {
		int rows = 10;
		SparseDoubleMatrix sdm = new SparseDoubleMatrix(rows, rows);
		sdm.setEmptyValue(0);
		sdm.setValue(0, 0, 1);
		sdm.setValue(2, 9, 18);
		sdm.setValue(1, 9, 9);
		sdm.setValue(2, 4, 8);
		sdm.setValue(2, 6, 12);
		sdm.setValue(4, 0, 8);
		sdm.setValue(3, 9, 27);
		sdm.setValue(3, 0, 3);
		sdm.setValue(3, 2, 6);
		sdm.setValue(3, 8, 24);
		sdm.setValue(5, 0, 8);

		for (int i = 0; i < rows; i++) {
			System.out.println(i + " row: " + Arrays.toString(sdm.getColumnForRowValues(i)));
		}

		for (int i = 0; i < rows; i++) {
			System.out.println(i + " column: " + Arrays.toString(sdm.getRowForColumnValues(i)));
		}
		sdm.multiply(0.5);
		sdm.multiply(2);
	}

	public void test2() {
		SparseDoubleMatrix A = new SparseDoubleMatrix(3, 3);
		A.setValue(0, 0, 1);
		A.setValue(0, 1, 2);
		A.setValue(0, 2, 3);
		A.setValue(1, 0, 3);
		A.setValue(1, 1, 1);
		A.setValue(1, 2, 2);
		A.setValue(2, 0, 2);
		A.setValue(2, 1, 3);
		A.setValue(2, 2, 1);
		System.out.println("A: " + A.maxtrixFormat());
		A.LP();
		System.out.println("LP: " + A.maxtrixFormat());
	}

	public void test3() {
		SparseDoubleMatrix A = new SparseDoubleMatrix(3, 3);
		A.setValue(0, 0, 1);
		A.setValue(0, 1, 2);
		A.setValue(0, 2, 0);
		A.setValue(1, 0, 3);
		A.setValue(1, 1, 1);
		A.setValue(1, 2, 2);
		A.setValue(2, 0, 2);
		A.setValue(2, 1, 0.5);
		A.setValue(2, 2, 2);
		int[] minIndex = A.min();
		assertEquals(0, minIndex[0]);
		assertEquals(2, minIndex[1]);
		A.removeAllRows(2);
		assertEquals(A.getEmptyValue(), A.getValue(2, 0));
		assertEquals(A.getEmptyValue(), A.getValue(2, 1));
		assertEquals(A.getEmptyValue(), A.getValue(2, 2));
		A.removeAllColumns(1);
		assertEquals(A.getEmptyValue(), A.getValue(0, 1));
		assertEquals(A.getEmptyValue(), A.getValue(1, 1));
		assertEquals(A.getEmptyValue(), A.getValue(2, 1));
		assertEquals(4, A.size());
	}

	public void test4() throws IOException {
		SparseDoubleMatrix A = new SparseDoubleMatrix(3, 3);

		A.setValue(0, 1, 2);
		A.setValue(1, 2, 0);
		A.setValue(2, 2, 2);

		// write data
		SimpleByteArrayOutputStream bo = new SimpleByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bo);
		A.write(dos);
		dos.close();

		// read data
		SimpleByteArrayInputStream bis = new SimpleByteArrayInputStream(bo);
		DataInputStream dis = new DataInputStream(bis);
		SparseDoubleMatrix B = SparseDoubleMatrix.read(dis);
		dis.close();
		assertTrue(A.equals(B));
	}

	public void test5() {
		SparseDoubleMatrix A = new SparseDoubleMatrix(3, 3);

		A.setValue(0, 1, 2);
		A.setValue(1, 2, 0);
		A.setValue(2, 2, 2);
		int[] minIndex = A.min();
		assertEquals(1, minIndex[0]);
		assertEquals(2, minIndex[1]);
		int[] columns = A.getColumnForRowValues(0);
		assertEquals(1, columns[0]);
		columns = A.getColumnForRowValues(1);
		assertEquals(2, columns[0]);
		int[] rows = A.getRowForColumnValues(2);
		assertEquals(1, rows[0]);
		assertEquals(2, rows[1]);
	}
}
