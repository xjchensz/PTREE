package test.data.matrix;

import java.io.IOException;
import java.util.Arrays;

import junit.framework.TestCase;

import common.graph.DirectedGraph;
import common.graph.Gabow;
import common.graph.IDirectedGraph;
import common.graph.UnDirectedGraph;

public class TestGabow extends TestCase {

	public void testGabow1() throws IOException {

		// create graph
		int numNodes = 10;
		IDirectedGraph sdm = new DirectedGraph(numNodes);

		sdm.addConnection(0, 1, 1);
		sdm.addConnection(1, 2, 1);
		sdm.addConnection(2, 0, 1);
		sdm.addConnection(3, 0, 1);
		sdm.addConnection(3, 5, 1);
		sdm.addConnection(5, 2, 1);
		sdm.addConnection(4, 3, 1);
		sdm.addConnection(4, 5, 1);
		sdm.addConnection(6, 4, 1);
		sdm.addConnection(6, 7, 1);
		sdm.addConnection(8, 9, 1);

		Gabow gabow = new Gabow(sdm);
		gabow.run();
		int[][] to = gabow.getTopOrderNodes();
		for (int i = 0; i < to.length; i++) {
			System.out.println(Arrays.toString(to[i]));
		}
		gabow.close();
	}

	public void testGabow2() throws IOException {

		// create graph
		int numNodes = 10;
		IDirectedGraph sdm = new UnDirectedGraph(numNodes);

		sdm.addConnection(0, 1, 1);
		sdm.addConnection(1, 2, 1);
		sdm.addConnection(2, 0, 1);
		sdm.addConnection(3, 0, 1);
		sdm.addConnection(3, 5, 1);
		sdm.addConnection(5, 2, 1);
		sdm.addConnection(4, 3, 1);
		sdm.addConnection(4, 5, 1);
		sdm.addConnection(6, 4, 1);
		sdm.addConnection(6, 7, 1);
		sdm.addConnection(8, 9, 1);

		Gabow gabow = new Gabow(sdm);
		gabow.run();
		int[][] to = gabow.getTopOrderNodes();
		for (int i = 0; i < to.length; i++) {
			System.out.println(Arrays.toString(to[i]));
		}
		gabow.close();
	}

}
