/**
 * @author Xiaojun Chen
 * @email xjchen@szu.edu.cn
 * 2016��2��10��
 */
package test.data.matrix;

import java.util.Arrays;

import common.matrix.EigSolver;
import common.matrix.SparseDoubleMatrix;
import junit.framework.TestCase;

/**
 * @author Xiaojun Chen
 *
 */
public class TestEig extends TestCase {

	public void testEigenvaluesCircul() throws Exception { // from
		// http://www.mathworks.com/help/matlab/ref/eig.html
		SparseDoubleMatrix A = new SparseDoubleMatrix(3, 3);
		A.setValue(0, 0, 1);
		A.setValue(0, 1, 2);
		A.setValue(0, 2, 3);
		A.setValue(1, 0, 3);
		A.setValue(1, 1, 1);
		A.setValue(1, 2, 2);
		A.setValue(2, 0, 2);
		A.setValue(2, 1, 3);
		A.setValue(2, 2, 1);
		double[] d = new double[3];
		double[][] vec = new double[3][3];
		EigSolver.eig(A, d, vec);
		System.out.println(Arrays.toString(d));
	}

}
