/**
 * 
 */
package test.data.distance;

import java.util.Random;

import common.data.distance.EuclideanDistanceMeasure;
import common.data.instance.numeric.sparse.SparseDoubleInstance;
import common.data.meta.MetaData;
import junit.framework.TestCase;
import test.dataGenerator.SparseDoubleInstanceGenerator;

/**
 * @author Great
 *
 */
public class TestEuclideanDistance extends TestCase {

	public void testDistance() {
		SparseDoubleInstanceGenerator sg = new SparseDoubleInstanceGenerator();
		MetaData md = sg.generateMetaData("a", "a", 100, 1000, new Random(), true);
		EuclideanDistanceMeasure distance = EuclideanDistanceMeasure.getInstance();

		SparseDoubleInstance sdi1 = new SparseDoubleInstance(0, md);
		sdi1.setValue(0, 10);
		SparseDoubleInstance sdi = new SparseDoubleInstance(0, md);
		sdi.setValue(1, 20);
		assertEquals(Math.sqrt(500), distance.distance(sdi, sdi1));

		sdi = new SparseDoubleInstance(2, md);
		sdi.setValue(0, 20);
		sdi.setValue(1, 20);
		assertEquals(Math.sqrt(500), distance.distance(sdi, sdi1));

		sdi = new SparseDoubleInstance(3, md);
		sdi.setValue(0, 10);
		assertEquals(0.0, distance.distance(sdi, sdi1));

		sdi = new SparseDoubleInstance(4, md);
		sdi.setValue(0, 10);
		sdi.setValue(5, 10);
		assertEquals(10.0, distance.distance(sdi, sdi1));
	}

}
