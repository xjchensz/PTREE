package test.data.distance;

import static org.junit.Assert.assertEquals;

import java.util.Random;

import org.junit.Test;

import test.dataGenerator.SparseDoubleInstanceGenerator;

import common.data.distance.AngularDistanceMeasure;
import common.data.instance.numeric.sparse.SparseDoubleInstance;
import common.data.meta.MetaData;

public class TestAngularDistance {

	@Test
	public void test() {
		SparseDoubleInstanceGenerator sg = new SparseDoubleInstanceGenerator();
		MetaData md = sg.generateMetaData("a", "a", 100, 1000, new Random(),
				true);
		AngularDistanceMeasure distance = AngularDistanceMeasure.getInstance();

		SparseDoubleInstance sdi1 = new SparseDoubleInstance(0, md);
		sdi1.setValue(0, 10);
		SparseDoubleInstance sdi = new SparseDoubleInstance(0, md);
		sdi.setValue(1, 20);
		assertEquals(1, distance.distance(sdi, sdi1), 0);

		sdi = new SparseDoubleInstance(2, md);
		sdi.setValue(0, 20);
		sdi.setValue(1, 20);
		assertEquals(0.5, distance.distance(sdi, sdi1), 0.001);

		sdi = new SparseDoubleInstance(3, md);
		sdi.setValue(0, 10);
		sdi.setValue(1, 5.7735);
		assertEquals(0.333, distance.distance(sdi, sdi1), 0.001);

	}

}
