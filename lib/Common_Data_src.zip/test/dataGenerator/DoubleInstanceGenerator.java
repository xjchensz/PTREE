/**
 * Created by Xiaojun Chen at 2011-9-2
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataGenerator;

import java.io.File;
import java.util.Random;

import common.data.Data;
import common.data.IDataIterator;
import common.data.instance.numeric.DenseDoubleInstance;
import common.data.instance.numeric.IDoubleInstance;
import common.data.io.ZipSerializedDataWriter;
import common.data.meta.IAttribute;
import common.data.meta.MetaData;
import common.data.meta.NominalAttribute;
import common.data.meta.NumericAttribute;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class DoubleInstanceGenerator implements IDataGenerator<IDoubleInstance> {

	public Data<IDoubleInstance> createData(String id, String name,
			int numInstances, int numAttributes, Random random,
			boolean hasLabels) {
		return new Data<IDoubleInstance>(createDataIterator(id, name,
				numInstances, numAttributes, random, hasLabels));
	}

	public IDataIterator<IDoubleInstance> createDataIterator(String id,
			String name, final int numInstances, final int numAttributes,
			final Random random, final boolean hasLabels) {
		final MetaData md = generateMetaData(id, name, numInstances,
				numAttributes, random, hasLabels);
		final int numClasses = md.numLabels();

		final long[] seeds = new long[numInstances];
		for (int i = 0; i < seeds.length; i++) {
			seeds[i] = random.nextLong();
		}

		return new IDataIterator<IDoubleInstance>() {
			int index = 0;

			@Override
			public MetaData getMetaData() {
				return md;
			}

			@Override
			public boolean hasNext() {
				return index < numInstances;
			}

			@Override
			public IDoubleInstance next() {
				random.setSeed(seeds[index]);
				double[] values = new double[numAttributes];
				for (int j = 0; j < values.length; j++) {
					values[j] = random.nextDouble();
				}
				if (hasLabels) {
					values[values.length - 1] = random.nextInt(numClasses);
				}

				return new DenseDoubleInstance(index++, md, values);
			}

			@Override
			public void remove() {

			}

			public void close() {

			}

			@Override
			public void reset() {
				index = 0;
			}

			@Override
			public boolean isClosed() {
				return false;
			}
		};
	}

	public MetaData generateMetaData(String id, String name, int numInstances,
			int numAttributes, Random random, boolean hasLabels) {
		IAttribute[] attrs = new IAttribute[numAttributes];
		int numClasses = random.nextInt(8) + 2;
		for (int i = 0; i < attrs.length; i++) {
			attrs[i] = new NumericAttribute(i + "", "Attr" + (i + 1) + "");
		}
		if (hasLabels) {
			String[] classes = new String[numClasses];
			for (int i = 0; i < classes.length; i++) {
				classes[i] = "c" + i;
			}
			attrs[numAttributes - 1] = new NominalAttribute((numAttributes - 1)
					+ "", "Class", classes);
		}

		if (hasLabels) {
			return new MetaData(id, name, attrs, numAttributes - 1,
					numInstances);
		} else {
			return new MetaData(id, name, attrs, -1, numInstances);
		}
	}

	public static void generateData(String id, String name, int numInstances,
			int numVariables, boolean hasLabel, String directory)
			throws Exception {
		IDataIterator<IDoubleInstance> ditr = new DoubleInstanceGenerator()
				.createDataIterator(id, name, numInstances, numVariables,
						new Random(), hasLabel);
		DataGeneratorUtils.writeData(ditr, new File(directory));
	}

	public static void generateZipData(String id, String name,
			int numInstances, int numVariables, boolean hasLabels, String file)
			throws Exception {
		IDataIterator<IDoubleInstance> ditr = new DoubleInstanceGenerator()
				.createDataIterator(id, name, numInstances, numVariables,
						new Random(), hasLabels);

		ZipSerializedDataWriter writer = new ZipSerializedDataWriter(ditr);
		writer.writeToFile(new File(file));
		writer.close(true);
	}

	public static void main(String[] args) {
		try {
			int numInstances = 100;
			int numVariables = 5;
			boolean hasLabel = true;
			String file = "serialized/data";
			generateData("1", "", numInstances, numVariables, hasLabel, file);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
