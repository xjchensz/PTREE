/**
 * Created by Xiaojun Chen at 2012-7-10
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataGenerator;

import java.util.Random;

import common.data.Data;
import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.data.meta.MetaData;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public interface IDataGenerator<T extends IInstance> {

	public Data<T> createData(String id, String name, int numInstances,
			int numAttributes, Random random, boolean hasLabels);

	public IDataIterator<T> createDataIterator(String id, String name,
			int numInstances, int numAttributes, Random random,
			boolean hasLabels);

	public MetaData generateMetaData(String id, String name, int numInstances,
			int numAttributes, Random random, boolean hasLabels);

}
