package test.dataGenerator;

import java.io.File;
import java.util.Random;

public class SampleDataGenerater {

	public static void generateDenseIntZipData(String id, String name,
			int numInstances, int numAttributes, String file) throws Exception {
		IntInstanceGenerator dg = new IntInstanceGenerator();
		DataGeneratorUtils.writeIndexedZipFile(dg.createDataIterator(id, name,
				numInstances, numAttributes, new Random(), true),
				new File(file));
	}

	public static void generateDenseIntFileData(String id, String name,
			int numInstances, int numAttributes, String dir) throws Exception {
		IntInstanceGenerator dg = new IntInstanceGenerator();
		DataGeneratorUtils
				.writeIndexedData(dg.createDataIterator(id, name, numInstances,
						numAttributes, new Random(), true), new File(dir));
	}

	public static void generateBigData() throws Exception {
		String id = "data1";
		String name = "big";
		int numInstances = 20000;
		int numAttributes = 1000;
		String file = "big.zip";
		String dir = "big";
		generateDenseIntZipData(id, name, numInstances, numAttributes, file);
		generateDenseIntFileData(id, name, numInstances, numAttributes, dir);
	}

	public static void generateSmallData() throws Exception {
		String id = "data2";
		String name = "small";
		int numInstances = 1000;
		int numAttributes = 100;
		String file = "small.zip";
		String dir = "small";
		generateDenseIntZipData(id, name, numInstances, numAttributes, file);
		generateDenseIntFileData(id, name, numInstances, numAttributes, dir);
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		generateBigData();
		generateSmallData();
	}

}
