/**
 * Created by Xiaojun Chen at 2012-7-10
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataGenerator;

import java.io.File;

import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.data.io.SerializedDataWriter;
import common.data.io.ZipSerializedDataWriter;
import common.data.io.indexed.IndexedSerializedDataWriter;
import common.data.io.indexed.IndexedZipSerializedDataWriter;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class DataGeneratorUtils {

	public static void writeData(IDataIterator<? extends IInstance> data,
			File dir) throws Exception {
		SerializedDataWriter writer = new SerializedDataWriter(data);
		if (!dir.exists()) {
			dir.mkdirs();
		} else {
			File[] files = dir.listFiles();
			for (File f : files) {
				f.delete();
			}
		}
		writer.writeToDirectory(dir);
		writer.close(true);
	}

	public static void writeIndexedData(
			IDataIterator<? extends IInstance> data, File dir) throws Exception {
		IndexedSerializedDataWriter writer = new IndexedSerializedDataWriter(
				data);
		if (!dir.exists()) {
			dir.mkdirs();
		} else {
			File[] files = dir.listFiles();
			for (File f : files) {
				f.delete();
			}
		}
		writer.writeToDirectory(dir);
		writer.close(true);
	}

	public static void writeZipFile(IDataIterator<? extends IInstance> data,
			File zipFile) throws Exception {
		ZipSerializedDataWriter writer = new ZipSerializedDataWriter(data);
		writer.writeToFile(zipFile);
		writer.close(true);
	}

	public static void writeIndexedZipFile(
			IDataIterator<? extends IInstance> data, File zipFile)
			throws Exception {
		IndexedZipSerializedDataWriter writer = new IndexedZipSerializedDataWriter(
				data);
		writer.writeToFile(zipFile);
		writer.close(true);
	}

}
