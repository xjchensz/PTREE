/**
 * Created by Xiaojun Chen at 2011-9-2
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataGenerator;

import java.util.Random;

import common.data.Data;
import common.data.IDataIterator;
import common.data.instance.numeric.sparse.SparseDoubleInstance;
import common.data.meta.DataType;
import common.data.meta.IAttribute;
import common.data.meta.MetaData;
import common.data.meta.NominalAttribute;
import common.data.meta.NumericAttribute;
import common.utils.RandomUtils;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class SparseDoubleInstanceGenerator implements
		IDataGenerator<SparseDoubleInstance> {

	public Data<SparseDoubleInstance> createData(String id, String name,
			int numInstances, int numAttributes, Random random, boolean hasLabel) {
		return new Data<SparseDoubleInstance>(createDataIterator(id, name,
				numInstances, numAttributes, random, hasLabel));
	}

	public IDataIterator<SparseDoubleInstance> createDataIterator(String id,
			String name, final int numInstances, final int numAttributes,
			final Random random, final boolean hasLabel) {
		double sparseDegree = 0;
		if (!hasLabel) {
			sparseDegree = (double) 1 / numAttributes;
		} else {
			sparseDegree = (double) 1 / (numAttributes - 1);
		}
		sparseDegree += (1 - sparseDegree) * random.nextDouble();
		return createDataIterator(id, name, numInstances, numAttributes,
				random, hasLabel, sparseDegree);
	}

	public static IDataIterator<SparseDoubleInstance> createDataIterator(
			String id, String name, final int numInstances,
			final int numAttributes, final Random random,
			final boolean hasLabel, double sparseDegree) {
		if (!hasLabel) {
			if (sparseDegree < (double) 1 / numAttributes) {
				throw new IllegalArgumentException(
						"sparseDegree should be more than " + (double) 1
								/ numAttributes);
			}
		} else {
			if (sparseDegree < (double) 1 / (numAttributes - 1)) {
				throw new IllegalArgumentException(
						"sparseDegree should be more than " + (double) 1
								/ (numAttributes - 1));
			}
		}

		// assign
		int numFilledElements = (int) (numInstances * numAttributes * sparseDegree);
		if (hasLabel) {
			numFilledElements = (int) (numInstances * (numAttributes - 1) * sparseDegree);
		}
		numFilledElements = numFilledElements < numInstances ? numInstances
				: numFilledElements;
		final int[] numElementsOfInstance = RandomUtils.randomNumberAssign(
				numFilledElements, numInstances, 1, hasLabel ? numAttributes
						: numAttributes + 1, random);

		final MetaData md = new SparseDoubleInstanceGenerator()
				.generateMetaData(id, name, numInstances, numAttributes,
						random, hasLabel);
		final int numClasses = md.numLabels();

		final long[] seeds = new long[numInstances];
		for (int i = 0; i < seeds.length; i++) {
			seeds[i] = random.nextLong();
		}

		return new IDataIterator<SparseDoubleInstance>() {
			int index = 0;

			@Override
			public MetaData getMetaData() {
				return md;
			}

			@Override
			public boolean hasNext() {
				return index < numInstances;
			}

			@Override
			public SparseDoubleInstance next() {
				random.setSeed(seeds[index]);
				if (!hasLabel) {
					int[] attrs = RandomUtils.nonRepeatSample(0, numAttributes,
							1, numElementsOfInstance[index] - 1, random);

					SparseDoubleInstance si = new SparseDoubleInstance(index,
							md);
					if (index < numAttributes) {
						si.setValue(index, random.nextDouble());
					} else {
						si.setValue(random.nextInt(numAttributes),
								random.nextDouble());
					}
					for (int i = 0; i < attrs.length; i++) {
						si.setValue(attrs[i], random.nextDouble());
					}
					index++;
					return si;
				} else {
					int[] attrs = RandomUtils.nonRepeatSample(0,
							numAttributes - 1, 1,
							numElementsOfInstance[index] - 1, random);

					SparseDoubleInstance si = new SparseDoubleInstance(index,
							md);
					if (index < numAttributes - 1) {
						si.setValue(index, random.nextDouble());
					} else {
						si.setValue(random.nextInt(numAttributes - 1),
								random.nextDouble());
					}
					for (int i = 0; i < attrs.length; i++) {
						si.setValue(attrs[i], random.nextDouble());
					}
					// class label
					si.setValue(numAttributes - 1, random.nextInt(numClasses));
					index++;
					return si;
				}
			}

			@Override
			public void remove() {

			}

			public void close() {

			}

			@Override
			public void reset() {
				index = 0;
			}

			@Override
			public boolean isClosed() {
				return false;
			}
		};
	}

	public MetaData generateMetaData(String id, String name, int numInstances,
			int numAttributes, Random random, boolean hasLabel) {
		IAttribute[] attrs = new IAttribute[numAttributes];
		// 2-10 classes
		int numClasses = random.nextInt(8) + 2;
		for (int i = 0; i < attrs.length; i++) {
			attrs[i] = new NumericAttribute(i + "", "Attr" + (i + 1) + "");
		}
		if (hasLabel) {
			String[] classes = new String[numClasses];
			for (int i = 0; i < classes.length; i++) {
				classes[i] = "c" + i;
			}
			attrs[numAttributes - 1] = new NominalAttribute((numAttributes - 1)
					+ "", "Class", classes);
		}

		if (hasLabel) {
			return new MetaData(id, name, attrs, numAttributes - 1,
					numInstances, DataType.SPARSE_DOUBLE);
		} else {
			return new MetaData(id, name, attrs, -1, numInstances,
					DataType.SPARSE_DOUBLE);
		}
	}

}
