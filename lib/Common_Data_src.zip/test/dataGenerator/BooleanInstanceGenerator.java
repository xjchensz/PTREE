/**
 * Created by Xiaojun Chen at 2011-9-2
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataGenerator;

import java.util.Random;

import common.data.Data;
import common.data.IDataIterator;
import common.data.instance.numeric.DenseBooleanInstance;
import common.data.instance.numeric.IBooleanInstance;
import common.data.meta.BooleanAttribute;
import common.data.meta.DataType;
import common.data.meta.IAttribute;
import common.data.meta.MetaData;
import common.data.meta.NominalAttribute;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class BooleanInstanceGenerator implements
		IDataGenerator<IBooleanInstance> {

	public Data<IBooleanInstance> createData(String id, String name,
			int numInstances, int numAttributes, Random random,
			boolean hasLabels) {
		return new Data<IBooleanInstance>(createDataIterator(id, name,
				numInstances, numAttributes, random, hasLabels));
	}

	public IDataIterator<IBooleanInstance> createDataIterator(String id,
			String name, final int numInstances, final int numAttributes,
			final Random random, final boolean hasLabels) {
		final MetaData md = generateMetaData(id, name, numInstances,
				numAttributes, random, hasLabels);
		final int numClasses = md.numLabels();

		final long[] seeds = new long[numInstances];
		for (int i = 0; i < seeds.length; i++) {
			seeds[i] = random.nextLong();
		}

		return new IDataIterator<IBooleanInstance>() {
			int index = 0;

			@Override
			public MetaData getMetaData() {
				return md;
			}

			@Override
			public boolean hasNext() {
				return index < numInstances;
			}

			@Override
			public IBooleanInstance next() {
				random.setSeed(seeds[index]);
				int booleanAttributes = numAttributes;
				if (hasLabels) {
					booleanAttributes = numAttributes - 1;
				}
				boolean[] values = new boolean[booleanAttributes];

				for (int j = 0; j < values.length; j++) {
					values[j] = random.nextBoolean();
				}

				if (!hasLabels) {
					return new DenseBooleanInstance(index++, md, values);
				} else {
					return new DenseBooleanInstance(index++, md, values,
							random.nextInt(numClasses));
				}
			}

			@Override
			public void remove() {

			}

			public void close() {

			}

			@Override
			public void reset() {
				index = 0;
			}

			@Override
			public boolean isClosed() {
				return false;
			}

		};
	}

	public MetaData generateMetaData(String id, String name, int numInstances,
			int numAttributes, Random random, boolean hasLabels) {
		IAttribute[] attrs = new IAttribute[numAttributes];
		int numClasses = random.nextInt(8) + 2;
		for (int i = 0; i < attrs.length; i++) {
			attrs[i] = new BooleanAttribute(i + "", "Attr" + (i + 1) + "");
		}
		if (hasLabels) {
			String[] classes = new String[numClasses];
			for (int i = 0; i < classes.length; i++) {
				classes[i] = "c" + i;
			}
			attrs[numAttributes - 1] = new NominalAttribute((numAttributes - 1)
					+ "", "Class", classes);
		}

		if (hasLabels) {
			return new MetaData(id, name, attrs, numAttributes - 1,
					numInstances, DataType.DENSE_BOOLEAN);
		} else {
			return new MetaData(id, name, attrs, -1, numInstances,
					DataType.DENSE_BOOLEAN);
		}
	}

}
