/**
 * Created by Xiaojun Chen at 2011-9-2
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataGenerator;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import common.data.IDataIterator;
import common.data.instance.numeric.DenseDoubleInstance;
import common.data.instance.numeric.INumericInstance;
import common.data.io.SerializedDataWriter;
import common.data.meta.NominalAttribute;
import common.data.meta.IAttribute;
import common.data.meta.MetaData;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class CategoryDataGenerator {

	public static IDataIterator<INumericInstance> createDataIterator(String id,
			String name, final int numInstances, final int numAttributes,
			final Random random, final boolean hasLabel) {
		final int Classes[] = new int[numAttributes];
		final MetaData md = getMetaData(id, name, numInstances, numAttributes,
				random, Classes);

		return new IDataIterator<INumericInstance>() {
			int index = 0;

			@Override
			public MetaData getMetaData() {
				return md;
			}

			@Override
			public boolean hasNext() {
				return index < numInstances;
			}

			@Override
			public INumericInstance next() {

				double[] values = new double[numAttributes];
				for (int j = 0; j < values.length; j++) {
					values[j] = random.nextInt(Classes[j]);
				}

				return new DenseDoubleInstance(index++, md, values);
			}

			@Override
			public void remove() {

			}

			public void close() {

			}

			@Override
			public void reset() {
				index = 0;
			}

			@Override
			public boolean isClosed() {
				return false;
			}
		};
	}

	private static MetaData getMetaData(String id, String name,
			int numInstances, int numAttributes, Random random, int[] classes2) {
		IAttribute[] attrs = new IAttribute[numAttributes];
		// 2-10 classes
		int numClasses;
		for (int i = 0; i < attrs.length; i++) {
			numClasses = random.nextInt(8) + 2;
			classes2[i] = numClasses;
			String[] classes = new String[numClasses];
			for (int j = 0; j < classes.length; j++) {
				classes[j] = "c" + j;
			}
			attrs[i] = new NominalAttribute(i + "", i + "", classes);
		}
		return new MetaData(id, name, attrs, -1, numInstances);
	}

	public static void writeSerializedData(String id, String name,
			int numInstances, int numVariables) throws IOException {
		IDataIterator<INumericInstance> ditr = CategoryDataGenerator
				.createDataIterator(id, name, numInstances, numVariables,
						new Random(), true);
		new SerializedDataWriter(ditr).writeToDirectory(new File(
				"serialized/cdata"));
	}

	public static void main(String[] args) {
		// testDataUtils();
		try {
			int numInstances = 10;
			int numVariables = 928;
			writeSerializedData("1", "", numInstances, numVariables);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
