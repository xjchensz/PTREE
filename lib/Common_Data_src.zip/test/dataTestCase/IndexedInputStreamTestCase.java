/**
 * Created by Xiaojun Chen at 2012-3-27
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataTestCase;

import java.io.File;
import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;

import common.data.Data;
import common.data.IndexedInputStream;
import common.data.instance.IInstance;
import common.data.io.SerializedDataStreamReader;
import common.data.io.indexed.IndexedSerializedDataWriter;
import common.data.io.indexed.IndexedZipSerializedDataWriter;
import common.data.io.indexed.SerializedDataFileIndexedInputStream;
import common.data.io.indexed.UnZipSerializedDataFileIndexedInputStream;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class IndexedInputStreamTestCase extends AbstractDataTestCase {

	public IndexedInputStreamTestCase(
			IDataGenerator<? extends IInstance> dataGenerator, int index) {
		super(dataGenerator, index);
	}

	@Test
	public void testIndexedFileInputStream() throws Exception {
		File dir = new File("serialized/data");
		clearDirectory(dir);
		// write data
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 10, new Random(10), true);
		IndexedSerializedDataWriter sdw = new IndexedSerializedDataWriter(
				data.toIterator());
		sdw.writeToDirectory(dir);
		sdw.close(true);
		// test
		SerializedDataFileIndexedInputStream ifs = new SerializedDataFileIndexedInputStream(
				dir);
		testIndexedFileInputStream(data, ifs, 0, 10);
		testIndexedFileInputStream(data, ifs, 0, 200);
		testIndexedFileInputStream(data, ifs, 100, 200);
		testIndexedFileInputStream(data, ifs, 111, 222);
		testIndexedFileInputStream(data, ifs, 777, 899);
		deleteDirectory(dir);
	}

	@Test
	public void testZipIndexedFileInputStream() throws Exception {
		File file = new File("serialized/data.zip");
		clearFile(file);
		// write data
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 1000, new Random(10), true);
		IndexedZipSerializedDataWriter zsdw = new IndexedZipSerializedDataWriter(
				data.toIterator());
		zsdw.writeToFile(file);
		zsdw.close(true);

		// test
		UnZipSerializedDataFileIndexedInputStream ifs = new UnZipSerializedDataFileIndexedInputStream(
				file);
		testIndexedFileInputStream(data, ifs, 0, 10);
		testIndexedFileInputStream(data, ifs, 0, 200);
		testIndexedFileInputStream(data, ifs, 100, 200);
		testIndexedFileInputStream(data, ifs, 111, 222);
		testIndexedFileInputStream(data, ifs, 777, 899);
		file.delete();
		deleteFile(file);
	}

	private void testIndexedFileInputStream(Data<? extends IInstance> data,
			IndexedInputStream iis, int rowStart, int rowEnd) throws Exception {
		SerializedDataStreamReader<IInstance> sd = new SerializedDataStreamReader<IInstance>(
				iis.subInputStream(rowStart, rowEnd));
		for (int i = rowStart; i < rowEnd; i++) {
			assertEquals(data.get(i), sd.next());
		}
	}

}
