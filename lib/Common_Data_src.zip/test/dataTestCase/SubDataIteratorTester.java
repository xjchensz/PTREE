/**
 * Created by Xiaojun Chen at 2012-3-29
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataTestCase;

import java.io.IOException;
import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;

import common.data.Data;
import common.data.SubDataIterator;
import common.data.instance.IInstance;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class SubDataIteratorTester extends AbstractDataTestCase {

	public SubDataIteratorTester(
			IDataGenerator<? extends IInstance> dataGenerator, int index) {
		super(dataGenerator, index);
	}

	@Test
	public void testSubDataIterator() throws ArrayIndexOutOfBoundsException,
			IOException, Exception {
		int numInstances = 100;
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", numInstances, 10, new Random(10), true);
		int rowStart = numInstances / 4;
		int rowEnd = numInstances / 2;

		SubDataIterator<IInstance> di = new SubDataIterator<IInstance>(
				data.toIterator(), rowStart, rowEnd, false);
		for (int i = rowStart; i < rowEnd; i++) {
			assertEquals(data.get(i), di.next());
		}
	}
}
