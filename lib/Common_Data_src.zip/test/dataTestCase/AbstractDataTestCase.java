/**
 * Created by Xiaojun Chen at 2012-6-15
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataTestCase;

import java.io.File;
import java.util.Arrays;
import java.util.Collection;

import junit.framework.TestCase;

import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import test.dataGenerator.BooleanInstanceGenerator;
import test.dataGenerator.DoubleInstanceGenerator;
import test.dataGenerator.IDataGenerator;
import test.dataGenerator.IntInstanceGenerator;
import test.dataGenerator.SparseBooleanInstanceGenerator;
import test.dataGenerator.SparseDoubleInstanceGenerator;
import test.dataGenerator.SparseIntInstanceGenerator;

import common.data.IDataIterator;
import common.data.instance.IInstance;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
@RunWith(value = Parameterized.class)
public abstract class AbstractDataTestCase extends TestCase {

	private IDataGenerator<? extends IInstance> m_DataGenerator;
	private int index;

	/**
	 * 
	 */
	public AbstractDataTestCase(
			IDataGenerator<? extends IInstance> dataGenerator, int index) {
		m_DataGenerator = dataGenerator;
		this.index = index;
	}

	@Parameters
	public static Collection<Object[]> data() {
		Object[][] data = new Object[][] {
				new Object[] { new DoubleInstanceGenerator(), 0 },
				new Object[] { new IntInstanceGenerator(), 1 },
				new Object[] { new BooleanInstanceGenerator(), 2 },
				new Object[] { new SparseDoubleInstanceGenerator(), 3 },
				new Object[] { new SparseIntInstanceGenerator(), 4 },
				new Object[] { new SparseBooleanInstanceGenerator(), 5 }, };
		return Arrays.asList(data);
	}

	public IDataGenerator<? extends IInstance> getDataGenerator() {
		return m_DataGenerator;
	}

	public int getIndex() {
		return index;
	}

	public static void clearFile(File file) {
		if (file.exists()) {
			file.delete();
		} else {
			if (!file.getParentFile().exists()) {
				file.getParentFile().mkdirs();
			}
		}
	}

	public static void deleteFile(File file) {
		if (file.exists()) {
			file.delete();
		}
		if (!file.getParentFile().exists()) {
			file.getParentFile().delete();
		}
	}

	public static void clearDirectory(File directory) {
		if (!directory.exists()) {
			directory.mkdirs();
		} else {
			File[] files = directory.listFiles();
			for (File f : files) {
				f.delete();
			}
		}
	}

	public static void deleteDirectory(File directory) {
		if (directory.exists()) {
			File[] files = directory.listFiles();
			for (File f : files) {
				f.delete();
			}
			directory.delete();
		}
	}

	public static void compareData(IDataIterator<? extends IInstance> d1,
			IDataIterator<? extends IInstance> d2) {
		assertEquals(d1.getMetaData(), d2.getMetaData());
		while (d1.hasNext()) {
			assertEquals(d1.next(), d2.next());
		}
		assertFalse(d2.hasNext());
	}
}
