/**
 * 
 */
package test.dataTestCase;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Arrays;
import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;

import common.XMLUtils;
import common.data.instance.IInstance;
import common.data.meta.CompressedMetaData;
import common.data.meta.Direction;
import common.data.meta.MetaData;
import common.json.JSONUtils;
import common.utils.SimpleByteArrayInputStream;
import common.utils.SimpleByteArrayOutputStream;

/**
 * @author xjchen
 * 
 */
public class TestCompressedMetaData extends AbstractDataTestCase {

	public TestCompressedMetaData(
			IDataGenerator<? extends IInstance> dataGenerator, int index) {
		super(dataGenerator, index);
	}

	@Test
	public void testMetaData() throws Exception {
		int numAttributes = 1000;
		MetaData md1 = getDataGenerator().generateMetaData("data", "", 100,
				numAttributes, new Random(), true);
		md1.getAttributeAt(0).setDirection(Direction.none);
		md1.update();
		assertEquals(1, md1.numIgnored());
		CompressedMetaData cmd1 = (CompressedMetaData) md1
				.toCompressedMetaData();
		assertEquals(md1.numAllAttributes(), cmd1.numAllAttributes());
		assertEquals(md1.getLabelId(), cmd1.getLabelId());
		assertEquals(md1.numIgnored(), cmd1.numIgnored());
		assertTrue(Arrays.equals(md1.getIgnored(), cmd1.getIgnored()));
		assertEquals(md1.numCategoryAttribute(), cmd1.numCategoryAttribute());
		assertEquals(md1.numNumericArrribute(), cmd1.numNumericArrribute());
		assertEquals(md1.numUsedAttributes(), cmd1.numUsedAttributes());

		// binary
		SimpleByteArrayOutputStream bo1 = new SimpleByteArrayOutputStream();
		DataOutputStream dos1 = new DataOutputStream(bo1);
		cmd1.write(dos1);
		SimpleByteArrayInputStream bis1 = new SimpleByteArrayInputStream(bo1);
		int length = bis1.available();
		System.out.println(length * 1000000 / (1024 * numAttributes)
				+ "k/million attribute!");
		CompressedMetaData cmd3 = (CompressedMetaData) MetaData
				.readMetaData(new DataInputStream(bis1));
		assertTrue(cmd1.equals(cmd3));

		// xml
		String xml = cmd1.toXML();
		System.out.println("XML: " + (double) (xml.length() * 2 / length)
				+ " times of binary object.");
		CompressedMetaData cmd2 = (CompressedMetaData) XMLUtils.load(xml);
		assertTrue(cmd1.equals(cmd2));

		// json
		String jsonString = JSONUtils.toJSONOString(cmd1);
		System.out.println("Json: "
				+ (double) (jsonString.length() * 2 / length)
				+ " times of binary object.");
		CompressedMetaData cmd4 = JSONUtils.parse(jsonString,
				CompressedMetaData.class);
		assertTrue(cmd1.equals(cmd4));
	}
}
