/**
 * Created by Xiaojun Chen at 2012-3-29
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataTestCase;

import java.io.File;
import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;

import common.data.IDataIterator;
import common.data.instance.IInstance;
import common.data.instance.numeric.INumericInstance;
import common.data.io.CSVDataWriter;

/**
 * @author Xiaojun Chen
 * 
 *         1.0.0
 */
public class CSVDataWriterTester extends AbstractDataTestCase {

	public CSVDataWriterTester(
			IDataGenerator<? extends IInstance> dataGenerator, int index) {
		super(dataGenerator, index);
	}

	@Test
	public void testCSVDataWriter() throws Exception {
		IDataIterator<INumericInstance> dataIterator = (IDataIterator<INumericInstance>) getDataGenerator()
				.createDataIterator("data", "", 100, 100, new Random(10), true);
		CSVDataWriter cdw = new CSVDataWriter(dataIterator);
		File dir = new File("text");
		clearDirectory(dir);
		cdw.writeToFile(new File(dir, "data.csv"));
		deleteDirectory(dir);
	}
}
