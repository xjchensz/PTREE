/**
 * Created by Xiaojun Chen at 2011-11-7
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataTestCase;

import java.io.DataOutputStream;
import java.io.File;
import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;

import common.data.Data;
import common.data.IDataIterator;
import common.data.IIndexedDataIterator;
import common.data.instance.IInstance;
import common.data.instance.numeric.INumericInstance;
import common.data.io.SerializedDataFileReader;
import common.data.io.SerializedDataStreamReader;
import common.data.io.SerializedDataWriter;
import common.data.io.indexed.IndexedSerializedDataFileReader;
import common.data.io.indexed.IndexedSerializedDataInputStream;
import common.data.io.indexed.IndexedSerializedDataStreamReader;
import common.data.io.indexed.IndexedSerializedDataWriter;
import common.utils.SimpleByteArrayInputStream;
import common.utils.SimpleByteArrayOutputStream;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class SerializedDataTestCase extends AbstractDataTestCase {

	public SerializedDataTestCase(
			IDataGenerator<? extends IInstance> dataGenerator, int index) {
		super(dataGenerator, index);
	}

	@Test
	public void testWriteReadStream() throws Exception {
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 2, new Random(10), true);
		// write data
		SimpleByteArrayOutputStream bo = new SimpleByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bo);
		SerializedDataWriter sdw = new SerializedDataWriter(data.toIterator());
		sdw.writeToOutputStream(dos);
		sdw.close(true);

		// read data
		SimpleByteArrayInputStream bis = new SimpleByteArrayInputStream(bo);
		IDataIterator<IInstance> di = new SerializedDataStreamReader<IInstance>(
				bis);
		compareData(data.toIterator(), di);
		data.clear();
		di.close();
	}

	@Test
	public void testWriteReadFiles() throws Exception {
		File dir = new File("serialized/data");
		clearDirectory(dir);
		// write data
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 1000, new Random(10), true);
		SerializedDataWriter sdw = new SerializedDataWriter(data.toIterator());
		sdw.writeToDirectory(dir);
		sdw.close(true);

		// read data
		IDataIterator<IInstance> di = new SerializedDataFileReader<IInstance>(
				dir);
		compareData(data.toIterator(), di);
		data.clear();
		di.close();
		deleteDirectory(dir);
	}

	@Test
	public void testWriteReadIndexedStream() throws Exception {
		File dir = new File("serialized/data");
		clearDirectory(dir);
		// write data
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 1000, new Random(10), true);
		IndexedSerializedDataWriter isdw = new IndexedSerializedDataWriter(data
				.clone().toIterator());
		isdw.writeToDirectory(dir);
		isdw.close(true);

		// read data

		IIndexedDataIterator<INumericInstance> di = new IndexedSerializedDataStreamReader<INumericInstance>(
				new IndexedSerializedDataInputStream(dir));
		compareData(data.clone().toIterator(), di);
		di.close();

		// test skip
		di = new IndexedSerializedDataStreamReader<INumericInstance>(
				new IndexedSerializedDataInputStream(dir));
		di.skipTo(10);
		assertEquals(data.get(10), di.next());
		di.skip(9);
		assertEquals(data.get(20), di.next());
		try {
			di.skip(-1);
			fail("Should throw exception!");
		} catch (RuntimeException e) {

		}

		try {
			di.skipTo(20);
			fail("Should throw exception!");
		} catch (RuntimeException e) {

		}

		data.clear();
		di.close();
		deleteDirectory(dir);
	}

	@Test
	public void testWriteReadIndexedFiles() throws Exception {
		File dir = new File("serialized/data" + "/" + getIndex());
		clearDirectory(dir);
		// write data
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 10, new Random(10), true);
		IndexedSerializedDataWriter isdw = new IndexedSerializedDataWriter(data
				.clone().toIterator());
		isdw.writeToDirectory(dir);
		isdw.close(true);

		// read data
		IIndexedDataIterator<INumericInstance> di = new IndexedSerializedDataFileReader<INumericInstance>(
				dir);
		compareData(data.clone().toIterator(), di);
		di.reset();

		// skipto
		di.skipTo(10);
		assertEquals(data.get(10), di.next());

		// skip
		di.skip(70);
		assertEquals(data.get(81), di.next());
		di.skip(-2);
		assertEquals(data.get(80), di.next());

		// back
		// skipto
		di.skipTo(10);
		assertEquals(data.get(10), di.next());

		// big skip
		di.skipTo(30);
		assertEquals(data.get(30), di.next());

		// reset
		di.reset();
		// skip
		di.skip(10);
		di.skip(30);
		assertEquals(data.get(40), di.next());

		// compare
		di.reset();
		compareData(data.toIterator(), di);

		data.clear();
		di.close();
		deleteDirectory(dir);
	}
}
