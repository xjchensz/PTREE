/**
 * Created by Xiaojun Chen at 2011-11-7
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataTestCase;

import java.io.File;
import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;

import common.data.Data;
import common.data.IDataIterator;
import common.data.IIndexedDataIterator;
import common.data.instance.IInstance;
import common.data.instance.numeric.INumericInstance;
import common.data.io.SerializedDataInputStream;
import common.data.io.SerializedDataStreamReader;
import common.data.io.SerializedDataWriter;
import common.data.io.ZipSerializedDataWriter;
import common.data.io.indexed.IndexedSerializedDataInputStream;
import common.data.io.indexed.IndexedSerializedDataStreamReader;
import common.data.io.indexed.IndexedSerializedDataWriter;
import common.data.io.indexed.IndexedZipSerializedDataWriter;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class InputStreamTestCase extends AbstractDataTestCase {

	public InputStreamTestCase(
			IDataGenerator<? extends IInstance> dataGenerator, int index) {
		super(dataGenerator, index);
	}

	@Test
	public void testStream() throws Exception {

		File file = new File("serialized/data");
		clearDirectory(file);
		// write data
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 1000, new Random(10), true);
		SerializedDataWriter sdw = new SerializedDataWriter(data.toIterator());
		sdw.writeToDirectory(file);
		sdw.close(true);

		// read data
		IDataIterator<INumericInstance> di = new SerializedDataStreamReader<INumericInstance>(
				new SerializedDataInputStream(file, true));
		compareData(data.toIterator(), di);
		data.clear();
		di.close();
		file.delete();
	}

	@Test
	public void testIndexedStream() throws Exception {
		File dir = new File("serialized/data");
		clearDirectory(dir);
		// write data
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 1000, new Random(10), true);
		IndexedSerializedDataWriter isdw = new IndexedSerializedDataWriter(data
				.clone().toIterator());
		isdw.writeToDirectory(dir);
		isdw.close(true);

		// read data
		IIndexedDataIterator<INumericInstance> di = new IndexedSerializedDataStreamReader<INumericInstance>(
				new IndexedSerializedDataInputStream(dir));
		compareData(data.clone().toIterator(), di);

		data.clear();
		di.close();
		deleteDirectory(dir);
	}

	public void testZipStream() throws Exception {
		File file = new File("serialized/data.zip");
		if (!file.exists()) {
			file.createNewFile();
		}
		// write data
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 2, 1000, new Random(10), true);
		ZipSerializedDataWriter sdw = new ZipSerializedDataWriter(
				data.toIterator());
		sdw.writeToFile(file);
		sdw.close(true);

		// read data
		IDataIterator<INumericInstance> di = new SerializedDataStreamReader<INumericInstance>(
				new SerializedDataInputStream(file, true));
		compareData(data.toIterator(), di);
		data.clear();
		di.close();
		file.delete();
	}

	public void testIndexedZipStream() throws Exception {
		File file = new File("serialized/data.zip");
		if (!file.exists()) {
			file.createNewFile();
		}
		// write data
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 2, 1000, new Random(10), true);
		IndexedZipSerializedDataWriter sdw = new IndexedZipSerializedDataWriter(
				data.toIterator());
		sdw.writeToFile(file);
		sdw.close(true);

		// read data
		IIndexedDataIterator<INumericInstance> di = new IndexedSerializedDataStreamReader<INumericInstance>(
				new IndexedSerializedDataInputStream(file));
		compareData(data.toIterator(), di);

		data.clear();
		di.close();
		file.delete();
	}
}
