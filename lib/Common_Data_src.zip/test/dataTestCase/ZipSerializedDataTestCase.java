/**
 * Created by Xiaojun Chen at 2011-11-7
 * Shenzhen High Performance Data Mining Lab 
 */
package test.dataTestCase;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.Random;

import org.junit.Test;

import test.dataGenerator.IDataGenerator;

import common.data.Data;
import common.data.IDataIterator;
import common.data.IIndexedDataIterator;
import common.data.instance.IInstance;
import common.data.instance.numeric.INumericInstance;
import common.data.io.SerializedDataStreamReader;
import common.data.io.SerializedDataWriter;
import common.data.io.UnZipSerializedDataInputStream;
import common.data.io.ZipSerializedDataInputStream;
import common.data.io.ZipSerializedDataReader;
import common.data.io.ZipSerializedDataWriter;
import common.data.io.indexed.IndexedZipSerializedDataFileReader;
import common.data.io.indexed.IndexedZipSerializedDataStreamReader;
import common.data.io.indexed.IndexedZipSerializedDataWriter;
import common.utils.SimpleByteArrayInputStream;
import common.utils.SimpleByteArrayOutputStream;

/**
 * @author Xiaojun Chen
 * @version 0.1
 */
public class ZipSerializedDataTestCase extends AbstractDataTestCase {

	public ZipSerializedDataTestCase(
			IDataGenerator<? extends IInstance> dataGenerator, int index) {
		super(dataGenerator, index);
	}

	@Test
	public void testWriteReadStream() throws Exception {
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 500, new Random(10), true);
		// write data
		SimpleByteArrayOutputStream bo = new SimpleByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bo);
		ZipSerializedDataWriter zsdw = new ZipSerializedDataWriter(
				data.toIterator());
		zsdw.writeToOutputStream(dos, true);
		zsdw.close(true);

		// read data
		SimpleByteArrayInputStream bis = new SimpleByteArrayInputStream(bo);
		IDataIterator<INumericInstance> di = new ZipSerializedDataReader<INumericInstance>(
				bis);
		compareData(data.toIterator(), di);
		di.close();

		// close
		data.clear();
	}

	@Test
	public void testWriteReadFile() throws Exception {
		File file = new File("serialized/data.zip");
		clearFile(file);
		// write data
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 1000, new Random(10), true);
		ZipSerializedDataWriter sdw = new ZipSerializedDataWriter(
				data.toIterator());
		sdw.writeToFile(file);
		sdw.close(true);

		// read data
		IDataIterator<INumericInstance> di = new ZipSerializedDataReader<INumericInstance>(
				file);
		compareData(data.toIterator(), di);
		data.clear();
		di.close();
		deleteFile(file);
	}

	@Test
	public void testWriteReadInputStream() throws Exception {
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 500, new Random(10), true);
		// inputstream
		ZipSerializedDataInputStream zis = new ZipSerializedDataInputStream(
				data.toIterator());

		// transform to data
		IDataIterator<INumericInstance> di = new ZipSerializedDataReader<INumericInstance>(
				zis);
		compareData(data.toIterator(), di);
		di.close();

		// close
		data.clear();
	}

	@Test
	public void testWriteDirectoryReadStream() throws Exception {
		File dir = new File("serialized");
		deleteDirectory(dir);

		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 500, new Random(10), true);

		// write data
		SerializedDataWriter sdw = new SerializedDataWriter(data.toIterator());
		sdw.writeToDirectory(dir);
		sdw.close(true);

		// read data
		IDataIterator<IInstance> di = new ZipSerializedDataReader<IInstance>(
				new ZipSerializedDataInputStream(dir));
		compareData(data.toIterator(), di);
		data.clear();
		di.close();
		deleteDirectory(dir);
	}

	@Test
	public void testWriteReadUnZipInputStream() throws Exception {
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 1000, 500, new Random(10), true);
		// inputstream
		UnZipSerializedDataInputStream is = new UnZipSerializedDataInputStream(
				new ZipSerializedDataInputStream(data.toIterator()));

		// transform to data
		IDataIterator<INumericInstance> di = new SerializedDataStreamReader<INumericInstance>(
				is);
		compareData(data.toIterator(), di);
		di.close();

		// close
		data.clear();
	}

	@Test
	public void testWriteReadIndexedFile() throws Exception {
		File file = new File("serialized/" + getIndex() + ".zip");
		clearFile(file);
		// write data
		Data<? extends IInstance> data = getDataGenerator().createData("data",
				"", 10000, 100, new Random(10), true);
		IndexedZipSerializedDataWriter isdw = new IndexedZipSerializedDataWriter(
				data.toIterator());
		isdw.writeToFile(file);
		isdw.close(true);

		// read data
		IIndexedDataIterator<INumericInstance> di = new IndexedZipSerializedDataFileReader<INumericInstance>(
				file);
		compareData(data.toIterator(), di);
		di.reset();

		// skipto
		di.skipTo(10);
		assertEquals(data.get(10), di.next());

		// skip
		di.skip(70);
		assertEquals(data.get(81), di.next());
		di.skip(-2);
		assertEquals(data.get(80), di.next());

		// back
		// skipto
		di.skipTo(10);
		assertEquals(data.get(10), di.next());

		// big skip
		di.skipTo(30);
		assertEquals(data.get(30), di.next());

		// reset
		di.reset();
		// skip
		di.skip(10);
		di.skip(30);
		assertEquals(data.get(40), di.next());

		// compare
		di.reset();
		compareData(data.toIterator(), di);

		di.close();

		// read stream
		di = new IndexedZipSerializedDataStreamReader<INumericInstance>(
				new FileInputStream(file));
		compareData(data.toIterator(), di);
		di.close();

		di = new IndexedZipSerializedDataStreamReader<INumericInstance>(
				new FileInputStream(file));
		di.skip(10);
		assertEquals(data.get(10), di.next());

		di.skip(39);
		assertEquals(data.get(50), di.next());

		data.clear();
		deleteFile(file);
	}
}
